package parcial12;

public class Ciudad {
	private String nombre;
	private int tiempoTransito;
	
	public Ciudad(String nombre, int tiempoTransito) {
		this.nombre = nombre;
		this.tiempoTransito = tiempoTransito;
	}
	
	public String getNombre() {
		return nombre;
	}
	public void setNombre(String nombre) {
		this.nombre = nombre;
	}
	public int getTiempoTransito() {
		return tiempoTransito;
	}
	public void setTiempoTransito(int tiempoTransito) {
		this.tiempoTransito = tiempoTransito;
	}
	
	
}
