package parcial12;

import java.util.Iterator;
import java.util.List;

import practica5.ejercicio1Grafo.Edge;
import practica5.ejercicio1Grafo.Graph;
import practica5.ejercicio1Grafo.Vertex;
import practica5.ejercicio1Grafo.adjList.AdjListGraph;

public class Parcial {//empece 2:10 termine 2:35
	public int resolver(Graph<Ciudad> ciudades,String origen,String destino,int maxControles) {
		int maxTiempoTransito=0;
		if(!ciudades.isEmpty()) {
			Vertex<Ciudad> ori=buscarCiudades(ciudades,origen,destino);
			if(ori!=null) {
				int maximo=0;
				int tiempoTransito=ori.getData().getTiempoTransito();
				maxTiempoTransito=resolver(ciudades,ori,destino,maxControles,maximo,tiempoTransito,new boolean[ciudades.getSize()]);
			}
		}
		return maxTiempoTransito;
	}
	
	private int resolver(Graph<Ciudad> ciudades,Vertex<Ciudad> v,String destino,int maxControles,int maximo, int tiempoTransito,boolean[]visitados) {
		visitados[v.getPosition()]=true;
		if(v.getData().getNombre().equals(destino)&&tiempoTransito>maximo) {
			maximo=tiempoTransito;
		}
		else {
			List<Edge<Ciudad>> ady=ciudades.getEdges(v);
			for(Edge<Ciudad> arista:ady) {
				int aux=tiempoTransito+arista.getTarget().getData().getTiempoTransito();
				if(!visitados[arista.getTarget().getPosition()]&&arista.getWeight()<=maxControles) {
					maximo=resolver(ciudades,arista.getTarget(),destino,maxControles,maximo,aux,visitados);
				}
			}
		}
		visitados[v.getPosition()]=false;
		return maximo;
	}
	
	private Vertex<Ciudad> buscarCiudades(Graph<Ciudad> ciudades,String origen,String destino){
		boolean encontreO=false;
		boolean encontreD=false;
		boolean encontre=false;
		Vertex<Ciudad> v=null;
		Vertex<Ciudad> vO=null;
		List<Vertex<Ciudad>> vertices=ciudades.getVertices();
		Iterator<Vertex<Ciudad>> it=vertices.iterator();
		while(it.hasNext()&&!encontre) {
			v=it.next();
			if(v.getData().getNombre().equals(origen)) {
				encontreO=true;
				vO=v;
			}
			if(v.getData().getNombre().equals(destino)) {
				encontreD=true;
			}
			if(encontreO&&encontreD) {
				encontre=true;
			}
		}
		return encontre?vO:null;
	}
	
	public static void main(String args[]) {
        Graph<Ciudad> grafo = new AdjListGraph<Ciudad>();
        //Descarte Saladillo, Lobos y Pinamar
        Vertex<Ciudad> v1 = grafo.createVertex(new Ciudad("Suipacha", 3));
        Vertex<Ciudad> v2 = grafo.createVertex(new Ciudad("Carlos Keen", 2));
        Vertex<Ciudad> v3 = grafo.createVertex(new Ciudad("Moreno", 2));
        Vertex<Ciudad> v4 = grafo.createVertex(new Ciudad("Quilmes", 3));
        Vertex<Ciudad> v5 = grafo.createVertex(new Ciudad("Navarro", 1));
        Vertex<Ciudad> v6 = grafo.createVertex(new Ciudad("Cañuelas", 2));
        Vertex<Ciudad> v7 = grafo.createVertex(new Ciudad("Abasto", 3));
        Vertex<Ciudad> v8 = grafo.createVertex(new Ciudad("La Plata", 1));
        
        grafo.connect(v1, v2, 2);
        grafo.connect(v2, v1, 2);
        grafo.connect(v2, v3, 2);
        grafo.connect(v3, v2, 2);
        grafo.connect(v3, v4, 2);
        grafo.connect(v4, v3, 2);
        grafo.connect(v1, v5, 2);
        grafo.connect(v5, v1, 2);
        grafo.connect(v5, v6, 2);
        grafo.connect(v6, v5, 2);
        grafo.connect(v6, v7, 2);
        grafo.connect(v7, v6, 2);
        grafo.connect(v7, v3, 3);
        grafo.connect(v3, v7, 3);
        grafo.connect(v7, v8, 2);
        grafo.connect(v8, v7, 2);
        grafo.connect(v8, v4, 2);
        grafo.connect(v4, v8, 2);
        
        Parcial p = new Parcial();
        
        System.out.println(p.resolver(grafo, "La Plata", "Suipacha", 2));
        System.out.println(p.resolver(grafo, "La Plata", "Carlos Keen", 2));
    }
}
