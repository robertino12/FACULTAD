package parcial5;

public class Estadio {
	private String nombre;
	private String nombreCiudad;
	
	public Estadio( String nombreCiudad,String nombre) {
		this.nombre = nombre;
		this.nombreCiudad = nombreCiudad;
	}
	
	public String getNombre() {
		return nombre;
	}
	public void setNombre(String nombre) {
		this.nombre = nombre;
	}
	public String getNombreCiudad() {
		return nombreCiudad;
	}
	public void setNombreCiudad(String nombreCiudad) {
		this.nombreCiudad = nombreCiudad;
	}
	
	
}
