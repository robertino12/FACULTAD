package parcial5;

import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;

import practica5.ejercicio1Grafo.Edge;
import practica5.ejercicio1Grafo.Graph;
import practica5.ejercicio1Grafo.Vertex;
import practica5.ejercicio1Grafo.adjList.AdjListGraph;

public class Parcial {//empece 18:30 termine 19:11
	public List<String> estadios (Graph<Estadio> mapaEstadios, String estadioOrigen, int cantKm){
		List<String> caminoMax=new LinkedList<String>();
		if(!mapaEstadios.isEmpty()) {
			Vertex<Estadio> v=buscarOrigen(mapaEstadios,estadioOrigen);	
			if(v!=null) {
				int cantKmRecorridos=0;
				estadios(mapaEstadios,caminoMax,new LinkedList<String>(),cantKmRecorridos,cantKm,v,new boolean[mapaEstadios.getSize()]);
			}
		}
		return caminoMax;
	}
	
	private void estadios(Graph<Estadio> mapa,List<String> caminoMax, LinkedList<String> caminoAct, int cantKmRecorridos,int cantKm, Vertex<Estadio> v,boolean[]visitados) {
		visitados[v.getPosition()]=true;
		caminoAct.add(v.getData().getNombre());
		List<Edge<Estadio>> ady=mapa.getEdges(v);
		Iterator<Edge<Estadio>> it=ady.iterator();
		while(it.hasNext()&&cantKmRecorridos<=cantKm) {
			Edge<Estadio> arista=it.next();
			int aux=cantKmRecorridos+arista.getWeight();
			if(!visitados[arista.getTarget().getPosition()]&&aux<=cantKm) {
				estadios(mapa,caminoMax,caminoAct,aux,cantKm,arista.getTarget(),visitados);
			}
		}
		if(caminoAct.size()>caminoMax.size()) {
			caminoMax.removeAll(caminoMax);
			caminoMax.addAll(caminoAct);
		}
		visitados[v.getPosition()]=false;
		caminoAct.remove(caminoAct.size()-1);
	}
	
	private Vertex<Estadio> buscarOrigen(Graph<Estadio> mapa,String origen){
		Vertex<Estadio> v=null;
		boolean encontre=false;
		List<Vertex<Estadio>> vertices=mapa.getVertices();
		Iterator<Vertex<Estadio>> it=vertices.iterator();
		while(it.hasNext()&&!encontre) {
			v=it.next();
			if(v.getData().getNombre().equals(origen)) {
				encontre=true;
			}
		}
		return v;
	}
	
	 public static void main(String args[]) {
	        Graph<Estadio> grafo = new AdjListGraph<Estadio>();
	        Vertex<Estadio> v1 = grafo.createVertex(new Estadio("Jor", "AI BAYT STADIUM"));
	        Vertex<Estadio> v2 = grafo.createVertex(new Estadio("Lusail", "LUSAIL STADIUM"));
	        Vertex<Estadio> v3 = grafo.createVertex(new Estadio("Rayán", "EDUCATION CITY STADIUM"));
	        Vertex<Estadio> v4 = grafo.createVertex(new Estadio("Rayán", "AL RAYYAN STADIUM"));
	        Vertex<Estadio> v5 = grafo.createVertex(new Estadio("Doha", "STADIUM 947"));
	        Vertex<Estadio> v6 = grafo.createVertex(new Estadio("Doha", "KHALIFA INTERNATIONAL STADIUM"));
	        Vertex<Estadio> v7 = grafo.createVertex(new Estadio("Doha", "AL THUMAMA STADIUM"));
	        Vertex<Estadio> v8 = grafo.createVertex(new Estadio("Wakrah", "AL JANOUB STADIUM"));
	        
	        grafo.connect(v1, v2, 42);
	        grafo.connect(v2, v1, 42);
	        grafo.connect(v2, v3, 24);
	        grafo.connect(v3, v2, 24);
	        grafo.connect(v2, v5, 52);
	        grafo.connect(v5, v2, 52);
	        grafo.connect(v3, v4, 11);
	        grafo.connect(v4, v3, 11);
	        grafo.connect(v4, v6, 8);
	        grafo.connect(v6, v4, 8);
	        grafo.connect(v6, v7, 12);
	        grafo.connect(v7, v6, 12);
	        grafo.connect(v7, v8, 12);
	        grafo.connect(v8, v7, 12);
	        grafo.connect(v8, v5, 19);
	        grafo.connect(v5, v8, 19);
	        
	        Parcial p = new Parcial();
	        
	        System.out.println(p.estadios(grafo, "AI BAYT STADIUM", 100));
	    }
}
