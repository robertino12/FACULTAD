package parcial6;

import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;

import practica5.ejercicio1Grafo.Edge;
import practica5.ejercicio1Grafo.Graph;
import practica5.ejercicio1Grafo.Vertex;

public class Parcial {//empece 19:50 termine 20:14
	public List<String> caminoConPresupuesto(Graph<String> ciudades, String origen, String destino, int montoMaximo){
		List<String> camino=new LinkedList<String>();
		if(!ciudades.isEmpty()) {
			Vertex<String> ori=ciudades.search(origen);
			Vertex<String> dest=ciudades.search(destino);
			if(ori!=null&&dest!=null) {
				int pesosGastados=0;
				caminoConPresupuesto(ciudades,camino,ori,destino,pesosGastados,montoMaximo,new boolean[ciudades.getSize()]);
			}
		}
		return camino;
	}
	
	//que devuelva true cuando encuentre el camino, ya que pide uno cualquiera, al pedo seguir recorriendo
	private boolean caminoConPresupuesto(Graph<String> ciudades,List<String> camino,Vertex<String> v,String destino, int pesosGastados, int montoMaximo,boolean[]visitados) {
		visitados[v.getPosition()]=true;
		camino.add(v.getData());
		boolean encontre=false;
		if(v.getData().equals(destino)) {
			if(pesosGastados<=montoMaximo) {
				return true;
			}
		}
		else {
			List<Edge<String>> ady=ciudades.getEdges(v);
			Iterator<Edge<String>> it=ady.iterator();
			while(it.hasNext()&&!encontre&&pesosGastados<=montoMaximo) {
				Edge<String> arista=it.next();
				int aux=pesosGastados+arista.getWeight();
				if(!visitados[arista.getTarget().getPosition()]&&aux<=montoMaximo) {
					encontre=caminoConPresupuesto(ciudades,camino,arista.getTarget(),destino,aux,montoMaximo,visitados);
				}
			}
			if(!encontre) {
				visitados[v.getPosition()]=false;
				camino.remove(camino.size()-1);
			}
		}
		return encontre;
	}
}
