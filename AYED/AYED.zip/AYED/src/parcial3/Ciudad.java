package parcial3;

public class Ciudad {
	private String nombre;
	private int tiempoRecorrer;
	
	public Ciudad(String nombre, int tiempoRecorrer) {
		this.nombre = nombre;
		this.tiempoRecorrer = tiempoRecorrer;
	}
	public String getNombre() {
		return nombre;
	}
	public void setNombre(String nombre) {
		this.nombre = nombre;
	}
	public int getTiempoRecorrer() {
		return tiempoRecorrer;
	}
	public void setTiempoRecorrer(int tiempoRecorrer) {
		this.tiempoRecorrer = tiempoRecorrer;
	}
	
	
}
