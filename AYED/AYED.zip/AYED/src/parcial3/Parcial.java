package parcial3;

import java.util.Iterator;
import java.util.List;

import practica5.ejercicio1Grafo.Edge;
import practica5.ejercicio1Grafo.Graph;
import practica5.ejercicio1Grafo.Vertex;
import practica5.ejercicio1Grafo.adjList.AdjListGraph;

public class Parcial {//empece 13:28
	public String resolver(Graph<Ciudad> sitios,int tiempo) {
		boolean cumple=false;
		if(!sitios.isEmpty()) {
			Vertex<Ciudad> v=buscarEntrada(sitios, "Entrada");
			if(v!=null) {
				if(v.getData().getTiempoRecorrer()<=tiempo) {
					int tiempoConsumido=v.getData().getTiempoRecorrer();
					int lugaresRecorridos=1;
					cumple=resolver(sitios,tiempo,tiempoConsumido,lugaresRecorridos,new boolean[sitios.getSize()],v);
				}
			}
		}
		return cumple?"Alcanzable":"No Alcanzable";
	}
	
	private boolean resolver(Graph<Ciudad> sitios, int tiempo, int tiempoConsumido, int lugaresRecorridos, boolean[]visitados,Vertex<Ciudad> v) {
		visitados[v.getPosition()]=true;
		boolean encontre=false;
		if(lugaresRecorridos==sitios.getSize()&&tiempoConsumido<=tiempo){
			return true;
		}
		else {
			List<Edge<Ciudad>> ady=sitios.getEdges(v);
			Iterator<Edge<Ciudad>> it=ady.iterator();
			while(it.hasNext()&&!encontre&&tiempoConsumido<=tiempo) {
				Edge<Ciudad> arista=it.next();
				int aux=tiempoConsumido+arista.getWeight()+arista.getTarget().getData().getTiempoRecorrer();
				if(!visitados[arista.getTarget().getPosition()]&&aux<=tiempo) {
					encontre=resolver(sitios,tiempo,aux,lugaresRecorridos+1,visitados,arista.getTarget());
				}
			}
			if(!encontre) {
				visitados[v.getPosition()]=false;
			}
		}
		return encontre;
	}
	
	private Vertex<Ciudad> buscarEntrada(Graph<Ciudad> sitios,String entrada){
		boolean encontre=false;
		Vertex<Ciudad> v=null;
		List<Vertex<Ciudad>> vertices=sitios.getVertices();
		Iterator<Vertex<Ciudad>> it=vertices.iterator();
		while(it.hasNext()&&!encontre) {
			v=it.next();
			if(v.getData().getNombre().equals(entrada)) {
				encontre=true;
			}
		}
		return v;
	}
	
	public static void main(String args[]) {
        Graph<Ciudad> grafo = new AdjListGraph<Ciudad>();
        Vertex<Ciudad> Entrada = grafo.createVertex(new Ciudad("Entrada", 15));
        Vertex<Ciudad> Cebras = grafo.createVertex(new Ciudad("Cebras", 10));
        Vertex<Ciudad> Tigres = grafo.createVertex(new Ciudad("Tigres", 10));
        Vertex<Ciudad> Flamencos = grafo.createVertex(new Ciudad("Flamencos", 10));
        Vertex<Ciudad> Murcielagos = grafo.createVertex(new Ciudad("Murciélagos", 20));
        Vertex<Ciudad> Wallabies = grafo.createVertex(new Ciudad("Wallabies", 30));
        Vertex<Ciudad> Tortugas = grafo.createVertex(new Ciudad("Tortugas", 10));
        Vertex<Ciudad> Pumas = grafo.createVertex(new Ciudad("Pumas", 10));
        
        grafo.connect(Entrada, Cebras, 10);
        grafo.connect(Cebras, Entrada, 10);
        grafo.connect(Entrada, Tigres, 15);
        grafo.connect(Tigres, Entrada, 15);
        grafo.connect(Entrada, Murcielagos, 20);
        grafo.connect(Murcielagos, Entrada, 20);
        grafo.connect(Entrada, Flamencos, 25);
        grafo.connect(Flamencos, Entrada, 25);
        
        grafo.connect(Tigres, Cebras, 8);
        grafo.connect(Cebras, Tigres, 8);
        grafo.connect(Cebras, Tortugas, 5);
        grafo.connect(Tortugas, Cebras, 5);
        grafo.connect(Flamencos, Murcielagos, 25);
        grafo.connect(Murcielagos, Flamencos, 25);
        grafo.connect(Murcielagos, Wallabies, 10);
        grafo.connect(Wallabies, Murcielagos, 10);
        grafo.connect(Wallabies, Tortugas, 10);
        grafo.connect(Tortugas, Wallabies, 10);
        grafo.connect(Tortugas, Pumas, 15);
        grafo.connect(Pumas, Tortugas, 15);
        grafo.connect(Pumas, Wallabies, 2);
        grafo.connect(Wallabies, Pumas, 2);
        
        Parcial p = new Parcial();
        
        System.out.println(p.resolver(grafo, 220));
        System.out.println(p.resolver(grafo, 205));
        System.out.println(p.resolver(grafo, 195));
        System.out.println(p.resolver(grafo, 100));
    }
}
