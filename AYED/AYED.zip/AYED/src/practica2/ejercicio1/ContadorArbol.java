package practica2.ejercicio1;

import java.util.*;
public class ContadorArbol {
	BinaryTree<Integer> arbol;
	ArrayList<Integer> lista;
	public ContadorArbol() {
	}
	
	public void setArbol(BinaryTree<Integer> arbol) {
		this.arbol=arbol;
	}
	public void setLista(ArrayList<Integer> lista) {
		this.lista=lista;
	}
	public ArrayList<Integer> numerosPares(){
		//preOrden(this.arbol);
		//inOrden(this.arbol);
		posOrden(this.arbol);
		return this.lista;
	}
	/*private void preOrden(BinaryTree<Integer> arbol){
		if(arbol.getData()%2==0)
			this.lista.add(arbol.getData());
		if(arbol.hasLeftChild()) {
			this.preOrden(arbol.getLeftChild());
		} 
	    if(arbol.hasRightChild()) {
	    	this.preOrden(arbol.getRightChild());
	    }
	}*///funciona 2,4,6
	/*private void inOrden(BinaryTree<Integer> arbol){
		
		if(arbol.hasLeftChild()) {
			this.inOrden(arbol.getLeftChild());
		} 
		if(arbol.getData()%2==0)
			this.lista.add(arbol.getData());
	    if(arbol.hasRightChild()) {
	    	this.inOrden(arbol.getRightChild());
	    }
	}*///funciona 4,2,6
	private void posOrden(BinaryTree<Integer> arbol){
		if(arbol.hasLeftChild()) {
			this.posOrden(arbol.getLeftChild());
		} 
	    if(arbol.hasRightChild()) {
	    	this.posOrden(arbol.getRightChild());
	    }
	    if(arbol.getData()%2==0)
			this.lista.add(arbol.getData());
	}//funciona 4,2,6
	
	/*public ArrayList<Integer> numerosPares2(){
		if(this.arbol.getData()%2==0)
			this.lista.add(this.arbol.getData());
		if(this.arbol.hasLeftChild()) {
			this.arbol=this.arbol.getLeftChild();
			this.numerosPares2();
		} 
	    if(this.arbol.hasRightChild()) {
	    	this.arbol=this.arbol.getRightChild();
	    	this.numerosPares2();
	    }
	    	
	    return lista;
	}//DE ESTA MANERA SOLO ME IMPRIME 2 Y 4, LA HICE YO,
	//segun chatgpt es xq cada vez q recursiono actualizo la instancia del arbol
	//por lo tanto pierdo la referencia al nodo actual, por lo cual
	//no puedo explorar todos los nodos del arbol bien. */

	public static void main(String[] args) {
		ContadorArbol obj=new ContadorArbol();
		BinaryTree<Integer> arbol=new BinaryTree<>(1);
		BinaryTree<Integer> hijoIzq=new BinaryTree<>(2);
		hijoIzq.addLeftChild(new BinaryTree<Integer>(4));
		hijoIzq.addRightChild(new BinaryTree<Integer>(5));
		arbol.addLeftChild(hijoIzq);
		BinaryTree<Integer> hijoDer=new BinaryTree<>(3);
		hijoDer.addLeftChild(new BinaryTree<Integer>(6));
		hijoDer.addRightChild(new BinaryTree<Integer>(7));
		arbol.addRightChild(hijoDer);
		obj.setArbol(arbol);
		ArrayList<Integer> lista=new ArrayList<>();
		obj.setLista(lista);
		for(int i:obj.numerosPares()) {
			System.out.println(i);
		}
	}

}