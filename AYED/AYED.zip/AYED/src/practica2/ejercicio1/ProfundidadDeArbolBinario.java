package practica2.ejercicio1;

import java.util.LinkedList;
import java.util.Queue;

public class ProfundidadDeArbolBinario {
	BinaryTree<Integer> arbol;
	
	public ProfundidadDeArbolBinario() {
		
	}
	
	public void setArbol(BinaryTree<Integer> arbol) {
		this.arbol=arbol;
	}
	
	public int sumaElementosProfundidad(int p) {
		return sumaProfundidad(this.arbol,p);
	}
	
	private int sumaProfundidad(BinaryTree<Integer> a,int p) {
		int suma=0;
		if(p<0) {
			System.out.println("p es incorrecto");
		}else {
			int nivel=0;
			BinaryTree<Integer> arbol=null;
			Queue<BinaryTree<Integer>> cola=new LinkedList<>();
			cola.add(a);
			cola.add(null);
			while(nivel<=p) {
					arbol=cola.remove();
					if(arbol!=null) {
						if(nivel==p)suma=suma+arbol.getData();
						if(arbol.hasLeftChild()) cola.add(arbol.getLeftChild());
						if(arbol.hasRightChild()) cola.add(arbol.getRightChild());
					}
					else if(!cola.isEmpty()) {
						cola.add(null);
						nivel++;
					}
					else if(cola.isEmpty())nivel++;
			}
		}
		return suma;
	}
	
	public static void main(String[] args) {
		ProfundidadDeArbolBinario obj=new ProfundidadDeArbolBinario();
		BinaryTree<Integer> arbol=new BinaryTree<>(1);
		BinaryTree<Integer> hijoIzq=new BinaryTree<>(2);
		hijoIzq.addLeftChild(new BinaryTree<Integer>(4));
		hijoIzq.addRightChild(new BinaryTree<Integer>(5));
		arbol.addLeftChild(hijoIzq);
		BinaryTree<Integer> hijoDer=new BinaryTree<>(3);
		hijoDer.addLeftChild(new BinaryTree<Integer>(6));
		hijoDer.addRightChild(new BinaryTree<Integer>(7));
		arbol.addRightChild(hijoDer);
		obj.setArbol(arbol);
		System.out.println(obj.sumaElementosProfundidad(1));
	}
}
