package practica2.ejercicio1;

public class RedBinariaLlena {
	BinaryTree<Integer> arbol;
	
	public RedBinariaLlena() {
		
	}
	
	public void setArbol(BinaryTree<Integer> arbol) {
		this.arbol=arbol;
	}
	
	public int retardoReenvio() {
		return retardo(this.arbol);
	}
	
	private int retardo(BinaryTree<Integer> arbol) {
		//como se que esta lleno no pregunto si es null o esta vacio
		//tampoco pregunto si tiene hijo izq o der
		int valorHI=0;
		int valorHD=0;
		if(arbol.isLeaf()) {
			return arbol.getData();
		}
		else {
			valorHI=retardo(arbol.getLeftChild());
			valorHD=retardo(arbol.getRightChild());
			int max=Math.max(valorHI, valorHD);
			return max+arbol.getData();
		}
	}
	
	public static void main(String[] args) {
		RedBinariaLlena obj=new RedBinariaLlena();
		BinaryTree<Integer> arbol=new BinaryTree<>(1);
		BinaryTree<Integer> hijoIzq=new BinaryTree<>(2);
		hijoIzq.addLeftChild(new BinaryTree<Integer>(4));
		hijoIzq.addRightChild(new BinaryTree<Integer>(5));
		arbol.addLeftChild(hijoIzq);
		BinaryTree<Integer> hijoDer=new BinaryTree<>(3);
		hijoDer.addLeftChild(new BinaryTree<Integer>(6));
		hijoDer.addRightChild(new BinaryTree<Integer>(7));
		arbol.addRightChild(hijoDer);
		obj.setArbol(arbol);
		System.out.println(obj.retardoReenvio());
	}
}
