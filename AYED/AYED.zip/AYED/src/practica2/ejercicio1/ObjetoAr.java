package practica2.ejercicio1;

public class ObjetoAr {
	private int suma;
	private int diferencia;
	
	public ObjetoAr() {
		this.suma=0;
		this.diferencia=0;
	}

	public int getSuma() {
		return suma;
	}

	public void setSuma(int suma) {
		this.suma = suma;
	}

	public int getDiferencia() {
		return diferencia;
	}

	public void setDiferencia(int diferencia) {
		this.diferencia = diferencia;
	}
	
	
}
