package practica2.ejercicio1;

public class Transformacion {
	BinaryTree<Integer> arbol;
	
	public Transformacion() {
		
	}
	
	public void setArbol(BinaryTree<Integer> arbol) {
		this.arbol=arbol;
	}
	
	public BinaryTree<Integer> getArbol(){
		return this.arbol;
	}
	
	public BinaryTree<Integer> suma(){
		suma2(this.arbol);
		return this.arbol;	
	}
	
	private int suma2 (BinaryTree<Integer> a){
		int valorHI=0;
		int valorHD=0;
		if(a.isLeaf()) {
			int aux=a.getData();
			a.setData(0);
			return aux;
		}
		else {
			if(a.hasLeftChild()) {
	            valorHI=suma2(a.getLeftChild());
	        }
	        if(a.hasRightChild()) {
	            valorHD=suma2(a.getRightChild());
	        }
			int suma = valorHI+valorHD;
			int act=a.getData();//yo  en mi anterior codigo me estaba olvidand d esto, x eso me daba 0,1,0
			a.setData(suma);
			return suma+act;
		}
	}
	public static void main(String[] args) {
		Transformacion obj=new Transformacion();
		BinaryTree<Integer> arbol=new BinaryTree<>(1);
		BinaryTree<Integer> hijoIzq=new BinaryTree<>(2);
		/*hijoIzq.addLeftChild(new BinaryTree<Integer>(4));
		hijoIzq.addRightChild(new BinaryTree<Integer>(5));*/
		arbol.addLeftChild(hijoIzq);
		BinaryTree<Integer> hijoDer=new BinaryTree<>(3);
		/*hijoDer.addLeftChild(new BinaryTree<Integer>(6));
		hijoDer.addRightChild(new BinaryTree<Integer>(7));*/
		arbol.addRightChild(hijoDer);
		obj.setArbol(arbol);
		obj.suma();
		obj.getArbol().imprimirArbol();
	}
}
