package practica2.ejercicio1;

import java.util.LinkedList;
import java.util.Queue;

public class ParcialArboles {
	private BinaryTree<Integer> arbol;
	
	public ParcialArboles() {
		
	}
	
	public void setArbol(BinaryTree<Integer> arbol) {
		this.arbol=arbol;
	}
	
	public BinaryTree<Integer> getArbol(){
		return this.arbol;
	}
	
	/*public boolean isLeftTree(int num) {
		if(aux(this.arbol,num)=0) {
			return false;
		}else return true;
	}
	
	private int aux(BinaryTree<Integer> arbol,int num) {
		int cantUniHI=0;
		int cantUniHD=0;
		if(((arbol.hasLeftChild())&&(!arbol.hasRightChild())&&(){
			return 1;
		}
		else
			if(((arbol.hasRightChild())&&(!arbol.hasLeftChild()))){
				return 1;
			}
		if(arbol.getData()==num) {
			if(((arbol.hasLeftChild())&&(!arbol.hasRightChild())){
				cantUniHD=-1;
				cantUniHI+=isLeftTree(arbol.getLeftChild());
			}
			else if(((arbol.hasRightChild())&&(!arbol.hasLeftChild()))){
				cantUniHI=-1;
				cantUniHD+=1;
				isLeftTree(arbol.getRightChild())
			}		
		}
		else if(arbol.
		else {
			//recorre hasta que encuentres el nodo
			isLeftTree(arbol.getLeftChild());
			isLeftTree(arbol.getRightChild());
			return 0;/devuevlo 0 porque no se encontro num, para q desp devuelva false
		}
	}
	private int aux(BinaryTree<Integer> arbol,int num) {
		int cantUniHI=0;
		int cantUniHD=0;
		if(arbol.getData()==num){//entra solo una vez aca
			if(((arbol.hasLeftChild())&&(!arbol.hasRightChild())){
				cantUniHD=-1;
				cantUniHI=recursionBase(arbol.getLeftChild());
			}
			else if(((arbol.hasRightChild())&&(!arbol.hasLeftChild()))){
				cantUniHI=-1;
				cantUniHD=recursionBase(arbol.getRightChild());
			}
			 return recursionBase(arbol);
		}
		else {
			aux(arbol.getLeftChild());
			aux(arbol.getRightChild());
			return 0;
		}
	}
	private int recursionBase (BinaryTree<Integer> arbol){
		int cant=0;
		if(((arbol.hasLeftChild())&&(!arbol.hasRightChild())){
			cant+=recursionBase(arbol.getLeftChild())+1;
		}
		else if(((arbol.hasRightChild())&&(!arbol.hasLeftChild()))){
				cant+=recursionBase(arbol.getRightChild())+1;
			} 	
		if(arbol.hasLeftChild()){
			recursionBase(arbol.getLeftChild());
		}
		if(arbol.hasRightChild()){
			recursionBase(arbol.getRightChild());
		}
		return cant;
	}
	*/
	
	//como ya pasan los arboles como parametro no es necesario hacer metodos privados
	public boolean esPrefijo(BinaryTree<Integer> arbol1,BinaryTree<Integer> arbol2) {
		boolean izq=true;
		boolean der=true;
		if(arbol1.getData()!=arbol2.getData()) {
			return false;
		}
		else {
			if(arbol1.hasLeftChild()&&arbol2.hasLeftChild()) {
				izq=esPrefijo(arbol1.getLeftChild(), arbol2.getLeftChild());
			}
			if(arbol1.hasRightChild()&&arbol2.hasRightChild()) {
				der=esPrefijo(arbol1.getRightChild(), arbol2.getRightChild());
			}
			if(izq==der) {
				return true;
			}
			else
				return false;
		}
	}
	
	public BinaryTree<ObjetoAr> sumAndDif(BinaryTree<Integer> arbol){
		int antSum=0;
		int antDif=0;
		BinaryTree<ObjetoAr> nuevo = new BinaryTree<ObjetoAr>();
		aux(arbol,nuevo,antSum,antDif);
		return nuevo;
	  }
	  
	  private void aux (BinaryTree<Integer> arbol,BinaryTree<ObjetoAr> nuevo, int antSum,int antDif){
		int suma=antSum+arbol.getData();
		int diferencia=arbol.getData()-antDif;
		ObjetoAr objeto = new ObjetoAr();
		objeto.setSuma(suma);
		objeto.setDiferencia(diferencia);
		nuevo.setData(objeto);
		if(arbol.hasLeftChild()){
			nuevo.addLeftChild(new BinaryTree<ObjetoAr>());
			aux(arbol.getLeftChild(),nuevo.getLeftChild(),suma,arbol.getData());
		}
		if(arbol.hasRightChild()){
			nuevo.addRightChild(new BinaryTree<ObjetoAr>());
			aux(arbol.getRightChild(),nuevo.getRightChild(),suma,arbol.getData());
		}
	}
	
	public void imprimirArbolObj(BinaryTree<ObjetoAr> arbol) {
		System.out.println("suma: "+arbol.getData().getSuma() + " resta: "+arbol.getData().getDiferencia());
	    if(arbol.hasLeftChild()) imprimirArbolObj(arbol.getLeftChild());
	    if(arbol.hasRightChild()) imprimirArbolObj(arbol.getRightChild());
	}
	public static void main(String[] args) {
		ParcialArboles obj=new ParcialArboles();
		/*BinaryTree<Integer> arbol1=new BinaryTree<>(65);
		BinaryTree<Integer> hijoIzq1=new BinaryTree<>(37);
		hijoIzq1.addRightChild(new BinaryTree<Integer>(47));
		arbol1.addLeftChild(hijoIzq1);
		BinaryTree<Integer> hijoDer1=new BinaryTree<>(81);
		hijoDer1.addRightChild(new BinaryTree<Integer>(93));
		arbol1.addRightChild(hijoDer1);
		BinaryTree<Integer> arbol2=new BinaryTree<>(65);
		BinaryTree<Integer> hijoIzq=new BinaryTree<>(37);
		hijoIzq.addLeftChild(new BinaryTree<Integer>(22));
		hijoIzq.addRightChild(new BinaryTree<Integer>(47));
		arbol2.addLeftChild(hijoIzq);
		BinaryTree<Integer> hijoDer=new BinaryTree<>(81);
		hijoDer.addLeftChild(new BinaryTree<Integer>(76));
		hijoDer.addRightChild(new BinaryTree<Integer>(93));
		arbol2.addRightChild(hijoDer);
		System.out.println(obj.esPrefijo(arbol1, arbol2));*/
		
		BinaryTree<Integer> arbol=new BinaryTree<>(20);
		BinaryTree<Integer> hijoIzq=new BinaryTree<>(5);
		hijoIzq.addLeftChild(new BinaryTree<Integer>(-5));
		hijoIzq.addRightChild(new BinaryTree<Integer>(10));
		arbol.addLeftChild(hijoIzq);
		BinaryTree<Integer> hijoDer=new BinaryTree<>(30);
		hijoDer.addLeftChild(new BinaryTree<Integer>(50));
		hijoDer.addRightChild(new BinaryTree<Integer>(-9));
		arbol.addRightChild(hijoDer);
		BinaryTree<ObjetoAr>nuevo=obj.sumAndDif(arbol);
		obj.imprimirArbolObj(nuevo);
	}
}
