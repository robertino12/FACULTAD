package practica2.ejercicio1;

import java.util.*;

public class BinaryTree<T> {
	private T data;
	private BinaryTree<T> leftChild;
	private BinaryTree<T> rightChild;
	
	public BinaryTree(T data) {
		this.data=data;
		this.leftChild=null;
		this.rightChild=null;
	}

	public BinaryTree() {}
	
	public T getData() {
		return this.data;
	}
	
	public void setData(T data) {
		this.data=data;
	}
	
	public BinaryTree<T> getLeftChild(){
		return this.leftChild;
	}
	
	public BinaryTree<T> getRightChild(){
		return this.rightChild;
	}
	
	public void addLeftChild(BinaryTree<T> child) {
		this.leftChild=child;
	}
	
	public void addRightChild(BinaryTree<T> child) {
		this.rightChild=child;
	}
	
	public void removeLeftChild() {
		this.leftChild=null;
	}
	
	public void removeRightChild() {
		this.rightChild=null;
	}
	
	public boolean isEmpty() {
		return (this.isLeaf()&&this.getData()==null);
	}
	
	public boolean isLeaf() {
		return (!this.hasLeftChild()&&!this.hasRightChild());
	}
	
	public boolean hasLeftChild() {
		return this.leftChild!=null;
	}
	
	public boolean hasRightChild() {
		return this.rightChild!=null;
	}
	
	public int contarHojas() {
		int hojasIzq=0;
		int hojasDer=0;
		if(this.isEmpty()) return 0;//analizamos caso nodo vacio
		else if(this.isLeaf()) return 1;//analizamos si es hoja
		else {
			if(this.hasLeftChild()) {
				hojasIzq=this.leftChild.contarHojas();//lo q retorna se va acumulando en las var
			}
			if(this.hasRightChild()) {
				hojasDer=this.rightChild.contarHojas();
			}
		}
		return hojasIzq+hojasDer;
	}
	
	public void imprimirArbol() {
        if(this.hasLeftChild()) this.getLeftChild().imprimirArbol();
        System.out.print(this.getData() + " ");
        if(this.hasRightChild()) this.getRightChild().imprimirArbol();
    }
	
	
	public BinaryTree<T> espejo(){
		BinaryTree<T> nuevo= new BinaryTree<T>(this.getData());//crea nodo nuevo con valor de la instancia objeto de tipo arbol que llama
		if(this.hasLeftChild()) {//pregunta si tiene hijo izq
			nuevo.addRightChild(this.getLeftChild().espejo());//si tiene hijo izq agregar en el nuevo el izq pro en la derecha
		}
		if(this.hasRightChild()) {//pregunta si tiene hijo derecho
			nuevo.addLeftChild(this.getRightChild().espejo());//si tiene derecho, agregalo en el nuevo pero a la izq
		}
		return nuevo;//una vez q vuelve a la raiz retorna el nuevo
	}
	
	public void entreNiveles (int n,int m) { 
		if(n<0 || m<n) {
			System.out.println("parametros incorrectos");
		}else {
			int nivel=0;
			BinaryTree<T> arbol=null;
			Queue<BinaryTree<T>> cola=new LinkedList<>();
			cola.add(this);
			cola.add(null);
			while(nivel<=m) {
					arbol=cola.remove();
					if(arbol!=null) {
						if(nivel>=n)System.out.println(arbol.getData());
						if(arbol.hasLeftChild()) cola.add(arbol.getLeftChild());
						if(arbol.hasRightChild()) cola.add(arbol.getRightChild());
					}
					else if(!cola.isEmpty()) {
						System.out.println();
						cola.add(null);
						nivel++;
					}
					else if(cola.isEmpty())nivel++;
					//este else es para cuando pones de un nivel X al ultimo en los param
					//xq sino queda en un while infinito y entra en error ya que
					//intenta remover de la cola cuando no hay mas, porque cuando llega al ultimo, remueve null
					//y cuando va al else la cola es vacia entonces no entra, por lo tanto el nivel no se aumenta
			}
		}
	}
	
	public static void main(String[] args) {
		BinaryTree<Integer> arbol=new BinaryTree<>(1);
		BinaryTree<Integer> hijoIzq=new BinaryTree<>(2);
		hijoIzq.addLeftChild(new BinaryTree<Integer>(4));
		hijoIzq.addRightChild(new BinaryTree<Integer>(5));
		BinaryTree<Integer> hijoDer=new BinaryTree<>(3);
		hijoDer.addLeftChild(new BinaryTree<Integer>(6));
		hijoDer.addRightChild(new BinaryTree<Integer>(7));
		arbol.addLeftChild(hijoIzq);
		arbol.addRightChild(hijoDer);
		System.out.println("arbol comun");
		arbol.imprimirArbol();
		System.out.println("arbol espejo");
		BinaryTree<Integer> ab=arbol.espejo();
		ab.imprimirArbol();
		System.out.println("arbol niveles");
		arbol.entreNiveles(0, 1);
	}
}
