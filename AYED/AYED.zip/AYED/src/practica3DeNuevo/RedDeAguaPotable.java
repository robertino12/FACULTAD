package practica3DeNuevo;

import java.util.LinkedList;
import java.util.List;

import practica3.GeneralTree;


public class RedDeAguaPotable {
	private GeneralTree<Character> a;
	
	public RedDeAguaPotable(GeneralTree<Character>a) {
		this.a=a;
	}
	
	public double minimoCaudal(double caudal) {
		double minimo=10000;
		if(!this.a.isEmpty()) {
			minimo=minimoCaudal(caudal,this.a);
		}
		return minimo;
	}
	
	private double minimoCaudal(double caudal,GeneralTree<Character> a) {
		if(a.isLeaf()) {
			return caudal;
		}
		else {
			double minCaudal=10000;
			for(GeneralTree<Character> child:a.getChildren()) {
				minCaudal=Math.min(minimoCaudal((caudal/a.getChildren().size()),child), minCaudal);
			}
			return minCaudal;
		}
	}
	
	public static void main(String[] args) {
		List<GeneralTree<Character>> hijos2=new LinkedList<GeneralTree<Character>>();
		hijos2.add(new GeneralTree<Character>('D'));
		GeneralTree<Character> padre1=new GeneralTree<Character>('B',hijos2);
		List<GeneralTree<Character>> hijos4=new LinkedList<GeneralTree<Character>>();
		hijos4.add(new GeneralTree<Character>('I'));
		hijos4.add(new GeneralTree<Character>('J'));
		GeneralTree<Character> padre3=new GeneralTree<Character>('E',hijos4);
		List<GeneralTree<Character>> hijos3=new LinkedList<GeneralTree<Character>>();
		hijos3.add(padre3);
		hijos3.add(new GeneralTree<Character>('F'));
		hijos3.add(new GeneralTree<Character>('G'));
		hijos3.add(new GeneralTree<Character>('H'));
		GeneralTree<Character> padre2=new GeneralTree<Character>('C',hijos3);
		List<GeneralTree<Character>> hijos1=new LinkedList<GeneralTree<Character>>();
		hijos1.add(padre1);
		hijos1.add(padre2);
		GeneralTree<Character> padre=new GeneralTree<Character>('A',hijos1);
		RedDeAguaPotable obj=new RedDeAguaPotable(padre);
		System.out.println(obj.minimoCaudal(1500));
	}
}
