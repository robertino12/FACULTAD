package practica3DeNuevo;

import java.util.LinkedList;
import java.util.List;

import practica3.GeneralTree;

public class Altura {
	public int altura(GeneralTree<Integer> a) {
		int alt=0;
		if(!a.isEmpty()) {
			alt=altura(a,0);
		}
		return  alt;
	}
	
	private int altura(GeneralTree<Integer> a,int longitud) {
		if(a.isLeaf()) {
			return longitud;
		}
		else {
			int maxLongitud=-1;
			List<GeneralTree<Integer>> children=a.getChildren();
			for(GeneralTree<Integer> hijo:children) {
				maxLongitud=Math.max(altura(hijo,longitud+1),maxLongitud);
			}
			return maxLongitud;
		}
	}
	
	public static void main(String[] args) {
		List<GeneralTree<Integer>>c1=new LinkedList<GeneralTree<Integer>>();
		c1.add(new GeneralTree<Integer>(6));
		c1.add(new GeneralTree<Integer>(11));
		GeneralTree<Integer> p1=new GeneralTree<Integer>(8,c1);
		List<GeneralTree<Integer>>c3=new LinkedList<GeneralTree<Integer>>();
		c3.add(new GeneralTree<Integer>(15));
		GeneralTree<Integer> p4=new GeneralTree<Integer>(12,c3);
		List<GeneralTree<Integer>>c2=new LinkedList<GeneralTree<Integer>>();
		c2.add(p4);
		c2.add(new GeneralTree<Integer>(13));
		GeneralTree<Integer> p2=new GeneralTree<Integer>(5,c2);
		GeneralTree<Integer> p3=new GeneralTree<Integer>(9);
		List<GeneralTree<Integer>> c0=new LinkedList<GeneralTree<Integer>>();
		c0.add(p1);
		c0.add(p2);
		c0.add(p3);
		GeneralTree<Integer> p0=new GeneralTree<Integer>(7,c0);
		
		Altura obj=new Altura();
		System.out.println(obj.altura(p0));
	}
}
