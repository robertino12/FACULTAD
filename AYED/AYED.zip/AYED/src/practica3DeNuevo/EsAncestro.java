package practica3DeNuevo;

import java.util.LinkedList;
import java.util.List;

import practica3.GeneralTree;

public class EsAncestro {
	public boolean esAncestro(int a, int b, GeneralTree<Integer> arbol) {
		boolean es=false;
		if(!arbol.isEmpty()) {
			GeneralTree<Integer> nodoA=buscarA(a,arbol);
			if(nodoA!=null) {
				es=esAncestro(nodoA,b);
			}
		}
		return es;
	}
	
	private boolean esAncestro(GeneralTree<Integer> a,int b) {
		if(a.getData()==b) {
			return true;
		}
		else {
			boolean es=false;
			for(GeneralTree<Integer> child:a.getChildren()) {
				es=esAncestro(child,b);
				if(es) {
					return es;
				}
			}
		}
		return false;
	}
	
	private GeneralTree<Integer> buscarA(int a,GeneralTree<Integer> arbol){
		if(a==arbol.getData()) {
			return arbol;
		}
		else {
			GeneralTree<Integer> nodo=null;
			for(GeneralTree<Integer> child:arbol.getChildren()) {
				nodo=buscarA(a,child);
				if(nodo!=null) {
					return nodo;
				}
			}
		}
		return null;
	}
	
	public static void main(String[] args) {
		List<GeneralTree<Integer>>c1=new LinkedList<GeneralTree<Integer>>();
		c1.add(new GeneralTree<Integer>(6));
		c1.add(new GeneralTree<Integer>(11));
		GeneralTree<Integer> p1=new GeneralTree<Integer>(8,c1);
		List<GeneralTree<Integer>>c3=new LinkedList<GeneralTree<Integer>>();
		c3.add(new GeneralTree<Integer>(15));
		GeneralTree<Integer> p4=new GeneralTree<Integer>(12,c3);
		List<GeneralTree<Integer>>c2=new LinkedList<GeneralTree<Integer>>();
		c2.add(p4);
		c2.add(new GeneralTree<Integer>(13));
		GeneralTree<Integer> p2=new GeneralTree<Integer>(5,c2);
		GeneralTree<Integer> p3=new GeneralTree<Integer>(9);
		List<GeneralTree<Integer>> c0=new LinkedList<GeneralTree<Integer>>();
		c0.add(p1);
		c0.add(p2);
		c0.add(p3);
		GeneralTree<Integer> p0=new GeneralTree<Integer>(7,c0);
		EsAncestro obj=new EsAncestro();
		System.out.println(obj.esAncestro(7, 17, p0));
	}
}
