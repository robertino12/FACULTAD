package parcial8;

import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;

import practica5.ejercicio1Grafo.Edge;
import practica5.ejercicio1Grafo.Graph;
import practica5.ejercicio1Grafo.Vertex;
import practica5.ejercicio1Grafo.adjList.AdjListGraph;

public class Parcial {//empece 00:50 termine 1:11
	public List<String> caminoConPresupuesto(Graph<String> ciudades,String origen,String destino,int montoMinimo){
		List<String> camino=new LinkedList<String>();
		if(!ciudades.isEmpty()) {
			Vertex<String> ori=ciudades.search(origen);
			Vertex<String> dest=ciudades.search(destino);
			if(ori!=null&&dest!=null) {
				int pesosGastados=0;
				caminoConPresupuesto(ciudades,ori,destino,montoMinimo,camino,pesosGastados,new boolean[ciudades.getSize()]);
			}
		}
		return camino;
	}
	
	private boolean caminoConPresupuesto(Graph<String> ciudades, Vertex<String> v, String destino, int montoMinimo, List<String> camino,int pesosGastados, boolean[]visitados) {
		visitados[v.getPosition()]=true;
		camino.add(v.getData());
		boolean encontre=false;
		if(v.getData().equals(destino)&&pesosGastados>montoMinimo) { 
			return true;
		}
		else {
			List<Edge<String>> ady=ciudades.getEdges(v);
			Iterator<Edge<String>> it=ady.iterator();
			while(it.hasNext()&&!encontre){
				Edge<String> arista=it.next();
				int aux=pesosGastados+arista.getWeight();
				if(!visitados[arista.getTarget().getPosition()]) {
					encontre=caminoConPresupuesto(ciudades,arista.getTarget(),destino,montoMinimo,camino,aux,visitados);
				}
			}
			if(!encontre) {
				visitados[v.getPosition()]=false;
				camino.remove(camino.size()-1);
			}
		}
		return encontre;
	}
	
	public static void main(String args[]) {
        Graph<String> grafo = new AdjListGraph<String>();
        Vertex<String> v1 = grafo.createVertex("Lincoln");
        Vertex<String> v2 = grafo.createVertex("Chascomús");
        Vertex<String> v3 = grafo.createVertex("Cañuelas");
        Vertex<String> v4 = grafo.createVertex("Dolores");
        Vertex<String> v5 = grafo.createVertex("Verónica");
        Vertex<String> v6 = grafo.createVertex("Villa Urquiza");
        Vertex<String> v7 = grafo.createVertex("Ranchos");
        Vertex<String> v8 = grafo.createVertex("Berisso");
        
        grafo.connect(v1, v2, 70);
        grafo.connect(v2, v1, 70);
        grafo.connect(v1, v3, 50);
        grafo.connect(v3, v1, 50);
        grafo.connect(v1, v4, 90);
        grafo.connect(v4, v1, 90);
        grafo.connect(v2, v5, 80);
        grafo.connect(v5, v2, 80);
        grafo.connect(v2, v6, 60);
        grafo.connect(v6, v2, 60);
        grafo.connect(v3, v5, 85);
        grafo.connect(v5, v3, 85);
        grafo.connect(v3, v7, 90);
        grafo.connect(v7, v3, 90);
        grafo.connect(v4, v6, 70);
        grafo.connect(v6, v4, 70);
        grafo.connect(v4, v7, 70);
        grafo.connect(v7, v4, 70);
        grafo.connect(v5, v8, 60);
        grafo.connect(v8, v5, 60);
        grafo.connect(v6, v8, 90);
        grafo.connect(v8, v6, 90);
        grafo.connect(v7, v8, 75);
        grafo.connect(v8, v7, 75);
        
        Parcial p = new Parcial();
        
        System.out.println(p.caminoConPresupuesto(grafo, "Lincoln", "Berisso", 200));
    }
}
