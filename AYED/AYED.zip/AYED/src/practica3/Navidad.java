package practica3;

import java.util.LinkedList;
import java.util.List;

public class Navidad {
	private GeneralTree<Integer> abeto;
	
	public Navidad (GeneralTree<Integer> abeto) {
		this.abeto=abeto;
	}
	
	public String esAbetoNavidenio() {
		GeneralTree<Integer> a=this.abeto;
		return a!=null&&!a.isEmpty()? esAbetoNavidenio(a):"arbol incorrecto";
	}
	

	private String esAbetoNavidenio(GeneralTree<Integer> a) {
		String es="yes";
		int cantNodos=0;
		List<GeneralTree<Integer>> hijos=a.getChildren();
		for(GeneralTree<Integer> hijo:hijos) {
			if(hijo.isLeaf()) {
				cantNodos++;
			}
			else {
				es=esAbetoNavidenio(hijo);
			}
			if(es.equals("no")) {
				return es;
			}
		}
		return cantNodos>=3?"yes":"no";
	}//no entiendo bien x q anda c abeto q tiene 3 hijos y cada uno c 3 hijos, si al raiz no se le aumenta la cant d nodos, tonce tiene 0
	
	/*private boolean isAbeto(GeneralTree<Integer> ab) {
        int nodosHoja = 0;
        for(GeneralTree<Integer> h: ab.getChildren()) {
            if(h.isLeaf()) nodosHoja++;
            else if(!isAbeto(h)) return false;
        }
        return nodosHoja >= 3;
    }*///este es el d matias guaymas no entiend x q le da bien
	
	public static void main(String[] args) {
		List<GeneralTree<Integer>> subArb1 = new LinkedList<GeneralTree<Integer>>();
	    subArb1.add(new GeneralTree<Integer>(2));
	    subArb1.add(new GeneralTree<Integer>(3));
	    subArb1.add(new GeneralTree<Integer>(4));
	    GeneralTree<Integer> a1 = new GeneralTree<Integer>(1, subArb1);
	    
	    List<GeneralTree<Integer>> subArb2A = new LinkedList<GeneralTree<Integer>>();
	    subArb2A.add(new GeneralTree<Integer>(5));
	    subArb2A.add(new GeneralTree<Integer>(6));
	    subArb2A.add(new GeneralTree<Integer>(7));
	    GeneralTree<Integer> subA2 = new GeneralTree<Integer>(2, subArb2A);
	    List<GeneralTree<Integer>> subArb2B = new LinkedList<GeneralTree<Integer>>();
	    subArb2B.add(subA2);
	    subArb2B.add(new GeneralTree<Integer>(3));
	    subArb2B.add(new GeneralTree<Integer>(4));
	    GeneralTree<Integer> a2 = new GeneralTree<Integer>(1, subArb2B);
	    
	    List<GeneralTree<Integer>> subArb3A = new LinkedList<GeneralTree<Integer>>();
	    subArb3A.add(new GeneralTree<Integer>(6));
	    subArb3A.add(new GeneralTree<Integer>(7));
	    subArb3A.add(new GeneralTree<Integer>(8));
	    GeneralTree<Integer> subA3 = new GeneralTree<Integer>(3, subArb3A);
	    List<GeneralTree<Integer>> subArb3B = new LinkedList<GeneralTree<Integer>>();
	    subArb3B.add(new GeneralTree<Integer>(2));
	    subArb3B.add(subA3);
	    subArb3B.add(new GeneralTree<Integer>(4));
	    subArb3B.add(new GeneralTree<Integer>(5));
	    GeneralTree<Integer> a3 = new GeneralTree<Integer>(1, subArb3B);
	    
	    Navidad nav1 = new Navidad(a1);
	    Navidad nav2 = new Navidad(a2);
	    Navidad nav3 = new Navidad(a3);
	    
	    System.out.println("Es abeto navidenio A1? " + nav1.esAbetoNavidenio());
	    System.out.println("Es abeto navidenio A2? " + nav2.esAbetoNavidenio());
	    System.out.println("Es abeto navidenio A3? " + nav3.esAbetoNavidenio());
	}
}
