package practica3;

import java.util.LinkedList;
import java.util.List;
import tp1.ejercicio8.Queue;

public class GeneralTree<T> {
	private T data;
	private List<GeneralTree<T>> children = new LinkedList<GeneralTree<T>>();
	
public GeneralTree() {}

public GeneralTree(T data) {
	this.data=data;
}

public GeneralTree(T data,List<GeneralTree<T>> children) {
	this(data);//hace el constructor de arriba, osea crea un arbol con valor en la raiz y en los hijos
	this.children=children;
}

public T getData() {
	return this.data;
}

public void setData(T data) {
	this.data=data;
}

public List<GeneralTree<T>> getChildren(){
	return this.children;
}

public void setChildren(List<GeneralTree<T>> children) {
	if(children!=null) {//tiene q poner esto, xq si pasamos una lista null y desp hacemos agregar hijo, y accede a getChildren y quiere agregar y tiene null, va a dar error
		this.children=children;
	}
}

public void addChild(GeneralTree<T> child) {
	this.getChildren().add(child);
}

public boolean hasChildren() {
	return this.children!=null && !this.children.isEmpty();//este isEmpty es d la lista no del metodo de abajo del arbol
}

public boolean isLeaf() {

	return !this.hasChildren();//osea hasChildren tiene q dar false y con el ! lo transforma a verdadero, retornadno true osea es hoja
}

public boolean isEmpty() {
	return data==null && !this.hasChildren();//lo mismo q poner this.hasChildren()==false
}

public void removeChild(GeneralTree<T> child) {
	if(this.hasChildren()) {
		this.children.remove(child);
	}
}

public List<Integer> numerosImparesMayoresQuePreOrden(Integer n){
	List<Integer> listaPre=new LinkedList<Integer>();
	if(this!=null){//sino pongo este y m mandan null, cuando yo ingrese al helper y haga a.getData va a dar error ya q a apunta a null
		if(!this.isEmpty()) {//ak lo mismo, si es vacio y entra helper da error
			this.numerosImparesMayoresQuePreOrden(n,listaPre);
		}
	}
	return listaPre;//si el arbol esta vacio devulev lista vacia
}

private void numerosImparesMayoresQuePreOrden(Integer n,List<Integer> listaPre) {
	if((Integer)this.getData()>n) { //sino pongo (Integer) me toma que estoy comparando un objeto de tipo T con un Integer, x lo tanto tengo que hacer downcasting, para que lo vea como un Integer
		if(((Integer)this.getData()%2)!=0) {
			listaPre.add((Integer)this.getData());
		}
	}//como da igual si es mayor o no tiene q seguir c el recorrido entonces no se pone else, se sigue
	//tomamos los hijos
	List<GeneralTree<T>> children=this.getChildren();//lo tengo que poner de tipo T y luego con cada dato hago el downCasting, no puedo poner (Integer)lista, no puedo pasar una lista a Integer xq no hay relacion, en cambio en T e Integer hay herencia
	for(GeneralTree<T> child: children) {
		child.numerosImparesMayoresQuePreOrden(n,listaPre);
	}
}

public int altura() {//preguntar xq con mi arbol q a partir de la raiz tengo 3 hijos en el camino max, devulve altura 3, y creo q deberia dar 4
    return (!this.isEmpty()) ? alturaHelper() : -1;
}

private int alturaHelper() {
    if(this.isLeaf()) return 0;
    else {
        int alturaMax = -1;
        List<GeneralTree<T>> children = this.getChildren();
        for(GeneralTree<T> child: children) {
            alturaMax = Math.max(alturaMax, child.alturaHelper());
        }
        return alturaMax + 1;
    }
}

//nivel haciendolo con recursion
public int nivelRecu(T dato) {
	if(this!=null) {
		if(!this.isEmpty()) {
			return nivelHelper(dato,0);
		}
	}
	return -1;
}

public int nivelHelper(T dato,int nivel) {
	if(this.getData()==dato) {
		return nivel;
	}
	else {
		if(this.isLeaf()) {//retorna -1 cuando llega a una hoja
			return -1;
		}
		else {
			List<GeneralTree<T>> l= this.getChildren();
			for(GeneralTree<T> child: l) {
				int altura=child.nivelHelper(dato,nivel+1);
				if(altura!=-1) {//altura solo va devolver distinto de -1 cuando lo encuentre
					return altura;//si llega a la raiz con disntito de -1 termina todo y devuelve nivel
				}
			}
		}
	}
	return 0;//esto es xq pide retornar, sino la otra forma es aca retornar -1, q seria cuando es hoja, osea sacaria el primer else
}

//nivel con recorrido niveles
public int nivel(T dato) {
	int nivel=0;
	GeneralTree<T> arbAux;
	Queue<GeneralTree<T>> cola=new Queue<GeneralTree<T>>();
	if(this!=null) {
		if(!this.isEmpty()) {
			cola.enqueue(this);
			cola.enqueue(null);
		}
	}
	while(!cola.isEmpty()) {
		arbAux=cola.dequeue();
		if(arbAux!=null) {
			if(arbAux.getData().equals(dato)) {
				return nivel;
			}
			List<GeneralTree<T>> l=arbAux.getChildren();
			for(GeneralTree<T> child: l) {
				cola.enqueue(child);
			}
		}
		else {
			if(!cola.isEmpty()) {//osea estoy en null
				cola.enqueue(null);
				nivel++;
			}
		}
	}
	return -1;//sino esta devuelve -1
}

public int ancho() {//hay q recorrer todos los niveles para saber donde esta la mayor cantidad de nodos
	int maxNodos=-1;
	Queue <GeneralTree<T>> cola= new Queue<GeneralTree<T>>();
	if(this!=null) {
		if(!this.isEmpty())
			cola.enqueue(this);
			cola.enqueue(null);
	}
	int cant=1;
	if(cant>maxNodos) {
		maxNodos=cant;
	}
	cant=0;
	while(!cola.isEmpty()) {
		GeneralTree<T> arbAux=cola.dequeue();
		if(arbAux!=null) {
			List<GeneralTree<T>> hijos=arbAux.getChildren();
			for(GeneralTree<T> hijo:hijos) {
				cola.enqueue(hijo);
				cant++;
			}
		}
		else {
			if(cant>maxNodos) {
					maxNodos=cant;
			}//sino lo pongo aca no me va a hacer el ultimo nivel, ya q la cola va a estar vacia
			if(!cola.isEmpty()) {//cuando termino el nivel, osea null, hace el max
				cola.enqueue(null);
				cant=0;//cuando cambia de nivel ponemos cant en 0 para resetear el cant por cada nivel
			}
		}
	}
	return maxNodos;
}

//primero tengo q buscar a, si a no esta no tiene sentido que recorre por b
//y tengo que devolver a asi en el otro privado empiezo a buscar desde ese nodo
public boolean esAncestro(T a,T b) {
	GeneralTree<T> esA=encontrarAAntesQueB(a,b);
	if(esA==null) {//xq sino esta A devuleve null, x ende hay q preg esto
		return false;
	}
	else
		if(esA.getData().equals(b)){
			return false;
	}//osea si lo q devuelve eso es b, es xq antes esta B
	return esAncestro(esA,b);//preg el !=null xq puede q A no este
}
private GeneralTree<T> encontrarAAntesQueB(T a,T b){
	if(this.getData().equals(a)||this.getData().equals(b)) {
		return this;//si es A o es B que devuelva el nodo, yo desp veo en el publico cual es
	}
	else {
		List<GeneralTree<T>> hijos=this.getChildren();
		for(GeneralTree<T> hijo:hijos) {
			GeneralTree<T> encontro=hijo.encontrarAAntesQueB(a,b);
			if(encontro!=null) {//cuando sea distinto de null es xq lo encontro
				return encontro;
			}
		}
	}
	return null;//cuando llega a hoja y no lo encuentra retorna null
}
private boolean esAncestro(GeneralTree<T> a,T b) {
	if(a.getData().equals(b)) {
		return true;
	}
	else {
		List<GeneralTree<T>> hijos=a.getChildren();
		for(GeneralTree<T> hijo:hijos) {
			 boolean encontroB=esAncestro(hijo, b);
			 if(encontroB) {
				 return true;
			 }
		}
	}
	return false;
}

}
