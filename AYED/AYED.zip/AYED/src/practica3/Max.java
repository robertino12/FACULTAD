package practica3;

public class Max {
	 private int max;
	    public Max(int valor) {
	        this.max = valor;
	    }

	    public int getMax() {
	        return max;
	    }

	    public void setMax(int max) {
	        this.max = max;
	    }
}
