package practica3;

import java.util.LinkedList;
import java.util.List;

import tp1.ejercicio8.Queue;

public class ParcialArboles {
	
	public static boolean esDeSeleccion(GeneralTree<Integer> arbol) {
		Integer valorPadre=0;
		return esDeSeleccion(arbol,valorPadre);
	}
	
	private static boolean esDeSeleccion(GeneralTree<Integer> arbol,Integer valorPadre) {
		boolean es=false;
		if(arbol.getData()>=valorPadre) {
			es=true;
		}
		if(es==true) {//xq si ya el primer hijo es menor, que pare
			List<GeneralTree<Integer>> hijos=arbol.getChildren();
			for(GeneralTree<Integer> hijo:hijos) {
				es=esDeSeleccion(hijo,arbol.getData());
				if(es==false) return es;//ponele q el primer hijo izq es 8
				//devuelve false a la raiz, si recibio false q retorne false, no q vaya al sig hijo xq capaz retorna true
			}
		}
		return es;//si es hoja retorna es y si un nodo no tiene mas hijos x recorrer tamb va a llegar ak a retornar es
		//siempre van a llegar ak todos los nodos, la unica manera q no es cuando es sea false
	}
	
	public static List<Integer> resolver(GeneralTree<Integer> arbol){
		int nivel=0;
		List<Integer> listMax=new LinkedList<Integer>();
		List<Integer> caminoAct=new LinkedList<Integer>();
		int valoresMulti=0;
		Max maxValoresMulti= new Max(-1);
		resolver(arbol,caminoAct,listMax,nivel,valoresMulti,maxValoresMulti);
		return listMax;
	}
	
	private static void resolver(GeneralTree<Integer> arbol,List<Integer> caminoAct,List<Integer> listMax,int nivel,int valoresMulti,Max maxValoresMulti){
		if(arbol.getData()==1) {
			caminoAct.add(arbol.getData());
		}
		//como si es 0 igual tiene q agarrar hijos no ponemos else
		valoresMulti+=arbol.getData()*nivel;
		List<GeneralTree<Integer>> hijos=arbol.getChildren();
		for(GeneralTree<Integer> hijo:hijos) {
			resolver(hijo,caminoAct,listMax,nivel+1,valoresMulti,maxValoresMulti);
		}
		//una vez q llegamos a la hoja, ya q no va a entrar al for
		//actualizamos lista max y camino act
		if(arbol.isLeaf()) {
			if(valoresMulti>maxValoresMulti.getMax()) {
				maxValoresMulti.setMax(valoresMulti);
				listMax.removeAll(listMax);
				listMax.addAll(caminoAct);
			}
		}
		if(arbol.getData()==1)//sino preguntamos esto, elimina mal, si nosotros solo estamos agregando cuando el dato del arbol
			//es 1, tamb tenemos q eliminar cuando es 1, sino elimminamos cualq cosa
			caminoAct.remove(caminoAct.size()-1);
	}
	//LO HABIA HECHO CASI IGUAL PERFECTO, SOLO Q EL PUSO EL MAXIMO COMO OBJETO ASI X CADA RECURSIVIDAD SE MANTENIA EL VALOR, YA QUE INT SIEMPRE SE PASA POR COPIA EL VALOR Y LOS OBJETOS UNA COPIA DE LA REFERENCIA, ENTONCES SE MANTIENE
		//OTRA COSA Q MODIFIQUE X CHAT GPT ES A LO ULTIMO PONER LA CONDICION DE ELIMINAR SI ES 1 Y LO DE SI ES HOJA
		//XQ YO LO PENSE AL PRINCPIO COMO Q SOLO LOS Q ERAN HOJAS BAJABAN YA Q NO ENTRAN AL FOR, PRO DESP CUANDO SE VUELVE DE LA RECURSION TAMB SE HACE
	
	
	public static boolean resolver11(GeneralTree<Integer> arbol) {
		Queue<GeneralTree<Integer>> cola=new Queue<GeneralTree<Integer>>();
		int cantNodosAnt=0;
		int cantNodosAct=0;
		boolean sigueCreciente=true;
		if(arbol!=null&&!arbol.isEmpty()) {
			cola.enqueue(arbol);
			cola.enqueue(null);
		}
		while(!cola.isEmpty()&&sigueCreciente) {
			GeneralTree<Integer> arbAux=cola.dequeue();
			if(arbAux!=null) {
				cantNodosAct++;
				for(GeneralTree<Integer> hijo:arbAux.getChildren()) {
					cola.enqueue(hijo);
				}
			}
			else {
				if(cantNodosAct!=(cantNodosAnt+1)) {
					sigueCreciente=false;
				}
				else {
					cantNodosAnt=cantNodosAct;
					cantNodosAct=0;
				}
				if(!cola.isEmpty()) {
					cola.enqueue(null);
				}
			}
		}
		return sigueCreciente;
	}
	
	public static void main(String[] args) {
        /*List <GeneralTree<Integer>> subChildren1 = new LinkedList <GeneralTree<Integer>>();
        subChildren1.add(new GeneralTree<Integer>(35));
        GeneralTree<Integer> subAb1 = new GeneralTree<Integer>(35, subChildren1);
        
        List <GeneralTree<Integer>> subChildren2 = new LinkedList <GeneralTree<Integer>>();
        subChildren2.add(subAb1);
        GeneralTree<Integer> subAb2 = new GeneralTree<Integer>(35, subChildren2);
        
        List <GeneralTree<Integer>> subChildren3 = new LinkedList <GeneralTree<Integer>>();
        subChildren3.add(new GeneralTree<Integer>(35));
        subChildren3.add(new GeneralTree<Integer>(83));
        subChildren3.add(new GeneralTree<Integer>(90));
        subChildren3.add(new GeneralTree<Integer>(33));
        GeneralTree<Integer> subAb3 = new GeneralTree<Integer>(33, subChildren3);
        
        List <GeneralTree<Integer>> subChildren4 = new LinkedList <GeneralTree<Integer>>();
        subChildren4.add(new GeneralTree<Integer>(14));
        //subChildren4.add(new GeneralTree<Integer>(12));
        subChildren4.add(new GeneralTree<Integer>(18));
        subChildren4.add(subAb3);
        //GeneralTree<Integer> subAb4 = new GeneralTree<Integer>(12, subChildren4);
        GeneralTree<Integer> subAb4 = new GeneralTree<Integer>(18, subChildren4);
        
        List <GeneralTree<Integer>> subArbIzq = new LinkedList <GeneralTree<Integer>>();
        subArbIzq.add(subAb2);
        subArbIzq.add(subAb4);
        GeneralTree<Integer> arbIzq = new GeneralTree<Integer>(12, subArbIzq);
        
        List <GeneralTree<Integer>> subArbDer = new LinkedList <GeneralTree<Integer>>();
        subArbDer.add(new GeneralTree<Integer>(25));
        GeneralTree<Integer> arbDer = new GeneralTree<Integer>(25, subArbDer);
        
        List <GeneralTree<Integer>> arbol = new LinkedList <GeneralTree<Integer>>();
        arbol.add(arbIzq);
        arbol.add(arbDer);
        GeneralTree<Integer> a = new GeneralTree<Integer>(12, arbol); 
        
        System.out.println("Es de seleccion el primer arbol: " + esDeSeleccion(a));*/
		
		/*List<GeneralTree<Integer>> subChildren1 = new LinkedList<GeneralTree<Integer>>();
        subChildren1.add(new GeneralTree<Integer>(1));
        subChildren1.add(new GeneralTree<Integer>(1));
        subChildren1.add(new GeneralTree<Integer>(1));
        GeneralTree<Integer> subA = new GeneralTree<Integer>(1, subChildren1);
        List<GeneralTree<Integer>> subChildren2 = new LinkedList<GeneralTree<Integer>>();
        subChildren2.add(subA);
        subChildren2.add(new GeneralTree<Integer>(1));
        GeneralTree<Integer> a1 = new GeneralTree<Integer>(0, subChildren2);
        
        List<GeneralTree<Integer>> subChildren3 = new LinkedList<GeneralTree<Integer>>();
        subChildren3.add(new GeneralTree<Integer>(1));
        GeneralTree<Integer> subB = new GeneralTree<Integer>(0, subChildren3);
        List<GeneralTree<Integer>> subChildren4 = new LinkedList<GeneralTree<Integer>>();
        subChildren4.add(subB);
        GeneralTree<Integer> subC = new GeneralTree<Integer>(0, subChildren4);
        List<GeneralTree<Integer>> subChildren5 = new LinkedList<GeneralTree<Integer>>();
        subChildren5.add(new GeneralTree<Integer>(1));
        subChildren5.add(subC);
        GeneralTree<Integer> a2 = new GeneralTree<Integer>(1, subChildren5);
        
        List<GeneralTree<Integer>> subChildren6 = new LinkedList<GeneralTree<Integer>>();
        subChildren6.add(new GeneralTree<Integer>(0));
        subChildren6.add(new GeneralTree<Integer>(0));
        GeneralTree<Integer> subD = new GeneralTree<Integer>(0, subChildren6);
        List<GeneralTree<Integer>> subChildren7 = new LinkedList<GeneralTree<Integer>>();
        subChildren7.add(subD);
        GeneralTree<Integer> subE = new GeneralTree<Integer>(0, subChildren7);
        List<GeneralTree<Integer>> subChildren8 = new LinkedList<GeneralTree<Integer>>();
        subChildren8.add(subE);
        GeneralTree<Integer> a3 = new GeneralTree<Integer>(1, subChildren8);
        
        List<GeneralTree<Integer>> arbol = new LinkedList<GeneralTree<Integer>>();
        arbol.add(a1);
        arbol.add(a2);
        arbol.add(a3);
        GeneralTree<Integer> a = new GeneralTree<Integer>(1, arbol);
        
        System.out.println(resolver(a));*/
		
		List <GeneralTree<Integer>> subChildren1 = new LinkedList <GeneralTree<Integer>>();
        subChildren1.add(new GeneralTree<Integer>(83));
        GeneralTree<Integer> subAb1 = new GeneralTree<Integer>(18, subChildren1);
        
        List <GeneralTree<Integer>> subChildren2 = new LinkedList <GeneralTree<Integer>>();
        subChildren2.add(subAb1);
        GeneralTree<Integer> subAb2 = new GeneralTree<Integer>(5, subChildren2);
        
        List <GeneralTree<Integer>> subChildren3 = new LinkedList <GeneralTree<Integer>>();
        subChildren3.add(new GeneralTree<Integer>(33));
        subChildren3.add(new GeneralTree<Integer>(12));
        subChildren3.add(new GeneralTree<Integer>(17));
        subChildren3.add(new GeneralTree<Integer>(9));
        GeneralTree<Integer> subAb3 = new GeneralTree<Integer>(3, subChildren3);
        
        List <GeneralTree<Integer>> subChildren4 = new LinkedList <GeneralTree<Integer>>();
        subChildren4.add(new GeneralTree<Integer>(7));
        subChildren4.add(new GeneralTree<Integer>(11));
        subChildren4.add(subAb3);
        GeneralTree<Integer> subAb4 = new GeneralTree<Integer>(4, subChildren4);
        
        List <GeneralTree<Integer>> subArbIzq = new LinkedList <GeneralTree<Integer>>();
        subArbIzq.add(subAb2);
        subArbIzq.add(subAb4);
        GeneralTree<Integer> arbIzq = new GeneralTree<Integer>(1, subArbIzq);
        
        List <GeneralTree<Integer>> subArbDer = new LinkedList <GeneralTree<Integer>>();
        subArbDer.add(new GeneralTree<Integer>(13));
        GeneralTree<Integer> arbDer = new GeneralTree<Integer>(25, subArbDer);
        
        List <GeneralTree<Integer>> arbol = new LinkedList <GeneralTree<Integer>>();
        arbol.add(arbIzq);
        arbol.add(arbDer);
        GeneralTree<Integer> a = new GeneralTree<Integer>(2, arbol);
        
        System.out.println("Es creciente el arbol 1: " + resolver11(a));
        
        List<GeneralTree<Integer>> subChildren5 = new LinkedList <GeneralTree<Integer>>();
        subChildren5.add(new GeneralTree<Integer>(7));
        subChildren5.add(subAb3);
        GeneralTree<Integer> subAb5 = new GeneralTree<Integer>(4, subChildren5);
        
        List<GeneralTree<Integer>> subArbIzq2 = new LinkedList<GeneralTree<Integer>>();
        subArbIzq2.add(subAb2);
        subArbIzq2.add(subAb5);
        GeneralTree<Integer> arbIzq2 = new GeneralTree<Integer>(1, subArbIzq2);
        
        List <GeneralTree<Integer>> arbol2 = new LinkedList <GeneralTree<Integer>>();
        arbol2.add(arbIzq2);
        arbol2.add(arbDer);
        GeneralTree<Integer> a2 = new GeneralTree<Integer>(2, arbol2);
        
        System.out.println("Es creciente el arbol 2: " + resolver11(a2));
        
        
        //Mas casos para evaluar
        
        List <GeneralTree<Integer>> arbol3 = new LinkedList <GeneralTree<Integer>>();
        arbol3.add(new GeneralTree<Integer>(1));
        arbol3.add(new GeneralTree<Integer>(2));
        arbol3.add(new GeneralTree<Integer>(3));
        GeneralTree<Integer> a3 = new GeneralTree<Integer>(4, arbol3);
        
        System.out.println("Es creciente el arbol 3: " + resolver11(a3));
        
        List <GeneralTree<Integer>> arbol4 = new LinkedList <GeneralTree<Integer>>();
        arbol4.add(new GeneralTree<Integer>(19));
        GeneralTree<Integer> a4 = new GeneralTree<Integer>(2, arbol4);
        
        System.out.println("Es creciente el arbol 4: " + resolver11(a4)); //Me devolvia true porque la cola se vacio justo en el null y no llega a evaluar el else if y sale del while, retornando true (en mi primera resolucion)
        
        List <GeneralTree<Integer>> subArb1 = new LinkedList <GeneralTree<Integer>>();
        subArb1.add(new GeneralTree<Integer>(1));
        subArb1.add(new GeneralTree<Integer>(2));
        GeneralTree<Integer> subA3 = new GeneralTree<Integer>(4, subArb1);
        List <GeneralTree<Integer>> subArb2 = new LinkedList <GeneralTree<Integer>>();
        subArb2.add(new GeneralTree<Integer>(3));
        subArb2.add(subA3);
        GeneralTree<Integer> a5 = new GeneralTree<Integer>(6, subArb2); 
        
        System.out.println("Es creciente el arbol 5: " + resolver11(a5));
	}
}
