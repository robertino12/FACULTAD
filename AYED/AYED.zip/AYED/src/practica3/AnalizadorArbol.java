package practica3;

import java.util.LinkedList;
import java.util.List;

import tp1.ejercicio8.Queue;

public class AnalizadorArbol {
	public double devolverMaximoPromedio(GeneralTree<AreaEmpresa>arbol) {
		double maxPromedio=-1;
		int sumaPromedios=0;
		int cantNodos=0;
		double promedio=0;
		Queue<GeneralTree<AreaEmpresa>> cola=new Queue<GeneralTree<AreaEmpresa>>();
		if(arbol!=null) {
			if(!arbol.isEmpty()) {
				cola.enqueue(arbol);
				cola.enqueue(null);
			}
		}
		while(!cola.isEmpty()) {
			GeneralTree<AreaEmpresa> aux=cola.dequeue();
			if(aux!=null) {
				cantNodos++;
				sumaPromedios+=aux.getData().getTardanza();
				List<GeneralTree<AreaEmpresa>> hijos=aux.getChildren();
				for(GeneralTree<AreaEmpresa> hijo: hijos) {
					cola.enqueue(hijo);
				}
			}
			else {
				promedio=sumaPromedios/cantNodos;
				if(promedio>maxPromedio) {
					maxPromedio=promedio;
				}
				if(!cola.isEmpty()) {
					cola.enqueue(null);
					promedio=0;
					cantNodos=0;
					sumaPromedios=0;
				}
			}
		}
		return maxPromedio;
	}
	
	public static void main(String[] args) {
		AreaEmpresa a1=new AreaEmpresa("m",14);
		AreaEmpresa a2=new AreaEmpresa("j",13);
		AreaEmpresa a3=new AreaEmpresa("k",25);
		AreaEmpresa a4=new AreaEmpresa("l",10);
		AreaEmpresa a5=new AreaEmpresa("a",4);
		AreaEmpresa a6=new AreaEmpresa("b",7);
		AreaEmpresa a7=new AreaEmpresa("c",5);
		AreaEmpresa a8=new AreaEmpresa("d",6);
		AreaEmpresa a9=new AreaEmpresa("e",10);
		AreaEmpresa a10=new AreaEmpresa("f",18);
		AreaEmpresa a11=new AreaEmpresa("g",9);
		AreaEmpresa a12=new AreaEmpresa("h",12);
		AreaEmpresa a13=new AreaEmpresa("i",19);
		List<GeneralTree<AreaEmpresa>> abajo1=new LinkedList<GeneralTree<AreaEmpresa>>();
		abajo1.add(new GeneralTree<AreaEmpresa>(a5)); 
		abajo1.add(new GeneralTree<AreaEmpresa>(a6)); 
		abajo1.add(new GeneralTree<AreaEmpresa>(a7));
		GeneralTree<AreaEmpresa> hijo1=new GeneralTree<AreaEmpresa>(a2,abajo1);
		List<GeneralTree<AreaEmpresa>> abajo2=new LinkedList<GeneralTree<AreaEmpresa>>();
		abajo2.add(new GeneralTree<AreaEmpresa>(a8)); 
		abajo2.add(new GeneralTree<AreaEmpresa>(a9)); 
		abajo2.add(new GeneralTree<AreaEmpresa>(a10));
		GeneralTree<AreaEmpresa> hijo2=new GeneralTree<AreaEmpresa>(a3,abajo2);
		List<GeneralTree<AreaEmpresa>> abajo3=new LinkedList<GeneralTree<AreaEmpresa>>();
		abajo3.add(new GeneralTree<AreaEmpresa>(a11)); 
		abajo3.add(new GeneralTree<AreaEmpresa>(a12)); 
		abajo3.add(new GeneralTree<AreaEmpresa>(a13));
		GeneralTree<AreaEmpresa> hijo3=new GeneralTree<AreaEmpresa>(a4,abajo3);
		List<GeneralTree<AreaEmpresa>> abajo=new LinkedList<GeneralTree<AreaEmpresa>>();
		abajo.add(hijo1);
		abajo.add(hijo2);
		abajo.add(hijo3);
		GeneralTree<AreaEmpresa> padre=new GeneralTree<AreaEmpresa>(a1,abajo);
		AnalizadorArbol obj=new AnalizadorArbol();
		System.out.println(obj.devolverMaximoPromedio(padre));
	}
}
