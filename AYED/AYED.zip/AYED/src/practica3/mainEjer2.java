package practica3;

import java.util.LinkedList;
import java.util.List;

public class mainEjer2 {

	public static void main(String[] args) {
		//c1=Children 1,hijos p1, padre 1
		List<GeneralTree<Integer>>c1=new LinkedList<GeneralTree<Integer>>();
		c1.add(new GeneralTree<Integer>(6));
		c1.add(new GeneralTree<Integer>(11));
		GeneralTree<Integer> p1=new GeneralTree<Integer>(8,c1);
		List<GeneralTree<Integer>>c3=new LinkedList<GeneralTree<Integer>>();
		c3.add(new GeneralTree<Integer>(15));
		GeneralTree<Integer> p4=new GeneralTree<Integer>(12,c3);
		List<GeneralTree<Integer>>c2=new LinkedList<GeneralTree<Integer>>();
		c2.add(p4);
		c2.add(new GeneralTree<Integer>(13));
		GeneralTree<Integer> p2=new GeneralTree<Integer>(5,c2);
		GeneralTree<Integer> p3=new GeneralTree<Integer>(9);
		List<GeneralTree<Integer>> c0=new LinkedList<GeneralTree<Integer>>();
		c0.add(p1);
		c0.add(p2);
		c0.add(p3);
		GeneralTree<Integer> p0=new GeneralTree<Integer>(7,c0);
		RecorridosAG preOrden=new RecorridosAG();
		System.out.println(preOrden.numerosImparesMayoresQuePreOrden(p0, 5));
		RecorridosAG inOrden=new RecorridosAG();
		System.out.println(inOrden.numerosImparesMayoresQueInOrden(p0, 5));
		RecorridosAG postOrden=new RecorridosAG();
		System.out.println(postOrden.numerosImparesMayoresQuePostOrden(p0, 5));
		RecorridosAG nivelOrden=new RecorridosAG();
		System.out.println(nivelOrden.numerosImparesMayoresQuePorNiveles(p0, 5));
		System.out.println(p0.altura());
		System.out.println(p0.nivelRecu(11));
		System.out.println(p0.nivel(5));
		System.out.println(p0.ancho());
		System.out.println(p0.esAncestro(9,7));
	}
}
