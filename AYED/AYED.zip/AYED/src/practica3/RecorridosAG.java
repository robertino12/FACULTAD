package practica3;

import java.util.LinkedList;
import java.util.List;
import tp1.ejercicio8.Queue;

public class RecorridosAG {
	public RecorridosAG() {
		
	}
	//x q se pasa un objeto integer y no un int
	public List<Integer> numerosImparesMayoresQuePreOrden(GeneralTree<Integer> a, Integer n){
		List<Integer> listaPre=new LinkedList<Integer>();
		if(a!=null){//sino pongo este y m mandan null, cuando yo ingrese al helper y haga a.getData va a dar error ya q a apunta a null
			if(!a.isEmpty()) {//ak lo mismo, si es vacio y entra helper da error
				this.numerosImparesMayoresQuePreOrden(a,n,listaPre);
			}
		}
		return listaPre;//si el arbol esta vacio devulev lista vacia
	}
	
	private void numerosImparesMayoresQuePreOrden(GeneralTree<Integer> a, Integer n,List<Integer> listaPre) {
		if(a.getData()>n) {
			if((a.getData()%2)!=0) {
				listaPre.add(a.getData());
			}
		}//como da igual si es mayor o no tiene q seguir c el recorrido entonces no se pone else, se sigue
		//tomamos los hijos
		List<GeneralTree<Integer>> children= a.getChildren();
		for(GeneralTree<Integer> child: children) {
			numerosImparesMayoresQuePreOrden(child,n,listaPre);
		}
	}
	
	public List<Integer> numerosImparesMayoresQueInOrden (GeneralTree <Integer> a, Integer n) {
        List <Integer> listaIn = new LinkedList<Integer>();
        if(a!=null) {
        	if(!a.isEmpty()) 
        		this.numerosImparesMayoresQueInOrden(a, n, listaIn);
        }
        
        return listaIn;
    }

    private void numerosImparesMayoresQueInOrden (GeneralTree <Integer> a, Integer n, List <Integer> listaIn) {
        List<GeneralTree<Integer>> children = a.getChildren();
        if(a.hasChildren()) {
            numerosImparesMayoresQueInOrden(children.get(0), n, listaIn);
        }
        int dato = a.getData();
        if(dato %2 != 0 && dato > n) listaIn.add(dato);
        for(int i=1; i < children.size(); i++) {
            numerosImparesMayoresQueInOrden(children.get(i), n, listaIn);
        }
    }
    
    public List<Integer> numerosImparesMayoresQuePostOrden(GeneralTree <Integer> a,Integer n){
    	List <Integer> listaPost = new LinkedList<Integer>();
        if(a!=null) {
        	if(!a.isEmpty()) 
        		this.numerosImparesMayoresQuePostOrden(a, n, listaPost);
        }
        
        return listaPost;
    }
    
    private void numerosImparesMayoresQuePostOrden(GeneralTree<Integer> a,Integer n,List<Integer> listaPost) {
    	List<GeneralTree<Integer>> children=a.getChildren();
    	for(GeneralTree<Integer> child: children) {
    		numerosImparesMayoresQuePostOrden(child,n,listaPost);
    	}
    	int dato=a.getData();
    	if((dato%2!=0)&&(dato>n)) {
    		listaPost.add(dato);
    	}
    }
    
    public List<Integer> numerosImparesMayoresQuePorNiveles(GeneralTree<Integer> a,Integer n){
	    List<Integer> l= new LinkedList<Integer>();
	    if(a!=null&&!a.isEmpty()) {
	    	GeneralTree<Integer> arbAux;
	    	Queue<GeneralTree<Integer>> cola= new Queue<GeneralTree<Integer>>();
	    	cola.enqueue(a);
	    	while(!cola.isEmpty()) {
	    		arbAux=cola.dequeue();
	    		if(!arbAux.isEmpty()) {
	    			int dato=arbAux.getData();
	    			if((dato%2!=0)&&(dato>n)){
	    				l.add(arbAux.getData());
	    			}
	    		}
	    		List<GeneralTree<Integer>> hijos=arbAux.getChildren();
	    		for(GeneralTree<Integer> child: hijos) {
	    			cola.enqueue(child);
	    		}
	    	}
    	}
    	return l;//devuelve lista vacia si arbol es null
    }
}
