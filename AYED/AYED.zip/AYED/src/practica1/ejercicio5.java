package practica1;
public class ejercicio5 {
	private int[] vector;
	private int max;
	private int min;
	private int suma;
	private int promedio;
	private int cant;
	
	public ejercicio5 (int[] vector) {
		this.vector=vector;
		this.max=-1;
		this.min=150;
		this.suma=0;
		this.promedio=0;
		this.cant=0;
	}
	
	public int getMax() {
		return this.max;
	}
	public int getMin() {
		return this.min;
	}
	public int getPromedio() {
		return this.promedio;
	}
	public void calcular () {
		for(int i=0;i<this.vector.length;i++) {
			if(this.vector[i]>this.max) {
				this.max=this.vector[i];
			}
			if(this.vector[i]<this.min) {
				this.min=this.vector[i];
			}
			this.suma=this.suma+this.vector[i];
			this.cant++;
		}
		this.promedio=this.suma/this.cant;
	}
	
	public String retornar () {
		String aux="El max es: "+this.max+", el min es: "+this.min+" y el promedio es: "+this.promedio;
		return aux;
	}
	public String retornarConParametro(String resultado) {
		resultado=this.retornar();
		return resultado;
	}
	public void retornarSinParametros () {
		System.out.println("El max es: "+this.getMax()+", el min es: "+this.getMin()+" y el promedio es: "+this.getPromedio());
	}
}
