package practica1;
import java.util.ArrayList;
public class mainEj3 {
	public static void main(String[] args) {
		ArrayList<ejercicio3Estudiante> estudiantes=new ArrayList<>();
		ArrayList<ejercicio3Profesor> profesores=new ArrayList<>();
		String[] nombresProfesores = {"Carlos", "Javier", "Pedro"};
        String[] apellidosProfesores = {"Gomez", "Perez", "Lopez"};
        String[] emailsProfesores = {"carlos@gmail.com", "javier@gmail.com", "pedro@gmail.com"};
        String[] catedras = {"Catedra1", "Catedra2", "Catedra3"};
        String[] facultades = {"Informática", "Ciencias", "Artes"};
        for (int i = 0; i < 3; i++) {
            ejercicio3Profesor profesor = new ejercicio3Profesor();
            profesor.setNombre(nombresProfesores[i]);
            profesor.setApellido(apellidosProfesores[i]);
            profesor.setEmail(emailsProfesores[i]);
            profesor.setCatedra(catedras[i]);
            profesor.setFacultad(facultades[i]);
            profesores.add(profesor);
        }
        String[] nombresEstudiante = {"rober", "sabri"};
        String[] apellidosEstudiante = {"lucen", "ona"};
        String[] emailsEstudiante = {"rober@gmail.com", "sabri@gmail.com"};
        String[] comision = {"comision1", "comision2"};
        String[] direccion = {"122", "44"};
        for (int i = 0; i < 2; i++) {
            ejercicio3Estudiante estudiante = new ejercicio3Estudiante();
            estudiante.setNombre(nombresEstudiante[i]);
            estudiante.setApellido(apellidosEstudiante[i]);
            estudiante.setEmail(emailsEstudiante[i]);
            estudiante.setComision(comision[i]);
            estudiante.setDireccion(direccion[i]);
            estudiantes.add(estudiante);
        }
        for (ejercicio3Profesor profe:profesores) {
        	System.out.println(profe.tusDatos());
        	System.out.println("------------");
        }
        for (ejercicio3Estudiante estudiante:estudiantes) {
        	System.out.println(estudiante.tusDatos());
        	System.out.println("------------");
        }
	}
}
