package practica1;

public class ejercicio3Profesor {
	private String nombre;
	private String apellido;
	private String catedra;
	private String email;
	private String facultad;
	
	public ejercicio3Profesor() {
	}
	
	public String getNombre() {
		return this.nombre;
	}
	
	public void setNombre(String nombre) {
		this.nombre=nombre;
	}
	public String getApellido() {
		return this.apellido;
	}
	
	public void setApellido(String apellido) {
		this.apellido=apellido;
	}
	public String getCatedra() {
		return this.catedra;
	}
	
	public void setCatedra(String catedra) {
		this.catedra=catedra;
	}
	public String getEmail() {
		return this.email;
	}
	
	public void setEmail(String email) {
		this.email=email;
	}
	public String getFacultad() {
		return this.facultad;
	}
	
	public void setFacultad(String facultad) {
		this.facultad=facultad;
	}
	public String tusDatos() {
		return "Los datos del profesor son: Nombre: "+this.getNombre()+ ", Apellido: "+this.getApellido()+", Email: "+this.getEmail()+", catedra: "+this.getCatedra()+", facultad: "+this.getFacultad();
	}
}
