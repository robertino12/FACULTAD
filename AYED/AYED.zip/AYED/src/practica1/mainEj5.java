package practica1;
import java.util.Random;
public class mainEj5 {
	public static void main(String[] args) {
		int[] vec= new int[10];
		Random rand=new Random();
		for(int i=0;i<vec.length;i++) {
			vec[i]=rand.nextInt(100);
		}
		for(int i=0;i<vec.length;i++) {
			System.out.println(vec[i]);
		}
		String resultado="";
		ejercicio5 obj= new ejercicio5(vec);
		obj.calcular();
		System.out.println(obj.retornar());
		resultado=obj.retornarConParametro(resultado);
		System.out.println(resultado);
		obj.retornarSinParametros();
	}
}
