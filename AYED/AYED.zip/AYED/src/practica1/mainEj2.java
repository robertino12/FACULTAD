package practica1;
import java.util.Scanner;
import java.util.ArrayList;
public class mainEj2 {
	public static void main(String[] args) {
		Scanner scanner= new Scanner(System.in);
		ejercicio2 obj= new ejercicio2();
		ArrayList<Integer> lista=new ArrayList<>();
		System.out.print("Ingrese un numero: ");
		int numero=scanner.nextInt();
		obj.multiplos(numero,lista);
		System.out.print(lista);
		scanner.close();
	}
}
