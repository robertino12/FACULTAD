package practica1;

import java.util.ArrayList;

public class ejercicio2 {
	
	public ArrayList<Integer> multiplos(int n, ArrayList<Integer> lista){
		int i;
		int aux;
		i=1;
		while(i<=n) {
			aux=n*i;
			lista.add(aux);
			i++;
		}
		return lista;
	}
}