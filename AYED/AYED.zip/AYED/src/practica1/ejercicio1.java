package practica1;
import java.util.ArrayList;
public class ejercicio1 {
	public void todosFor (int a, int b) {
		for (int i=a+1; i<=b;i++) {
			System.out.println(i);
		}
		System.out.println('-');
	}
	public void todosWhile (int a, int b) {
		int i;
		i=a;
		while(i<b) {
			i=i+1;
			System.out.println(i);
		}
		System.out.println('-');
	}
	public void todosRecursion (int a, int b, ArrayList<Integer> lista) {
		if(a==b) {
			System.out.println(a);
		}
		else {
			lista.add(a);
			todosRecursion(a+1,b,lista);
			if(lista.get(0)!=a) {
				System.out.println(a);
			}
			
		}
	}
	/*10 11 12 13
	entra al else, llama al metodo pasando al siguiente,
	 * entra de nuevo, pasa al siguiente
	 * entra de nuevo, pasa al siguiente 
	 * if(a<b){
	 * 	a++;
	 * 	System.out.println(a);
	 * 	todosRecursion(a,b);
	 * }*/
}
