package practica1;
import java.util.ArrayList;
public class mainEj1 {
	public static void main(String[] args) {
		ejercicio1 obj= new ejercicio1();
		ArrayList<Integer> lista=new ArrayList<>();
		int a=2;
		int b=6;
		obj.todosFor(a,b);
		obj.todosWhile(a, b);
		obj.todosRecursion(a, b,lista);
	}
}
