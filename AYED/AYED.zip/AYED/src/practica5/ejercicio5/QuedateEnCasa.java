package practica5.ejercicio5;

import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;

import practica5.ejercicio1Grafo.Edge;
import practica5.ejercicio1Grafo.Graph;
import practica5.ejercicio1Grafo.Vertex;
import practica5.ejercicio1Grafo.adjList.AdjListGraph;
import tp1.ejercicio8.Queue;

public class QuedateEnCasa {
	public List<Persona> listaJubilados(Graph<Persona> personas,Persona empleado,int distancia){
		List<Persona> lista=new LinkedList<Persona>();
		boolean[] visitados=new boolean[personas.getSize()];
		List<Vertex<Persona>> vertices= personas.getVertices();
		Iterator<Vertex<Persona>> it=vertices.iterator();
		boolean encontro=false;
		Vertex<Persona> v=null;
		while(it.hasNext()&&!encontro) {
			v=it.next();
			if(v.getData().getTipo().equals(empleado.getTipo())&&v.getData().getNombre().equals(empleado.getNombre())) {
				encontro=true;
			}
		}
		if(encontro) {
			this.listaJubilados(personas, v, distancia,visitados,lista);
		}
		return encontro?lista:null; 
	}
	
	private void listaJubilados(Graph<Persona> personas,Vertex<Persona> empleado,int distancia,boolean[]visitados,List<Persona> jubilados) {
		Queue<Vertex<Persona>> cola=new Queue<Vertex<Persona>>();
		cola.enqueue(empleado);
		cola.enqueue(null);
		visitados[empleado.getPosition()]=true;
		int distanciaRecorrida=0;
		while(!cola.isEmpty()&&distanciaRecorrida<distancia&&jubilados.size()<40) {
			Vertex<Persona> v=cola.dequeue();
			if(v!=null) {
				if(v.getData().getTipo().equals("jubilado")) {
					jubilados.add(v.getData());
				}
				List<Edge<Persona>> ady=personas.getEdges(v);
				//que no hayan percibido la jubilacion del mes quiere decir que no fueron visitados supongo
				for(Edge<Persona> a:ady) {
					if(!visitados[a.getTarget().getPosition()]) {
						visitados[a.getTarget().getPosition()]=true;
						cola.enqueue(a.getTarget());
					}
				}
			}
			else if(!cola.isEmpty()) {
				distanciaRecorrida++;
				cola.enqueue(null);
			}
		}
	}
	
	public static void main(String[] args) {
		Graph<Persona> grafo = new AdjListGraph<>();
	    Vertex<Persona> v1 = grafo.createVertex(new Persona("empleado", "matias", "AAA"));
	    Vertex<Persona> v2 = grafo.createVertex(new Persona("jubilado", "julian", "BBB"));
	    Vertex<Persona> v3 = grafo.createVertex(new Persona("jubilado", "francisco", "CCC"));
	    Vertex<Persona> v4 = grafo.createVertex(new Persona("empleado", "valentin", "DDD"));
	    Vertex<Persona> v5 = grafo.createVertex(new Persona("jubilado", "omar", "EEE"));
	    Vertex<Persona> v6 = grafo.createVertex(new Persona("empleado", "rosana", "FFF"));
	    Vertex<Persona> v7 = grafo.createVertex(new Persona("jubilado", "maria", "GGG"));
	    Vertex<Persona> v8 = grafo.createVertex(new Persona("jubilado", "sandra", "HHH"));
	    Vertex<Persona> v9 = grafo.createVertex(new Persona("jubilado", "matheo", "III"));
	    
	    grafo.connect(v1, v2);
	    grafo.connect(v2, v1);
	    grafo.connect(v2, v3);
	    grafo.connect(v3, v2);
	    
	    grafo.connect(v1, v9);
	    grafo.connect(v9, v1);
	    grafo.connect(v9, v8);
	    grafo.connect(v8, v9);
	    
	    grafo.connect(v1, v4);
	    grafo.connect(v4, v1);
	    grafo.connect(v1, v6);
	    grafo.connect(v6, v1);
	    grafo.connect(v4, v5);
	    grafo.connect(v5, v4);
	    grafo.connect(v5, v7);
	    grafo.connect(v7, v5);
	    
	    
	    QuedateEnCasa banco = new QuedateEnCasa();
	    Persona e=new Persona("empleado","matias","A");
	    List<Persona> lista=banco.listaJubilados(grafo, e, 3);
	    //List<Persona> lista=banco.listaJubilados(grafo, e, 2);
	    for(Persona p:lista) {
	    	System.out.println(p.getNombre());
	    }
	    //System.out.println(banco.carteraJubilados(grafo, "Matias", 3, 40));
	    
	    //System.out.println(banco.carteraJubilados(grafo, "Rosana", 2, 40));
	    
	    //System.out.println(banco.carteraJubilados(grafo, "Matias", 2, 1));
	}
}
