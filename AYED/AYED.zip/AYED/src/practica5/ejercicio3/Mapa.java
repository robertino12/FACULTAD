package practica5.ejercicio3;

import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;

import practica5.ejercicio1Grafo.Edge;
import practica5.ejercicio1Grafo.Graph;
import practica5.ejercicio1Grafo.Vertex;
import practica5.ejercicio1Grafo.adjList.AdjListGraph;

public class Mapa {
	private Graph<String> mapaCiudades;
	
	public Mapa(Graph<String> mapa) {
        this.setMapaCiudades(mapa);
    }

    public Graph<String> getMapaCiudades() {
        return mapaCiudades;
    }

    public void setMapaCiudades(Graph<String> mapaCiudades) {
        this.mapaCiudades = mapaCiudades;
    }
	
	public List<String> devolverCamino(String ciudad1,String ciudad2){
		boolean[] visitados= new boolean[this.mapaCiudades.getSize()];
		List<String> camino= new LinkedList<String>();
		//no tengo q hacer un for ya q es desde un origen a un destino
		//tendria q fijarme q el origen y el destino esten en el grafo
		boolean encontro=false;
		if(this.mapaCiudades.search(ciudad1)!=null&&this.mapaCiudades.search(ciudad2)!=null) {
			encontro=devolverCamino(this.mapaCiudades.search(ciudad1),ciudad2,camino,visitados);
		}
		//PREGUNTAR, XQ AL HACER SEARCH RECORRO EL GRAFO, Y NO SE SI ESTARIA MAL
		//SINO HAGO UN WHILE HASTA ENCONTRARLO, SI LO ENCUENTRO DISPARO EL DFS
		//TOTAL EN EL DFS CHEQUEO SI LLEGA A CIUDAD2 OSEA SI EXISTE
		return encontro==true?camino:null;
	}
	
	private boolean devolverCamino(Vertex<String> vertice,String ciudad2,List<String> camino,boolean[] visitados) {
		boolean encontre=false;
		camino.add(vertice.getData());
		visitados[vertice.getPosition()]=true;
		if(vertice.getData().equals(ciudad2)) {
			return true;
		}
		else {
			List<Edge<String>> ady=this.mapaCiudades.getEdges(vertice);
			//no tiene sentido hacer for porque si ya encontro el destino seguiria x los otros adyacentes
			Iterator<Edge<String>> it = ady.iterator();
			while(it.hasNext()&&!encontre) {
				Vertex<String> destino= it.next().getTarget();
				if(!visitados[destino.getPosition()]) {
					encontre=devolverCamino(destino,ciudad2,camino,visitados);
				}
			}
			if(!encontre) {
				camino.remove(camino.size()-1);
				visitados[vertice.getPosition()]=false;
			}	
		}
		return encontre;	
	}
	
	public List<String> devolverCaminoExceptuando(String c1,String c2, List<String> ciudades){
		boolean[]visitados=new boolean[this.mapaCiudades.getSize()];
		List<String> camino= new LinkedList<String>();
		boolean encontro=false;
		boolean esCamino=false;
		Vertex<String> v1=null;
		List<Vertex<String>> v=this.mapaCiudades.getVertices();
		Iterator<Vertex<String>> it=v.iterator();
		while(it.hasNext()&&!encontro) {
			v1=it.next();
			if(v1.getData().equals(c1)) {
				encontro=true;
			}
		}
		if(encontro) {
			esCamino=devolverCaminoExceptuando(v1,c2,visitados,camino,ciudades);
		}
		return esCamino?camino:null;
	}
	
	private boolean devolverCaminoExceptuando(Vertex<String> v1,String c2, boolean[]visitados,List<String>camino,List<String> ciudades) {
		boolean encontre=false;
		visitados[v1.getPosition()]=true;
		camino.add(v1.getData());
		if(v1.getData().equals(c2)) {
			return true;
		}
		else {
			List<Edge<String>> ady=this.mapaCiudades.getEdges(v1);
			Iterator<Edge<String>> it = ady.iterator();
			while(it.hasNext()&&!encontre) {
				Vertex<String> destino= it.next().getTarget();
				if(!visitados[destino.getPosition()]&&!ciudades.contains(destino.getData())) {
					encontre=devolverCaminoExceptuando(destino,c2,visitados,camino,ciudades);
				}
			}
			if(!encontre) {
				camino.remove(camino.size()-1);
				visitados[v1.getPosition()]=false;
			}	
		}
		return encontre;
	}
	
	public List<String> caminoMasCorto(String c1,String c2){
		boolean[]visitados=new boolean[this.mapaCiudades.getSize()];
		List<String> caminoAct= new LinkedList<String>();
		List<String> caminoMinimo= new LinkedList<String>();
		boolean encontro=false;
		Vertex<String> v1=null;
		List<Vertex<String>> v=this.mapaCiudades.getVertices();
		Iterator<Vertex<String>> it=v.iterator();
		while(it.hasNext()&&!encontro) {
			v1=it.next();
			if(v1.getData().equals(c1)) {
				encontro=true;
			}
		}
		if(encontro) {
			caminoMasCorto(v1,c2,visitados,caminoMinimo,caminoAct,0,Integer.MAX_VALUE);
		}
		return caminoMinimo.size()==0?null:caminoMinimo;//osea sino hay camino hasta destino
	}
	
	private int caminoMasCorto(Vertex<String> v1,String c2, boolean[]visitados,List<String> caminoMinimo,List<String> caminoAct,int totalPesoAristas,int min) {
		//tengo q recorrer todos los caminos, e ir quedandome con el minimo 
		visitados[v1.getPosition()] = true;
        caminoAct.add(v1.getData());
        if(v1.getData().equals(c2) && totalPesoAristas < min) {//si llega al destino y el total del peso del camino es menor a min actualizar
            caminoMinimo.removeAll(caminoMinimo);//si entra, saca todos los nodos de camino minimo anterior
            caminoMinimo.addAll(caminoAct);//pone el nuevo camino minimo
            min = totalPesoAristas;//actualiza el minimo y no lo devuelve aca xq tiene q seguir buscando caminos, entonces tiene q desmarcar el destino y sacarlo de la lista de caminoAct
        } else {
            List<Edge<String>> ady = this.mapaCiudades.getEdges(v1);
            Iterator<Edge<String>> it = ady.iterator();
            while(it.hasNext() && totalPesoAristas < min) {//este while sirve xq si en el if no entra y vuelve al while por otro adyacente, como no entro en el if tampoco va a entrar al while, ya que el peso total es mayor a min
            	//no tiene sentido seguir recorriendo si ya superaste el peso minimo
                Edge<String> v = it.next();
                int j = v.getTarget().getPosition();
                int aux = totalPesoAristas + v.getWeight();//suma el peso de la arista
                if(!visitados[j] && aux < min) {//la segunda condicion la pone xq si ya el peso del camino es mayor a min no tiene sentido disparar otro dfs
                    min = caminoMasCorto(v.getTarget(), c2, visitados,caminoMinimo, caminoAct, aux, min);
                }
            }
        }
        visitados[v1.getPosition()] = false;
        caminoAct.remove(caminoAct.size()-1);
        return min;//retorna el minimo cuando actualizo el minimo o cuando ya no hay mas adyacentes
	}
	
	public List<String> caminoSinCargarCombustible(String c1, String c2, int tanqueAuto){
		boolean[]visitados=new boolean[this.mapaCiudades.getSize()];
		List<String> camino= new LinkedList<String>();
		boolean encontro=false;
		boolean esCamino=false;
		Vertex<String> v1=null;
		List<Vertex<String>> v=this.mapaCiudades.getVertices();
		Iterator<Vertex<String>> it=v.iterator();
		while(it.hasNext()&&!encontro) {
			v1=it.next();
			if(v1.getData().equals(c1)) {
				encontro=true;
			}
		}
		if(encontro) {
			Integer naftaUsada=0;
			esCamino=caminoSinCargarCombustible(v1,c2,visitados,camino,tanqueAuto,naftaUsada);
		}
		return esCamino?camino:null;
	}
	
	private boolean caminoSinCargarCombustible(Vertex<String> v1,String c2, boolean[]visitados,List<String>camino,int tanqueAuto,Integer naftaUsada) {
		visitados[v1.getPosition()]=true;
		camino.add(v1.getData());
		boolean encontroCamino=false;
		if(v1.getData().equals(c2)&&naftaUsada<tanqueAuto) {
			return true;
		}
		else {
			List<Edge<String>> ady=this.mapaCiudades.getEdges(v1);
			Iterator<Edge<String>> it=ady.iterator();
			while(it.hasNext()&&naftaUsada<tanqueAuto&&!encontroCamino) {
				Edge<String> arista=it.next();
				int nafta=arista.getWeight();
				int aux= naftaUsada+nafta;
				if(!visitados[arista.getTarget().getPosition()]&&naftaUsada<tanqueAuto) {
					encontroCamino=caminoSinCargarCombustible(arista.getTarget(),c2,visitados,camino,tanqueAuto,aux);
				}
			}
		}
		if(!encontroCamino) {
			visitados[v1.getPosition()]=false;
			camino.remove(camino.size()-1);
		}
		return encontroCamino;
	}
	
	public List<String> caminoConMenorCargaDeCombustible(String c1,String c2,int tanqueAuto){
		boolean[]visitados=new boolean[this.mapaCiudades.getSize()];
		List<String> caminoAct= new LinkedList<String>();
		List<String> caminoMinimo= new LinkedList<String>();
		boolean encontro=false;
		Vertex<String> v1=null;
		List<Vertex<String>> v=this.mapaCiudades.getVertices();
		Iterator<Vertex<String>> it=v.iterator();
		while(it.hasNext()&&!encontro) {
			v1=it.next();
			if(v1.getData().equals(c1)) {
				encontro=true;
			}
		}
		if(encontro) {
			Integer naftaUsada=0;
			caminoConMenorCargaDeCombustible(v1,c2,visitados,caminoMinimo,caminoAct,tanqueAuto,naftaUsada,0,Integer.MAX_VALUE);
			//0 es la cantidad de veces que carga combustible, para ir llevando la cuenta
		}
		return caminoMinimo.size()==0?null:caminoMinimo;
	}
	
	public int caminoConMenorCargaDeCombustible(Vertex<String> v1,String c2,boolean[] visitados,List<String> caminoMinimo,List<String> caminoAct, int tanqueAuto,Integer naftaUsada, int cantCargas,int minCargas) {
		visitados[v1.getPosition()]=true;
		caminoAct.add(v1.getData());
		if(v1.getData().equals(c2)&&cantCargas<minCargas) {
			caminoMinimo.removeAll(caminoMinimo);
			caminoMinimo.addAll(caminoAct);
			minCargas=cantCargas;
		}
		else {
			List<Edge<String>> ady=this.mapaCiudades.getEdges(v1);
			Iterator<Edge<String>> it=ady.iterator();
			while(it.hasNext()&&cantCargas<minCargas) {
				Edge<String> arista= it.next();
				int nafta=arista.getWeight();
				int aux= nafta+naftaUsada;
				if((!visitados[arista.getTarget().getPosition()])&&(nafta<tanqueAuto)) {//directamente si la ruta q va a hacer es mayor al tanque del auto q vaya x otra ruta, xq ni cargando safa
					if(tanqueAuto-naftaUsada<nafta) {
						aux=0;//osea llena tanque
						cantCargas++;
					}
					minCargas=caminoConMenorCargaDeCombustible(arista.getTarget(),c2,visitados,caminoMinimo,caminoAct,tanqueAuto,aux,cantCargas,minCargas);
				}
			}
		}
		visitados[v1.getPosition()]=false;
		caminoAct.remove(caminoAct.size()-1);
		return minCargas;
	}
	//cada vez que voy a ir a una ciudad, preguntar el peso de la arista del edyacente para ver si cargo todo el tanque o no
	public static void main(String[] args) {
        Graph<String> mapaCiudades = new AdjListGraph<String>();
        Vertex<String> v1 = mapaCiudades.createVertex("La Plata"); //Casa Caperucita
        Vertex<String> v2 = mapaCiudades.createVertex("Ensenada"); //Claro 3
        Vertex<String> v3 = mapaCiudades.createVertex("Berisso"); //Claro 1
        Vertex<String> v4 = mapaCiudades.createVertex("Berazategui"); //Claro 2
        Vertex<String> v5 = mapaCiudades.createVertex("Florencio Varela"); //Claro 5
        Vertex<String> v6 = mapaCiudades.createVertex("Presidente Peron"); //Claro 4
        Vertex<String> v7 = mapaCiudades.createVertex("San Vicente"); //Casa Abuelita
        mapaCiudades.connect(v1, v2, 4);
        mapaCiudades.connect(v2, v1, 4);
        mapaCiudades.connect(v1, v3, 3);
        mapaCiudades.connect(v3, v1, 3);
        mapaCiudades.connect(v1, v4, 4);
        mapaCiudades.connect(v4, v1, 4);
        mapaCiudades.connect(v2, v5, 15);
        mapaCiudades.connect(v5, v2, 15);
        mapaCiudades.connect(v3, v5, 3);
        mapaCiudades.connect(v5, v3, 3);
        mapaCiudades.connect(v4, v3, 4);
        mapaCiudades.connect(v3, v4, 4);
        mapaCiudades.connect(v4, v5, 11);
        mapaCiudades.connect(v5, v4, 11);
        mapaCiudades.connect(v4, v6, 10);
        mapaCiudades.connect(v6, v4, 10);
        mapaCiudades.connect(v5, v7, 4);
        mapaCiudades.connect(v7, v5, 4);
        mapaCiudades.connect(v6, v7, 9);
        mapaCiudades.connect(v7, v6, 9);
        
        Mapa mapa = new Mapa(mapaCiudades);
        
        System.out.print("LISTA DEVOLVER CAMINO: ");
        System.out.print(mapa.devolverCamino("La Plata", "San Vicente"));
        
        System.out.println("");
        
        System.out.print("LISTA DEVOLVER CAMINO EXCEPTUANDO LUGARES:");
        List<String> restringidos = new LinkedList<String>();
        restringidos.add("Berisso");
        System.out.print(mapa.devolverCaminoExceptuando("La Plata", "San Vicente", restringidos));
        
        System.out.println("");
        
        System.out.print("LISTA CAMINO MAS CORTO (SEGUN DISTANCIA): ");
        System.out.print(mapa.caminoMasCorto("La Plata", "San Vicente"));
        
        System.out.println("");
        
        System.out.print("LISTA CAMINO SIN CARGAR COMBUSTIBLE: ");
        System.out.print(mapa.caminoSinCargarCombustible("La Plata", "San Vicente", 30));
    
        System.out.println("");
        
        System.out.print("LISTA CAMINO CON MENOR CARGAS DE COMBUSTIBLE: ");
        System.out.print(mapa.caminoConMenorCargaDeCombustible("La Plata", "San Vicente", 10));
        
        System.out.println("");
	}
}
