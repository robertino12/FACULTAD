package practica5.ejercicio2;

import practica5.ejercicio1Grafo.Vertex;
import practica5.ejercicio1Grafo.adjList.AdjListVertex;

public class MainRecorridos {

	public static void main(String[] args) {

	}

}
