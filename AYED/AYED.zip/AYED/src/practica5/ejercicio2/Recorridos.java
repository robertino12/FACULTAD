package practica5.ejercicio2;

import java.util.LinkedList;
import java.util.List;

import practica5.ejercicio1Grafo.Edge;
import practica5.ejercicio1Grafo.Graph;
import practica5.ejercicio1Grafo.Vertex;
import tp1.ejercicio8.Queue;

public class Recorridos {
	public List<Vertex<Integer>> dfs(Graph<Integer> g){
		List<Vertex<Integer>> lista=new LinkedList<Vertex<Integer>>();
		boolean[] visitados= new boolean[g.getSize()];
		for(int i=0;i<g.getSize();i++) {
			if(!visitados[i]) {
				dfs(i,g,lista,visitados);
			}
		}
		return lista;
	}
	
	private void dfs(int i,Graph<Integer> g,List<Vertex<Integer>>lista,boolean[]visitados) {
		visitados[i]=true;
		Vertex<Integer> v=g.getVertices().get(i);
		lista.add(v);
		List<Edge<Integer>> ady=g.getEdges(v);
		for(Edge<Integer> arista: ady) {
			int destino=arista.getTarget().getPosition();
			if(!visitados[destino])
				dfs(destino,g,lista,visitados);
		}
	}
	
	public List<Vertex<Integer>> bfs(Graph<Integer> g){
		boolean[] visitados=new boolean[g.getSize()];
		List<Vertex<Integer>> lista=new LinkedList<Vertex<Integer>>();
		for(int i=0;i<g.getSize();i++) {
			if(!visitados[i]) {
				bfs(i,g,visitados,lista);
			}
		}
		return lista;
	}
	
	private void bfs(int i,Graph<Integer> g,boolean[] visitados,List<Vertex<Integer>> lista) {
		Queue<Vertex<Integer>> cola= new Queue<Vertex<Integer>>();
		cola.enqueue(g.getVertex(i));
		visitados[i]=true;
		while(!cola.isEmpty()) {
			Vertex<Integer> v=cola.dequeue();
			lista.add(v);
			List<Edge<Integer>> ady=g.getEdges(v);
			for(Edge<Integer> arista:ady) {
				int j=arista.getTarget().getPosition();
				if(!visitados[j]) {
					Vertex<Integer> w=arista.getTarget();
					visitados[j]=true;
					cola.enqueue(w);
				}
			}
		}
	}
}
