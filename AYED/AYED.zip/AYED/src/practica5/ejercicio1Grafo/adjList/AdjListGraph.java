package practica5.ejercicio1Grafo.adjList;

import java.util.ArrayList;
import java.util.List;

import practica5.ejercicio1Grafo.Edge;
import practica5.ejercicio1Grafo.Graph;
import practica5.ejercicio1Grafo.Vertex;

/**
 * Implementación del grafo con listas de adyacencias.
 *
 * @param <T> Tipo de valores de los vértices
 */
public class AdjListGraph<T> implements Graph<T> {

    private List<AdjListVertex<T>> vertices;
    
    public AdjListGraph() {
    	this.vertices = new ArrayList<>();
    }

	@Override
	public Vertex<T> createVertex(T data) {
		int newPos = this.vertices.size();//toma el tamaño de la lista de vertices para ponerle la posicion al vertice que va a crear y agregar al final de la lista
		AdjListVertex<T> vertex = new AdjListVertex<>(data, newPos);//crea vertice con el dato y la posicion del final de la lista
		this.vertices.add(vertex);//lo agrega al final de la lista
		return vertex;//retorna el vertice creado
	}

	@Override
	public void removeVertex(Vertex<T> vertex) {
		int position = vertex.getPosition();//tomamos la posicion del vertice pasado como parametro que seria el que queremos eliminar
		if (this.vertices.get(position) != vertex) {//obtenemos el vertice de la lista de vertices a partir de la posicion del vertice pasado por parametro
			// el vértice no corresponde al grafo
			return;
		}
		//sino entra al if es xq el vertice que queremos eliminar esta en el grafo
		this.vertices.remove(position);//elimina el vertice en la posicion del vertice pasado por parametro
		for (;position < this.vertices.size(); position++) {
			this.vertices.get(position).decrementPosition();//una vez eliminado decrementamos la posicion de cada uno de los vertices de la lista
		}
		for (Vertex<T> other : this.vertices) {//
			this.disconnect(other, vertex);
		}
	}

	@Override
	public Vertex<T> search(T data) {//busca un vertice en base al dato pasado por parametro y lo retorna si lo encuentra
		for (Vertex<T> vertex : this.vertices) {//toma lista de vertices
			if (vertex.getData().equals(data)) {//pregunta si el vertice actual tiene de dato igual que el dato pasado por parametro
				return vertex;//devuelve el vertice
			}
		}//sino devuelve null
		return null;
	}

	/**
	 * Indica si el vértice recibido pertenece al grafo.
	 */
	private boolean belongs(Vertex<T> vertex) {
		int pos = vertex.getPosition();//toma posicion del vertice
		return pos >= 0 && pos < this.vertices.size() //pregunta si la pos se encuentra en el rango de la lista de vertices 
			&& this.vertices.get(pos) == vertex;//y obtenemos el vertice de la lista de vertices en la pos del vertice pasado por parametro y preguntamos si el vertice es igual al pasado por parametro
	}

	@Override
	public void connect(Vertex<T> origin, Vertex<T> destination) {//se usa para conectar dos vertices mediante una arista, osea q el vertice destino sea adyacente al origen. ya que al principio solo estan en la lista de vertices, no hay adyacencias
		if (this.belongs(origin) && this.belongs(destination)) {//pregunta si los vertices pertenecen a la lista de vertices
			((AdjListVertex<T>) origin).connect(destination);//si pertenecen, conectar el origen con el destino en la lista de adyacente del vertice origen
		}
	}

	@Override//hace lo mismo que el de arriba pero con aristas con peso
	public void connect(Vertex<T> origin, Vertex<T> destination, int weight) {
		if (this.belongs(origin) && this.belongs(destination)) {
			((AdjListVertex<T>) origin).connect(destination, weight);
		}
	}

	@Override//este elimina la arista que conecta al origen con destino en la lista de aristas de origen
	public void disconnect(Vertex<T> origin, Vertex<T> destination) {
		if (this.belongs(origin)) {
			((AdjListVertex<T>) origin).disconnect(destination);
		}
	}

	/**
	 * Retorna la arista entre los dos vértices, si es que existe.  Previamente valida
	 * que el vértice pertenezca al grafo.
	 */
	private Edge<T> edge(Vertex<T> origin, Vertex<T> destination) {
		if (this.belongs(origin)) {
			return ((AdjListVertex<T>) origin).getEdge(destination);
		}
		return null;
	}

	@Override
	public boolean existsEdge(Vertex<T> origin, Vertex<T> destination) {
		return this.edge(origin, destination) != null;
	}

	
	@Override
	public int weight(Vertex<T> origin, Vertex<T> destination) {
		Edge<T> edge = this.edge(origin, destination);//obtiene la arista entre los vertices
		int weight = 0;
		if (edge != null) {//si existe
			weight = edge.getWeight();//guarda el peso de la arista en la variable
		}
		return weight;//retorna el peso de la arista
	}

	@Override
	public boolean isEmpty() {
		return this.vertices.isEmpty();//sino tiene vertices el grafo esta vacio
	}

	@Override
	public List<Vertex<T>> getVertices() {
		return new ArrayList<>(this.vertices);
	}

	@Override
	public List<Edge<T>> getEdges(Vertex<T> vertex) {
		if (this.belongs(vertex)) {
			return ((AdjListVertex<T>) vertex).getEdges();
		}
		return null;
	}

	@Override
	public Vertex<T> getVertex(int position) {
		if (position < 0 || this.vertices.size()<= position) {
			// la posición recibida es incorrecta
			return null;
		}
		return this.vertices.get(position);
	}
	
	@Override
	public int getSize() {
		return this.vertices.size();
	}
}
