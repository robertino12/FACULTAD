package practica5.ejercicio6;

import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;

import practica5.ejercicio1Grafo.Edge;
import practica5.ejercicio1Grafo.Graph;
import practica5.ejercicio1Grafo.Vertex;
import practica5.ejercicio1Grafo.adjList.AdjListGraph;

public class BuscadorDeCaminos {
	private Graph<String> bosque;
	
	public BuscadorDeCaminos(Graph<String> bosque) {
        this.setBosque(bosque);
    }

    public Graph<String> getBosque() {
        return bosque;
    }

    public void setBosque(Graph<String> bosque) {
        this.bosque = bosque;
    }
	
	public List<List<String>> recorridosMasSeguros(){
		List<List<String>> todosCaminos=new LinkedList<List<String>>();
		List<String> camino=new LinkedList<String>();
		boolean[] visitados=new boolean[this.bosque.getSize()];
		boolean encontre=false;
		Vertex<String> v=null;
		List<Vertex<String>> vertices=this.bosque.getVertices();
		Iterator<Vertex<String>> it=vertices.iterator();
		while(it.hasNext()&&!encontre) {
			v=it.next();
			if(v.getData().equals("Casa Caperucita")) {
				encontre=true;
			}
		}
		if(encontre) {
			recorridosMasSeguros(todosCaminos,camino,visitados,v);
		}
		return encontre?todosCaminos:null;
	}
	
	private void recorridosMasSeguros(List<List<String>> todosCaminos,List<String> camino,boolean[]visitados,Vertex<String> v) {
		visitados[v.getPosition()]=true;
		camino.add(v.getData());
		if(v.getData().equals("Casa Abuelita")) {
			todosCaminos.add(new LinkedList<String>(camino));
		}
		else {
			List<Edge<String>> ady=this.bosque.getEdges(v);
			for(Edge<String> a:ady) {
				if(!visitados[a.getTarget().getPosition()]&&a.getWeight()<5) {
					recorridosMasSeguros(todosCaminos,camino,visitados,a.getTarget());
				}
			}
		}
		//hay q eliminar igual aunque llegue a destino ya que hay q buscar todos los caminos
		visitados[v.getPosition()]=false;
		camino.remove(camino.size()-1);
	}
	
	public static void main (String[] args) {
        Graph<String> bosque = new AdjListGraph<String>();
        Vertex<String> v1 = bosque.createVertex("Casa Caperucita");
        Vertex<String> v2 = bosque.createVertex("Claro 3");
        Vertex<String> v3 = bosque.createVertex("Claro 1");
        Vertex<String> v4 = bosque.createVertex("Claro 2");
        Vertex<String> v5 = bosque.createVertex("Claro 5");
        Vertex<String> v6 = bosque.createVertex("Claro 4");
        Vertex<String> v7 = bosque.createVertex("Casa Abuelita");
        bosque.connect(v1, v2, 4);
        bosque.connect(v2, v1, 4);
        bosque.connect(v1, v3, 3);
        bosque.connect(v3, v1, 3);
        bosque.connect(v1, v4, 4);
        bosque.connect(v4, v1, 4);
        bosque.connect(v2, v5, 15);
        bosque.connect(v5, v2, 15);
        bosque.connect(v3, v5, 3);
        bosque.connect(v5, v3, 3);
        bosque.connect(v4, v3, 4);
        bosque.connect(v3, v4, 4);
        bosque.connect(v4, v5, 11);
        bosque.connect(v5, v4, 11);
        bosque.connect(v4, v6, 10);
        bosque.connect(v6, v4, 10);
        bosque.connect(v4, v3, 4);
        bosque.connect(v3, v4, 4);
        bosque.connect(v5, v7, 4);
        bosque.connect(v7, v5, 4);
        bosque.connect(v6, v7, 9);
        bosque.connect(v7, v6, 9);
        BuscadorDeCaminos bos = new BuscadorDeCaminos(bosque);
        List<List<String>> lis = bos.recorridosMasSeguros();
        for(List<String> l: lis) {
            System.out.println(l);
        }
	}
}
