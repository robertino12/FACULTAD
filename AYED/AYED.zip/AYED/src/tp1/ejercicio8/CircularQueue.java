package tp1.ejercicio8;

public class CircularQueue<T> extends Queue<T>{
	public T shift() {
		T desencolado=this.dequeue();
		this.enqueue(desencolado);
		return desencolado;
	}
}