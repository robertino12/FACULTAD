package tp1.ejercicio8;

public abstract class  Sequence  {
	public abstract int size();
	public abstract boolean isEmpty();
}
