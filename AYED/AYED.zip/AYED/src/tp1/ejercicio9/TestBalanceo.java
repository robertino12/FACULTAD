package tp1.ejercicio9;
import java.util.Stack;
public class TestBalanceo {
	Stack<Character> pila=new Stack<>();
	
	public TestBalanceo() {}
	
	public boolean verificarBalanceo(String cadena) {
		// Verificar si la cadena contiene algún carácter que no sea un paréntesis, corchete o llave
        if (cadena.matches(".*[^\\{\\[\\(\\}\\]\\)].*")) {
            return false; // La cadena contiene al menos un carácter que no es un paréntesis, corchete o llave
        }
		int i=0;
		boolean balanceado=true;
		while((i<cadena.length())&&(balanceado)) {
			char c=cadena.charAt(i);
			//las comillas dobles son para string, las simples para char
			switch(c) {
				case '{':
				case '[':
				case '(':
					pila.push(c);
					break;
				case '}':
					if(pila.isEmpty()||pila.peek()!='{') {
						balanceado=false;
					}
					else {
						pila.pop();
					}
					break;
				case ']':
					if(pila.isEmpty()||pila.peek()!='[') {
						balanceado=false;
					}
					else {
						pila.pop();
					}
					break;
				case ')':
					if(pila.isEmpty()||pila.peek()!='(') {
						balanceado=false;
					}
					else {
						pila.pop();
					}
					break;
				
			}
			i++;
		}
		return balanceado;
	}
	
}
