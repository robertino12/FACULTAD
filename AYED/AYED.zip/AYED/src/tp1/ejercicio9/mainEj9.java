package tp1.ejercicio9;

import java.util.Scanner;

public class mainEj9 {
	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		System.out.println("Por favor, ingrese un string: ");
		String cadena = scanner.nextLine();
		TestBalanceo obj=new TestBalanceo();
		System.out.println(obj.verificarBalanceo(cadena));
		scanner.close();
	}
}
