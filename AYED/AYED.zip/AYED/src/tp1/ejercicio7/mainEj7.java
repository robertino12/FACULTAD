package tp1.ejercicio7;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.Scanner;

public class mainEj7 {
	public static void main(String[] args) {
		ArrayList<Integer> vec= new ArrayList<>();
		TestArrayList obj1= new TestArrayList(vec);
		Scanner scanner= new Scanner(System.in);
		System.out.print("Ingrese un numero: ");
		int numero=scanner.nextInt();
		while(numero!=0) {
			obj1.agregarElemento(numero);
			System.out.print("Ingrese un numero: ");
			numero=scanner.nextInt();
		}
		for(int objeto:obj1.getVector()) {
			System.out.println(objeto);
		}
		System.out.println("-");
/*Punto c*/System.out.println(obj1.getVector().toString());
		System.out.println("la lista es capicua? "+obj1.esCapicua());
		scanner.close();
		//INCISO G
		int num=6;
		incisoG prueba=new incisoG();
		ArrayList<Integer> vecVacio=new ArrayList<>();
		for(int aux:prueba.calcularSucesion(num, vecVacio)) {
			System.out.println(aux);
		}
		ArrayList<Integer> vec1=new ArrayList<>();
		vec1.add(1);
		vec1.add(2);
		vec1.add(3);
		vec1.add(4);
		vec1.add(5);
		incisoG obj= new incisoG();
		obj.invertir(vec1, 0, vec1.size()-1);
		LinkedList<Integer> lis=new LinkedList<>();
		lis.add(10);
		lis.add(20);
		lis.add(20);
		lis.add(50);
		incisoG sumar=new incisoG();
		sumar.sumar(lis, 0, 0);
		ArrayList<Integer> lista1=new ArrayList<>();
		ArrayList<Integer> lista2=new ArrayList<>();
		lista2.add(5);
		lista2.add(7);
		lista2.add(8);
		lista2.add(9);
		lista1.add(1);
		lista1.add(2);
		lista1.add(3);
		lista1.add(4);
		incisoG nueva=new incisoG();
		for(int num1:nueva.combinarOrdenado(lista1, lista2)) {
			System.out.println(num1);
		}
	}
	/*b: respecto a la implementacion ninguna
	 * pero es diferente como agrega*/
}
