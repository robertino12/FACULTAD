package tp1.ejercicio7;

import java.util.ArrayList;
import java.util.LinkedList;

public class incisoG {
	public ArrayList<Integer> calcularSucesion (int n,ArrayList<Integer> vec){
		if(n==1) {
			vec.add(n);
		}
		else {
			vec.add(n);
			if((n % 2)==0) {
				n=n/2;
				calcularSucesion(n,vec);
			}
			else {
				n=3*n+1;
				calcularSucesion(n,vec);
			}	
		}
		return vec;
	}
	public void invertir(ArrayList<Integer> lista, int posIni,int posFinal) {
		int aux=0;
		if(posIni<posFinal) {
			aux=lista.get(posIni);
			lista.set(posIni, lista.get(posFinal));
			lista.set(posFinal, aux);
			invertir(lista,posIni+1,posFinal-1);
		}
		if(posIni==0) {
			for(int num:lista) {
				System.out.println(num);
			}
		}
	}
	public void sumar(LinkedList<Integer>lista,int suma,int comienzo) {
		if (comienzo < lista.size()) {
	        suma = suma + lista.get(comienzo);
	        sumar(lista, suma, comienzo + 1);
	    } else {
	        System.out.println(suma);
	    }
	}
	public ArrayList<Integer> combinarOrdenado (ArrayList<Integer>lista1,ArrayList<Integer>lista2){
		ArrayList<Integer> lista3= new ArrayList<>();
		int total=lista1.size()+lista2.size();
		int i=0;
		int j=0;
		if(lista1.get(0)>lista2.get(lista2.size()-1)) {
			while(i<total) {
				if(i<lista2.size()) {
					lista3.add(lista2.get(i));
					i++;
				}
				else {
					lista3.add(lista1.get(j));
					j++;
					i++;
				}
			}	
		}
		else {
			while(i<total) {
				if(i<lista1.size()) {
					lista3.add(lista1.get(i));
					i++;
				}
				else {
					lista3.add(lista2.get(j));
					j++;
					i++;
				}
			}	
		}
		return lista3;
	}//5789
	//1234
}//1234
 //4321
 //10 20 20 50
/*con suma arriba de sumar:
 * entra, 0+10, hace sumar con suma=10
 * 10+20=30, hace sumar con suma=30
 * 30+20=50, hace sumar con suma=50
 * 50+50=100, hace sumar con suma=100
 * vuelve al anterior llamado, suma vuelve a 50
 * vuelve al anterior suma vuelve a 30
 * vuelve al anterior suma vuelve a 10*/
/*con suma abajo de sumar
 * entra, llama a sumar con suma=0
 * llama a sumar con suma=0
 * llama a sumar con suma=0
 * llama a sumar con suma =0
 * vuelve al que llamo y hace 0+20=20
 * vuelve al que llamo pero claro suma antes valia 0, entonces de nuevo 0+20
 * vuelve al que llamo 0+10, por eso imprime 10*/
 /*PARA ARREGLARLO HABIA QUE PONER EL ELSE,sino
  * despues vuelve y suma vale 0 PREGUNTAR*/
 