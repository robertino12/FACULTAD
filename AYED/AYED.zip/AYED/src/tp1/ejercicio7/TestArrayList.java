package tp1.ejercicio7;
import java.util.ArrayList;

public class TestArrayList {
	private ArrayList<Integer> vector= new ArrayList<>();
	
	public TestArrayList(ArrayList<Integer> vector) {
		this.vector=vector;
	}
	public ArrayList<Integer> getVector(){
		return this.vector;
	}
	public void agregarElemento(int numero) {
		vector.add(numero);
	}
	public void muchasAcciones() {
		ArrayList<String> lista= new ArrayList<>();
		lista.add("jorgito");
		lista.add("rober");
		lista.add("tom");
		ArrayList<String>copia= new ArrayList<>();
		//copia=lista;
		copia.addAll(lista);
		for(String nombre:lista) {
			System.out.println(nombre);
		}
		System.out.println("-");
		for(String nombre:copia) {
			System.out.println(nombre);
		}
		lista.set(1,"roberto");
		for(String nombre:lista) {
			System.out.println(nombre);
		}
		System.out.println("-");
		for(String nombre:copia) {
			System.out.println(nombre);
		}
		String newEstudiante="alejo";
		if(!lista.contains(newEstudiante)) {
			lista.add(newEstudiante);
		}
	}
	public boolean esCapicua() {
		int posIni=0;
		boolean esIgual=true;
		int posFinal=this.vector.size()-1;
		while((posIni<=posFinal)&&(posFinal>=posIni)&&(esIgual)){
			if(this.vector.get(posIni)!=this.vector.get(posFinal)) {
				esIgual=false;
			}
			else {
				posIni++;
				posFinal--;
			}
		}
		return esIgual;
	}
	/*CONCLUSIONES:
	 * luego de modificar el contenido de un elemento de la lista original
	 * la lista copia tambien se ve modificada, creo yo porque
	 * lista y copia estan apuntando a la misma direccion de memoria
	 * ya que un arrayList es un objeto creo
	 * entonces cuando hago lista=copia, estoy haciendo que amabas apunten a la misma direccion de memoria
	 * y si modifico una, la otra se vera modificada
	 * si hago una copia independiente con el metodo addAll
	 * y despues modifico la orginial, en la copia no se ve la modificacion*/
}
