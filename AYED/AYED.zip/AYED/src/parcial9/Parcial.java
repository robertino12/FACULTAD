package parcial9;

import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;

import practica5.ejercicio1Grafo.Edge;
import practica5.ejercicio1Grafo.Graph;
import practica5.ejercicio1Grafo.Vertex;
import practica5.ejercicio1Grafo.adjList.AdjListGraph;

public class Parcial {//empece 01:30 termine 01:42
	//se que quieren que en vez de poner un string es poner un objeto, pero solo se usa el nombre, es medio al pedo
	public List<String> resolver(Graph<String> ciudades,String origen,String destino, List<String>pasandoPor){
		List<String> camino=new LinkedList<String>();
		if(!ciudades.isEmpty()) {
			Vertex<String> ori=ciudades.search(origen);
			Vertex<String> dest=ciudades.search(destino);
			if(ori!=null&&dest!=null) {
				resolver(ciudades,ori,destino,pasandoPor,camino,new boolean[ciudades.getSize()]);
			}
		}
		return camino;
	}
	
	private boolean resolver(Graph<String> ciudades,Vertex<String> v,String destino, List<String> pasandoPor, List<String> camino, boolean[]visitados) {
		visitados[v.getPosition()]=true;
		camino.add(v.getData());
		boolean encontre=false;
		if(v.getData().equals(destino)&&camino.containsAll(pasandoPor)) {
			return true;
		}
		else {
			List<Edge<String>> ady=ciudades.getEdges(v);
			Iterator<Edge<String>> it=ady.iterator();
			while(it.hasNext()&&!encontre) {
				Edge<String> arista=it.next();
				if(!visitados[arista.getTarget().getPosition()]) {
					encontre=resolver(ciudades,arista.getTarget(),destino,pasandoPor,camino,visitados);
				}
			}
			if(!encontre) {
				visitados[v.getPosition()]=false;
				camino.remove(camino.size()-1);
			}
		}
		return encontre;
	}
	
	public static void main(String args[]) {
        Graph<String> grafo = new AdjListGraph<String>();
        //Descarte Saladillo, Lobos y Pinamar
        Vertex<String> v1 = grafo.createVertex("Suipacha");
        Vertex<String> v2 = grafo.createVertex("Carlos Keen");
        Vertex<String> v3 = grafo.createVertex("Moreno");
        Vertex<String> v4 = grafo.createVertex("Quilmes");
        Vertex<String> v5 = grafo.createVertex("Navarro");
        Vertex<String> v6 = grafo.createVertex("Cañuelas");
        Vertex<String> v7 = grafo.createVertex("Abasto");
        Vertex<String> v8 = grafo.createVertex("La Plata");
        
        grafo.connect(v1, v2);
        grafo.connect(v2, v1);
        grafo.connect(v2, v3);
        grafo.connect(v3, v2);
        grafo.connect(v3, v4);
        grafo.connect(v4, v3);
        grafo.connect(v1, v5);
        grafo.connect(v5, v1);
        grafo.connect(v5, v6);
        grafo.connect(v6, v5);
        grafo.connect(v6, v7);
        grafo.connect(v7, v6);
        grafo.connect(v7, v3);
        grafo.connect(v3, v7);
        grafo.connect(v7, v8);
        grafo.connect(v8, v7);
        grafo.connect(v8, v4);
        grafo.connect(v4, v8);
        
        Parcial p = new Parcial();
        
        List<String> pasandoPor = new LinkedList<String>();
        
        pasandoPor.add("Quilmes");
        //pasandoPor.add("Abasto");
        pasandoPor.add("Carlos Keen");
        
        System.out.println(p.resolver(grafo, "La Plata", "Suipacha", pasandoPor));
    }
}
