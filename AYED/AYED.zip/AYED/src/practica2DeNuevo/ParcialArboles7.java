package practica2DeNuevo;

import practica2.ejercicio1.BinaryTree;

public class ParcialArboles7 {
	private BinaryTree<Integer> a;
	
	public boolean isLeftTree(int num) {
		if(!this.a.isEmpty()) {
			BinaryTree<Integer> ab=buscarNum(num,this.a);
			if(!ab.isEmpty()) {
				isLeftTree(ab);
			}
		}
		return true;//NO ME SALIO
	}
	
	private int isLeftTree(BinaryTree<Integer>a) {
		int cantNodosUnicoHijoHi=0;
		int cantNodosUnicoHijoHd=0;
		if(a.hasLeftChild()&&!a.hasRightChild()) {
			cantNodosUnicoHijoHd=-1;
			cantNodosUnicoHijoHi=isLeftTree(a.getLeftChild())+1;
		}
		if(!a.hasLeftChild()&&a.hasRightChild()) {
			cantNodosUnicoHijoHi=-1;
			cantNodosUnicoHijoHd=isLeftTree(a.getRightChild())+1;
		}
		if(a.hasLeftChild()) {
			cantNodosUnicoHijoHi=isLeftTree(a.getLeftChild());
		}
		if(a.hasRightChild()) {
			cantNodosUnicoHijoHd=isLeftTree(a.getRightChild());
		}
		if(cantNodosUnicoHijoHi>cantNodosUnicoHijoHd) {
			return cantNodosUnicoHijoHi;
		}
		return 0;
	}
	
	private BinaryTree<Integer> buscarNum(int num,BinaryTree<Integer> a){
		if(a.getData()==num) {
			return a;
		}
		else {
			BinaryTree<Integer> res=new BinaryTree<Integer>();
			if(a.hasLeftChild()) {
				res=buscarNum(num,a.getLeftChild());
			}
			if(a.hasRightChild()) {
				res=buscarNum(num,a.getRightChild());
			}
			return res;
		}
	}
}
