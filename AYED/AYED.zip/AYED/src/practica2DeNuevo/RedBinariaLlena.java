package practica2DeNuevo;

import practica2.ejercicio1.BinaryTree;

public class RedBinariaLlena {
	public int retardoReenvio(BinaryTree<Integer> a) {
		int max=0;
		if(!a.isEmpty()) {
			max=retardoReenvio(a,0);
		}
		return max;
	}
	
	private int retardoReenvio(BinaryTree<Integer> a, int retardo) {
		int retardoMaxHi=0;
		int retardoMaxHd=0;
		retardo+=a.getData();
		if(a.isLeaf()) {
			return retardo;
		}
		else {
			if(a.hasLeftChild()) {
				retardoMaxHi=retardoReenvio(a.getLeftChild(),retardo);
			}
			if(a.hasRightChild()) {
				retardoMaxHd=retardoReenvio(a.getRightChild(),retardo);
			}
			return Math.max(retardoMaxHi, retardoMaxHd);
		}
		//va sacando los retardos de hijo izq y derecho y los compara
	}
	
	public static void main(String[] args) {
		BinaryTree<Integer> arbol=new BinaryTree<>(1);
		BinaryTree<Integer> hijoIzq=new BinaryTree<>(2);
		hijoIzq.addLeftChild(new BinaryTree<Integer>(4));
		hijoIzq.addRightChild(new BinaryTree<Integer>(10));
		BinaryTree<Integer> hijoDer=new BinaryTree<>(3);
		hijoDer.addLeftChild(new BinaryTree<Integer>(6));
		hijoDer.addRightChild(new BinaryTree<Integer>(7));
		arbol.addLeftChild(hijoIzq);
		arbol.addRightChild(hijoDer);
		RedBinariaLlena obj=new RedBinariaLlena();
		System.out.println(obj.retardoReenvio(arbol));
	}
}
