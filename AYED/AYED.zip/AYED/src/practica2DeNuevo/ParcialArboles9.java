package practica2DeNuevo;

import practica2.ejercicio1.BinaryTree;

public class ParcialArboles9 {
	public BinaryTree<SumDif> sumAndDif(BinaryTree<Integer> a){
		BinaryTree<SumDif> nuevo=new BinaryTree<SumDif>();
		if(!a.isEmpty()) {
			sumAndDif(a,nuevo,0,0);
		}
		return nuevo;
	}
	
	private void sumAndDif(BinaryTree<Integer> a, BinaryTree<SumDif> nuevo, int suma, int resta) {
		SumDif obj= new SumDif(a.getData()+suma,a.getData()-resta);
		nuevo.setData(obj);
		if(a.hasLeftChild()) {
			nuevo.addLeftChild(new BinaryTree<SumDif>());
			sumAndDif(a.getLeftChild(),nuevo.getLeftChild(),a.getData()+suma,a.getData());
		}
		if(a.hasRightChild()) {
			nuevo.addRightChild(new BinaryTree<SumDif>());
			sumAndDif(a.getRightChild(),nuevo.getRightChild(),a.getData()+suma,a.getData());
		}
	}
	
	public void imprimirArbolObj(BinaryTree<SumDif> arbol) {
		System.out.println("suma: "+arbol.getData().getSuma() + " resta: "+arbol.getData().getDiferencia());
	    if(arbol.hasLeftChild()) imprimirArbolObj(arbol.getLeftChild());
	    if(arbol.hasRightChild()) imprimirArbolObj(arbol.getRightChild());
	}
	
	public static void main(String[] args) {
		BinaryTree<Integer> arbol=new BinaryTree<>(20);
		BinaryTree<Integer> hijoIzq=new BinaryTree<>(5);
		hijoIzq.addLeftChild(new BinaryTree<Integer>(-5));
		hijoIzq.addRightChild(new BinaryTree<Integer>(10));
		arbol.addLeftChild(hijoIzq);
		BinaryTree<Integer> hijoDer=new BinaryTree<>(30);
		hijoDer.addLeftChild(new BinaryTree<Integer>(50));
		hijoDer.addRightChild(new BinaryTree<Integer>(-9));
		arbol.addRightChild(hijoDer);
		
		ParcialArboles9 obj=new ParcialArboles9();
		BinaryTree<SumDif> a=obj.sumAndDif(arbol);
		obj.imprimirArbolObj(a);
	}
}
