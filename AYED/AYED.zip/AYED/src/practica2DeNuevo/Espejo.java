package practica2DeNuevo;

import practica2.ejercicio1.BinaryTree;

public class Espejo {
	public BinaryTree<Integer> espejo(BinaryTree<Integer> a){
		BinaryTree<Integer> esp=null;
		if(!a.isEmpty()) {
			esp=new BinaryTree<Integer>();esp.setData(a.getData());
			espejo(a,esp);
		}
		return esp;
	} 
	
	private void espejo(BinaryTree<Integer> a,BinaryTree<Integer> esp) {
		if(a.hasLeftChild()) {
			esp.addRightChild(new BinaryTree<Integer>(a.getLeftChild().getData()));
			espejo(a.getLeftChild(),esp.getRightChild());
		}
		if(a.hasRightChild()) {
			esp.addLeftChild(new BinaryTree<Integer>(a.getRightChild().getData()));
			espejo(a.getRightChild(),esp.getLeftChild());
		}
		
	}
	
	public void imprimirArbol(BinaryTree<Integer> a) {
        if(a.hasLeftChild()) a.getLeftChild().imprimirArbol();
        System.out.print(a.getData() + " ");
        if(a.hasRightChild()) a.getRightChild().imprimirArbol();
    }
	
	public static void main(String[] args) {
		BinaryTree<Integer> arbol=new BinaryTree<>(1);
		BinaryTree<Integer> hijoIzq=new BinaryTree<>(2);
		hijoIzq.addLeftChild(new BinaryTree<Integer>(4));
		hijoIzq.addRightChild(new BinaryTree<Integer>(5));
		BinaryTree<Integer> hijoDer=new BinaryTree<>(3);
		hijoDer.addLeftChild(new BinaryTree<Integer>(6));
		hijoDer.addRightChild(new BinaryTree<Integer>(7));
		arbol.addLeftChild(hijoIzq);
		arbol.addRightChild(hijoDer);
		System.out.println("arbol comun");
		Espejo ejB=new Espejo();
		ejB.imprimirArbol(arbol);
		System.out.println("\n"+"arbol espejo");
		BinaryTree<Integer> ab=ejB.espejo(arbol);
		ejB.imprimirArbol(ab);
	}
}
