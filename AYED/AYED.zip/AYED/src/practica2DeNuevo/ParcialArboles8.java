package practica2DeNuevo;

import practica2.ejercicio1.BinaryTree;

public class ParcialArboles8 {
	public boolean esPrefijo(BinaryTree<Integer> a1,BinaryTree<Integer> a2) {
		boolean res=false;
		if(!a1.isEmpty()||!a2.isEmpty()) {	
			res=esPrefijoH(a1,a2);
		}
		return res;
	}
	
	private boolean esPrefijoH(BinaryTree<Integer> a1,BinaryTree<Integer> a2) {
		if(a1.getData()!=a2.getData()) {
			return false;
		}
		else {
			boolean esPrefijo=true;
			//boolean esPrefijoHd=true;
			if(a1.hasLeftChild()) {
				if(a2.hasLeftChild())
					esPrefijo=esPrefijoH(a1.getLeftChild(),a2.getLeftChild());
				else
					esPrefijo=false;
			}
			if(a1.hasRightChild()) {
				if(a2.hasRightChild())
					esPrefijo=esPrefijoH(a1.getRightChild(),a2.getRightChild());
				else
					esPrefijo=false;
			}
			if(esPrefijo==true) {
				return true;
			}
			else return false;
		}
	}
	
	public static void main(String[] args) {
		BinaryTree<Integer> arbol1=new BinaryTree<>(65);
		BinaryTree<Integer> hijoIzq1=new BinaryTree<>(37);
		hijoIzq1.addRightChild(new BinaryTree<Integer>(47));
		arbol1.addLeftChild(hijoIzq1);
		BinaryTree<Integer> hijoDer1=new BinaryTree<>(81);
		hijoDer1.addRightChild(new BinaryTree<Integer>(93));
		arbol1.addRightChild(hijoDer1);
		BinaryTree<Integer> arbol2=new BinaryTree<>(65);
		BinaryTree<Integer> hijoIzq=new BinaryTree<>(37);
		hijoIzq.addLeftChild(new BinaryTree<Integer>(22));
		hijoIzq.addRightChild(new BinaryTree<Integer>(47));
		arbol2.addLeftChild(hijoIzq);
		BinaryTree<Integer> hijoDer=new BinaryTree<>(81);
		hijoDer.addLeftChild(new BinaryTree<Integer>(76));
		hijoDer.addRightChild(new BinaryTree<Integer>(93));
		arbol2.addRightChild(hijoDer);
		ParcialArboles8 obj=new ParcialArboles8();
		System.out.println(obj.esPrefijo(arbol1, arbol2));
	}
}
