package practica2DeNuevo;

import practica2.ejercicio1.BinaryTree;

public class ContarHojas {
	
	public int contarHojas(BinaryTree<Integer> arbol) {
		int cant=0;
		if(!arbol.isEmpty()) {
			cant=contar(arbol);
		}
		return cant;//devuelve 0 si esta vacio
	}
	private int contar(BinaryTree<Integer> arbol) {
		int cantHojasHi=0;
		int cantHojasHd=0;
		if(arbol.isLeaf()) {
			return 1;
		}
		else {
			if(arbol.hasLeftChild()) {
				cantHojasHi=contarHojas(arbol.getLeftChild());
			}
			if(arbol.hasRightChild()) {
				cantHojasHd=contarHojas(arbol.getRightChild());
			}
			return cantHojasHi+cantHojasHd;
		}
	}
	
	public static void main(String[] args) {
		BinaryTree<Integer> arbol=new BinaryTree<>(1);
		BinaryTree<Integer> hijoIzq=new BinaryTree<>(2);
		hijoIzq.addLeftChild(new BinaryTree<Integer>(4));
		hijoIzq.addRightChild(new BinaryTree<Integer>(5));
		BinaryTree<Integer> hijoDer=new BinaryTree<>(3);
		hijoDer.addLeftChild(new BinaryTree<Integer>(6));
		hijoDer.addRightChild(new BinaryTree<Integer>(7));
		arbol.addLeftChild(hijoIzq);
		arbol.addRightChild(hijoDer);
		ContarHojas ej2=new ContarHojas();
		System.out.println(ej2.contarHojas(arbol));
	}
}
