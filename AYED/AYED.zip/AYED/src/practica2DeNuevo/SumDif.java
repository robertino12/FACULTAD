package practica2DeNuevo;

public class SumDif {
	private int suma;
	private int diferencia;
	
	public SumDif(int suma, int diferencia) {
		this.suma = suma;
		this.diferencia = diferencia;
	}
	public int getSuma() {
		return suma;
	}
	public void setSuma(int suma) {
		this.suma = suma;
	}
	public int getDiferencia() {
		return diferencia;
	}
	public void setDiferencia(int diferencia) {
		this.diferencia = diferencia;
	}
	
	
}
