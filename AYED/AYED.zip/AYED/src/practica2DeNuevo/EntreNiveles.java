package practica2DeNuevo;

import practica2.ejercicio1.BinaryTree;
import tp1.ejercicio8.Queue;

public class EntreNiveles {
	public void entreNiveles(int n,int m,BinaryTree<Integer> a) {
		if(a.isEmpty()) {
			System.out.println("arbol vacio");
		}{
			if(n>=0) {
				Queue<BinaryTree<Integer>> cola=new Queue<BinaryTree<Integer>>();
				BinaryTree<Integer> aux;
				cola.enqueue(a);
				cola.enqueue(null);
				int nivel=0;
				while(!cola.isEmpty()&&nivel<=m) {
					aux=cola.dequeue();
					if(aux!=null) {
						if(nivel>=n) {
							System.out.println(aux.getData());
						}
						if(aux.hasLeftChild()) {
							cola.enqueue(aux.getLeftChild());
						}	
						if(aux.hasRightChild()) {
							cola.enqueue(aux.getRightChild());
						}
					}
					else if(nivel<=m) {
						nivel++;
						cola.enqueue(null);
					}
				}
			}
			else {
				System.out.println("n es menor que 0");
			}
		}
	}
	
	public static void main(String[] args) {
		BinaryTree<Integer> arbol=new BinaryTree<>(1);
		BinaryTree<Integer> hijoIzq=new BinaryTree<>(2);
		hijoIzq.addLeftChild(new BinaryTree<Integer>(4));
		hijoIzq.addRightChild(new BinaryTree<Integer>(5));
		BinaryTree<Integer> hijoDer=new BinaryTree<>(3);
		hijoDer.addLeftChild(new BinaryTree<Integer>(6));
		hijoDer.addRightChild(new BinaryTree<Integer>(7));
		arbol.addLeftChild(hijoIzq);
		arbol.addRightChild(hijoDer);
		System.out.println("arbol niveles");
		EntreNiveles ejC=new EntreNiveles();
		ejC.entreNiveles(1, 2,arbol);
	}
}
