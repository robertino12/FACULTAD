package practica2DeNuevo;

import java.util.LinkedList;
import java.util.List;

import practica2.ejercicio1.BinaryTree;

public class ContadorArbol {
	private BinaryTree<Integer> a;
	
	public ContadorArbol(BinaryTree<Integer> a) {
		this.a=a;
	}
	
	public List<Integer> numerosPares(){
		List<Integer> numeros=new LinkedList<Integer>();
		if(!a.isEmpty()) {
			//numerosParesPreOrden(numeros,this.a);
			//numerosParesInOrden(numeros,this.a);
			numerosParesPostOrden(numeros,this.a);
		}
		return numeros;
	}
	
	/*private void numerosParesPreOrden(List<Integer> numeros,BinaryTree<Integer> a){
		if(a.getData()%2==0) {
			numeros.add(a.getData());
		}
		if(a.hasLeftChild()) {
			numerosParesPreOrden(numeros,a.getLeftChild());
		}
		if(a.hasRightChild()) {
			numerosParesPreOrden(numeros,a.getRightChild());
		}
	}*/
	
	/*private void numerosParesInOrden(List<Integer> numeros,BinaryTree<Integer> a){
		if(a.hasLeftChild()) {
			numerosParesInOrden(numeros,a.getLeftChild());
		}
		if(a.getData()%2==0) {
			numeros.add(a.getData());
		}
		if(a.hasRightChild()) {
			numerosParesInOrden(numeros,a.getRightChild());
		}
	}*/
	
	private void numerosParesPostOrden(List<Integer> numeros,BinaryTree<Integer> a){
		if(a.hasLeftChild()) {
			numerosParesPostOrden(numeros,a.getLeftChild());
		}	
		if(a.hasRightChild()) {
			numerosParesPostOrden(numeros,a.getRightChild());
		}
		if(a.getData()%2==0) {
			numeros.add(a.getData());
		}
	}
	
	public static void main(String[] args) {
		BinaryTree<Integer> arbol=new BinaryTree<>(1);
		BinaryTree<Integer> hijoIzq=new BinaryTree<>(2);
		hijoIzq.addLeftChild(new BinaryTree<Integer>(4));
		hijoIzq.addRightChild(new BinaryTree<Integer>(5));
		BinaryTree<Integer> hijoDer=new BinaryTree<>(3);
		hijoDer.addLeftChild(new BinaryTree<Integer>(6));
		hijoDer.addRightChild(new BinaryTree<Integer>(7));
		arbol.addLeftChild(hijoIzq);
		arbol.addRightChild(hijoDer);
		ContadorArbol obj=new ContadorArbol(arbol);
		System.out.println(obj.numerosPares());
	}
}
