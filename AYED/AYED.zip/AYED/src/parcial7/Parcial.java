package parcial7;

import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;

import practica5.ejercicio1Grafo.Edge;
import practica5.ejercicio1Grafo.Graph;
import practica5.ejercicio1Grafo.Vertex;
import practica5.ejercicio1Grafo.adjList.AdjListGraph;

public class Parcial {//empece 00:09 termine 00:35
	public List<String> recorrido(Graph<String> grafo, int cantLocalidades, int cantNafta, List<String> localidadesExceptuadas){
		List<String> camino=new LinkedList<String>();
		if(!grafo.isEmpty()) {
			Vertex<String> v=grafo.search("Mendoza");
			if(v!=null) {
				int litrosConsumidos=0;
				recorrido(grafo,v,cantLocalidades,cantNafta,localidadesExceptuadas,litrosConsumidos,new boolean[grafo.getSize()],camino);
			}
		}
		return camino;
	}
	
	private boolean recorrido(Graph<String> grafo,Vertex<String> v,int cantLocalidades,int cantNafta,List<String> localidadesExceptuadas,int litrosConsumidos,boolean[] visitados,List<String> camino) {
		visitados[v.getPosition()]=true;
		camino.add(v.getData());
		boolean encontre=false;
		if(camino.size()>=cantLocalidades&&litrosConsumidos<=cantNafta) {
			return true;
		}
		else {
			List<Edge<String>> ady=grafo.getEdges(v);
			Iterator<Edge<String>> it=ady.iterator();
			while(it.hasNext()&&!encontre&&litrosConsumidos<=cantNafta) {
				Edge<String> arista=it.next();
				int aux=litrosConsumidos+arista.getWeight();
				if(!visitados[arista.getTarget().getPosition()]&&aux<=cantNafta&&!localidadesExceptuadas.contains(arista.getTarget().getData())) {
					encontre=recorrido(grafo,arista.getTarget(),cantLocalidades,cantNafta,localidadesExceptuadas,aux,visitados,camino);
				}
			}
			if(!encontre) {
				visitados[v.getPosition()]=false;
				camino.remove(camino.size()-1);
			}
		}
		return encontre;
	}
	
	public static void main(String args[]) {
        Graph<String> grafo = new AdjListGraph<String>();
        Vertex<String> v1 = grafo.createVertex("Mendoza");
        Vertex<String> v2 = grafo.createVertex("Tunuyán");
        Vertex<String> v3 = grafo.createVertex("San Martin");
        Vertex<String> v4 = grafo.createVertex("La Paz");
        Vertex<String> v5 = grafo.createVertex("Santa Rosa");
        Vertex<String> v6 = grafo.createVertex("San Rafael");
        Vertex<String> v7 = grafo.createVertex("Malargue");
        Vertex<String> v8 = grafo.createVertex("General Alvear");
        
        grafo.connect(v1, v2, 10);
        grafo.connect(v1, v3, 6);
        grafo.connect(v2, v3, 10);
        grafo.connect(v3, v4, 8);
        grafo.connect(v4, v5, 2);
        grafo.connect(v3, v6, 13);
        grafo.connect(v6, v2, 11);
        grafo.connect(v6, v8, 7);
        grafo.connect(v2, v7, 12);
        grafo.connect(v8, v7, 6);
        
        List<String> localidadesExceptuadas = new LinkedList<String>();
        localidadesExceptuadas.add("General Alvear");
        localidadesExceptuadas.add("La Paz");
        
        Parcial p = new Parcial();
        
        System.out.println(p.recorrido(grafo, 5, 80, localidadesExceptuadas));
    }
}
