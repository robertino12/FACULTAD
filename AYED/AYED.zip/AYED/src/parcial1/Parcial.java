package parcial1;

import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;

import practica5.ejercicio1Grafo.Edge;
import practica5.ejercicio1Grafo.Graph;
import practica5.ejercicio1Grafo.Vertex;
import practica5.ejercicio1Grafo.adjList.AdjListGraph;

public class Parcial {//empece 13:44 termine 15:03
	public List<String> resolver(Graph<Ciudad> mapa,String ciudad, int cantDiasVacas){
		List<String> caminoMax=new LinkedList<String>();
		Vertex<Ciudad> v=buscarOrigen(mapa,ciudad);
		if(!mapa.isEmpty()) {
			if(v!=null) {
			if(v.getData().getCantDias()<=cantDiasVacas) {
				int cantCiudadesRecorridas=1;
				int cantDiasUsados=v.getData().getCantDias();
				boolean[] visitados=new boolean[mapa.getSize()];
				List<String> caminoAct=new LinkedList<String>();
				resolver(mapa,v,cantDiasVacas,cantCiudadesRecorridas,0,cantDiasUsados,visitados,caminoAct,caminoMax);
			}
			}
		}
		
		return caminoMax;
	}
	
	private int resolver(Graph<Ciudad> mapa,Vertex<Ciudad> v,int cantDiasVacas,int cantCiudadesRecorridas,int cantCiudadesMax,int cantDiasUsados,boolean visitados[],List<String> caminoAct,List<String> caminoMax) {
		visitados[v.getPosition()]=true;
		caminoAct.add(v.getData().getNombre());
		if(cantDiasUsados==cantDiasVacas&&cantCiudadesRecorridas>cantCiudadesMax) {
			caminoMax.removeAll(caminoMax);
			caminoMax.addAll(caminoAct);
			cantCiudadesMax=cantCiudadesRecorridas;
		}
		else {
			List<Edge<Ciudad>> ady=mapa.getEdges(v);
			Iterator<Edge<Ciudad>> it=ady.iterator();
			while(it.hasNext()&&cantDiasUsados<=cantDiasVacas) {
				Edge<Ciudad> arista=it.next();
				int aux=cantDiasUsados+arista.getTarget().getData().getCantDias();
				if(!visitados[arista.getTarget().getPosition()]&&aux<=cantDiasVacas) {
					cantCiudadesMax=resolver(mapa,arista.getTarget(),cantDiasVacas,cantCiudadesRecorridas++,cantCiudadesMax,aux,visitados,caminoAct,caminoMax);
				}
			}
		}
		visitados[v.getPosition()]=false;
		caminoAct.remove(caminoAct.size()-1);
		return cantCiudadesMax;
	}
	
	private Vertex<Ciudad> buscarOrigen(Graph<Ciudad> mapa,String ciudad) {
		Vertex<Ciudad> v=null;
		boolean encontro=false;
		List<Vertex<Ciudad>> vertices=mapa.getVertices();
		Iterator<Vertex<Ciudad>> it=vertices.iterator();
		while(it.hasNext()&&!encontro) {
			v=it.next();
			if(v.getData().getNombre().equals(ciudad)) {
				encontro=true;
			}
		}
		return v;
	}
	
	public static void main(String args[]) {
        Graph<Ciudad> mapa = new AdjListGraph<Ciudad>();
        Vertex<Ciudad> MarDelPlata = mapa.createVertex(new Ciudad(7, "Mar Del Plata"));
        Vertex<Ciudad> Pila = mapa.createVertex(new Ciudad(1, "Pila"));
        Vertex<Ciudad> Dolores = mapa.createVertex(new Ciudad(1, "Dolores"));
        Vertex<Ciudad> Chascomus = mapa.createVertex(new Ciudad(1, "Chascomús"));
        Vertex<Ciudad> MarAzul = mapa.createVertex(new Ciudad(3, "Mar Azul"));
        Vertex<Ciudad> Pinamar = mapa.createVertex(new Ciudad(4, "Pinamar"));
        Vertex<Ciudad> Madariaga = mapa.createVertex(new Ciudad(1, "Madariaga"));
        Vertex<Ciudad> LaPlata = mapa.createVertex(new Ciudad(5, "La Plata"));
        Vertex<Ciudad> LasGaviotas = mapa.createVertex(new Ciudad(1, "Las Gaviotas"));
        Vertex<Ciudad> Querandi = mapa.createVertex(new Ciudad(1, "Querandi"));
        Vertex<Ciudad> Hudson = mapa.createVertex(new Ciudad(1, "Hudson"));
        
        mapa.connect(MarDelPlata, Pila);
        mapa.connect(Pila, MarDelPlata);
        mapa.connect(Pila, Dolores);
        mapa.connect(Dolores, Pila);
        mapa.connect(Dolores, Chascomus);
        mapa.connect(Chascomus, Dolores);
        
        mapa.connect(MarDelPlata, MarAzul);
        mapa.connect(MarAzul, MarDelPlata);
        mapa.connect(MarAzul, Pinamar);
        mapa.connect(Pinamar, MarAzul);
        mapa.connect(Pinamar, Madariaga);
        mapa.connect(Madariaga, Pinamar);
        mapa.connect(Dolores, Madariaga);
        mapa.connect(Madariaga, Dolores);
        mapa.connect(Madariaga, LaPlata);
        mapa.connect(LaPlata, Madariaga);
        mapa.connect(Chascomus, LaPlata);
        mapa.connect(LaPlata, Chascomus);
        
        mapa.connect(MarAzul, LasGaviotas);
        mapa.connect(LasGaviotas, MarAzul);
        mapa.connect(MarAzul, Querandi);
        mapa.connect(Querandi, MarAzul);
        mapa.connect(LaPlata, Hudson);
        mapa.connect(Hudson, LaPlata);
        
        Parcial p = new Parcial();
        System.out.println(p.resolver(mapa, "Mar Del Plata", 5));
    }
}
