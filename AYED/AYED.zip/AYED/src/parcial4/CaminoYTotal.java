package parcial4;

import java.util.LinkedList;

public class CaminoYTotal {
	private LinkedList<String> camino;
	private int tiempoTotal;
	
	public CaminoYTotal(LinkedList<String> camino, int tiempoTotal) {
		this.camino = camino;
		this.tiempoTotal = tiempoTotal;
	}
	
	public LinkedList<String> getCamino() {
		return camino;
	}
	public void setCamino(LinkedList<String> camino) {
		this.camino = camino;
	}
	public int getTiempoTotal() {
		return tiempoTotal;
	}
	public void setTiempoTotal(int tiempoTotal) {
		this.tiempoTotal = tiempoTotal;
	}
	
	
}
