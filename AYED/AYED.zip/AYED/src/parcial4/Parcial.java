package parcial4;

import java.util.LinkedList;
import java.util.List;

import practica5.ejercicio1Grafo.Edge;
import practica5.ejercicio1Grafo.Graph;
import practica5.ejercicio1Grafo.Vertex;
import practica5.ejercicio1Grafo.adjList.AdjListGraph;

public class Parcial {
	public List<CaminoYTotal> resolver(Graph<String> sitios,String origen,String destino, List<String> evitarPasarPor){
		List<CaminoYTotal> camino=new LinkedList<CaminoYTotal>();
		if(!sitios.isEmpty()) {
			Vertex<String> v1=sitios.search(origen);
			Vertex<String> v2=sitios.search(destino);
			if(v1!=null&&v2!=null) {
				resolver(sitios,camino,v1,destino,new boolean[sitios.getSize()],0,new LinkedList<String>(),evitarPasarPor);
			}
		}
		return camino;
	}
	
	private void resolver(Graph<String> sitios,List<CaminoYTotal> caminoTotal,Vertex<String> v,String destino,boolean[] visitados, int distTotal, LinkedList<String> caminoAct,List<String> evitar) {
		visitados[v.getPosition()]=true;
		caminoAct.add(v.getData());
		if(v.getData().equals(destino)) {
			CaminoYTotal obj=new CaminoYTotal(new LinkedList<String>(caminoAct),distTotal);
			caminoTotal.add(obj);
		}
		else {
			List<Edge<String>> ady=sitios.getEdges(v);
			for(Edge<String> arista:ady) {
				int aux=distTotal+arista.getWeight();
				if(!visitados[arista.getTarget().getPosition()]&&!evitar.contains(arista.getTarget().getData())) {
					resolver(sitios,caminoTotal,arista.getTarget(),destino,visitados,aux,caminoAct,evitar);
				}
			}
		}
		visitados[v.getPosition()]=false;
		caminoAct.remove(caminoAct.size()-1);
	}
	
	public static void main(String args[]) {
        Graph<String> grafo = new AdjListGraph<String>();
        Vertex<String> v1 = grafo.createVertex("Estadio Diego Armando Maradona");
        Vertex<String> v2 = grafo.createVertex("Legislatura");
        Vertex<String> v3 = grafo.createVertex("Coliseo Podestá");
        Vertex<String> v4 = grafo.createVertex("MACLA");
        Vertex<String> v5 = grafo.createVertex("Catedral La Plata");
        Vertex<String> v6 = grafo.createVertex("Palacio Campodónico");
        Vertex<String> v7 = grafo.createVertex("Rectorado UNLP");
        Vertex<String> v8 = grafo.createVertex("Museo UNLP");
        
        grafo.connect(v1, v2, 25);
        grafo.connect(v2, v1, 25);
        grafo.connect(v1, v3, 20);
        grafo.connect(v3, v1, 20);
        grafo.connect(v1, v4, 35);
        grafo.connect(v4, v1, 35);
        grafo.connect(v1, v5, 40);
        grafo.connect(v5, v1, 40);
        grafo.connect(v2, v3, 25);
        grafo.connect(v3, v2, 25);
        grafo.connect(v4, v5, 8);
        grafo.connect(v5, v4, 8);
        grafo.connect(v5, v7, 5);
        grafo.connect(v7, v5, 5);
        grafo.connect(v3, v6, 10);
        grafo.connect(v6, v3, 10);
        grafo.connect(v6, v7, 30);
        grafo.connect(v7, v6, 30);
        grafo.connect(v7, v8, 15);
        grafo.connect(v8, v7, 15);
        
        List<String> evitarPasarPor = new LinkedList<String>();
        evitarPasarPor.add("Legislatura");
        evitarPasarPor.add("MACLA");
        
        Parcial p = new Parcial();
        List<CaminoYTotal> lis = p.resolver(grafo, "Estadio Diego Armando Maradona", "Palacio Campodónico", evitarPasarPor);
        
        for(CaminoYTotal aux: lis) {
            System.out.println(aux.getCamino());
            System.out.println(aux.getTiempoTotal()   );
        }
    }
}
