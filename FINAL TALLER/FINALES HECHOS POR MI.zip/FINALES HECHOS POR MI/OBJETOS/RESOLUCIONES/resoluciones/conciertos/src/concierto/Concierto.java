package concierto;

public class Concierto {
    private String nombreArtista;
    private int precioEntrada;
    private int cantEntradasVendidas;

    public Concierto(String nombreArtista, int precioEntrada, int cantEntradasVendidas) {
        this.nombreArtista = nombreArtista;
        this.precioEntrada = precioEntrada;
        this.cantEntradasVendidas = cantEntradasVendidas;
    }

    private String getNombreArtista() {
        return nombreArtista;
    }


    public int getPrecioEntrada() {
        return precioEntrada;
    }


    public int getCantEntradasVendidas() {
        return cantEntradasVendidas;
    }


    @Override
    public String toString() {
        return "Concierto{" + "nombreArtista=" + this.getNombreArtista() + ", precioEntrada=" + this.getPrecioEntrada() + ", cantEntradasVendidas=" + this.getCantEntradasVendidas() + '}';
    }
    
    
}
