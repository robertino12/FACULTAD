package concierto;

public class EstadioMain {

    public static void main(String[] args) {
        Estadio estadio=new Estadio("zerillo","118y60",30000);
        Concierto emilia=new Concierto("emilia",150,100);
        Concierto duki=new Concierto("mauro",200,100);
        Concierto khea=new Concierto("khea",100,100);
        Concierto cro=new Concierto("tomas",125,100);
        estadio.registrarConcierto(emilia, 4);
        estadio.registrarConcierto(duki, 8);
        estadio.registrarConcierto(khea, 2);
        estadio.registrarConcierto(cro, 8);
        System.out.println("la ganancia es: "+estadio.calcularGananciaEstadio(8));
        System.out.println(estadio.listarConciertos(8));
        System.out.println(estadio.toString());
    }
    
}
