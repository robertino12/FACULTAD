package concierto;

public class Estadio {
    private String nombre;
    private String direccion;
    private int capacidad;
    private Concierto [][] agenda;
    //private int dimLFila,dimLCol;//en este caos no sirven porque agrega conciertos en cualq mes
    //x ende si pongo uno en el mes 4, va a sumarse uno la diml y si recorro por tope de diml nunca va a llegar al mes 4
    private int dimFFila,dimFCol;
    
    public Estadio(String nombre, String direccion, int capacidad){
        this.nombre=nombre;
        this.direccion=direccion;
        this.capacidad=capacidad;
        this.dimFFila=12;
        this.dimFCol=31;
        this.agenda= new Concierto[this.dimFFila][this.dimFCol];
    }

    private String getNombre() {
        return nombre;
    }

    private String getDireccion() {
        return direccion;
    }

    private int getCapacidad() {
        return capacidad;
    }


    private Concierto[][] getAgenda() {
        return agenda;
    }

    private int getDimFFila() {
        return dimFFila;
    }


    private int getDimFCol() {
        return dimFCol;
    }

    
    public void registrarConcierto(Concierto c,int mes){
        int i=0;
        boolean registrado=false;
        while((i<this.getDimFCol())&&(registrado==false)){//mientras no llegue al final de la fila en el mes dado
            if(this.getAgenda()[mes][i]==null){
                this.getAgenda()[mes][i]=c;
                registrado=true;
            }
            else
                i++;
        }
    }
    
    public String listarConciertos(int mes){
        String aux=" ";
            int j=0;
            boolean parar=false;
            while((j<this.getDimFCol())&&(parar==false)){
                if(this.getAgenda()[mes][j]==null){
                    parar=true;
                }
                else{
                    aux+="en el mes: "+(mes+1)+" y en el dia: "+(j+1)+" = "+this.getAgenda()[mes][j].toString()+"\n";
                    j++;
                }    
            }
        return aux;
    }
    
    public int calcularGananciaEstadio(int mes){
        boolean parar=false;
        int i=0;
        int cantPlataEntradasVend=0;
        while((i<this.getDimFCol())&&(parar==false)){
            if(this.getAgenda()[mes][i]==null){
                parar=true;
            }
            else{
                cantPlataEntradasVend+=this.getAgenda()[mes][i].getPrecioEntrada()*this.getAgenda()[mes][i].getCantEntradasVendidas();
                i++;
            }
        }
        return cantPlataEntradasVend/2;
    } 
    
    @Override
    public String toString(){
        String aux="estadio: "+this.getNombre()+", direccion: "+this.getDireccion()+" y capacidad: "+this.getCapacidad()+"\n";
        int i=0;
        while(i<this.getDimFFila()){
            int j=0;
            boolean parar=false;
            aux+="mes: "+(i+1)+"\n";
            while((j<this.getDimFCol())&&(parar==false)){
                if(this.getAgenda()[i][j]==null){
                    parar=true;
                }
                else {
                    aux+="dia: "+(j+1)+": "+this.getAgenda()[i][j].toString()+"\n";
                    j++;
                }     
            }//con tan solo que el primer elemento de la fila tal columna 1 sea null, ya habilita a pasar de columna
            //hay q recorrer cada columan xq no sabemos en q mes hay conciertos, puede haber en uno si y otro no
            i++;
        }
        return aux;
    }
}
