package alumno;

public class AlumnoDoctorado extends Alumno{
    private String titulo;
    private String universidadOrigen;

    public AlumnoDoctorado(String titulo, String universidadOrigen, int dni, String nombre, int dimF) {
        super(dni, nombre, dimF);
        this.titulo = titulo;
        this.universidadOrigen = universidadOrigen;
    }

    public String getTitulo() {
        return titulo;
    }

    public void setTitulo(String titulo) {
        this.titulo = titulo;
    }

    public String getUniversidadOrigen() {
        return universidadOrigen;
    }

    public void setUniversidadOrigen(String universidadOrigen) {
        this.universidadOrigen = universidadOrigen;
    }
    
    @Override
    public String toString() {
        return super.toString()+" con el titulo de: "+this.getTitulo()+" en la universidad de origen: "+this.getUniversidadOrigen();
        
    }
}
