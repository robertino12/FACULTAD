package alumno;

public abstract class Alumno {
    private int dni;
    private String nombre;
    private MateriasAprobadas [] vectorMatA;
    private int dimL,dimF;

    public Alumno(int dni, String nombre, int dimF) {
        this.dni = dni;
        this.nombre = nombre;
        this.dimF = dimF;
        this.dimL = 0;
        this.vectorMatA = new MateriasAprobadas[this.dimF];
    }

    public int getDni() {
        return dni;
    }

    private void setDni(int dni) {
        this.dni = dni;
    }

    public String getNombre() {
        return nombre;
    }

    private void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public MateriasAprobadas[] getVectorMatA() {
        return vectorMatA;
    }

    public int getDimL() {
        return dimL;
    }

    private void setDimL(int dimL) {
        this.dimL = dimL;
    }

    private int getDimF() {
        return dimF;
    }

    private void setDimF(int dimF) {
        this.dimF = dimF;
    }
    
    public void agregarMateriaAprobada (MateriasAprobadas mat){
        if(this.getDimL()<this.getDimF()){
            this.getVectorMatA()[this.getDimL()]=mat;
            this.setDimL(this.getDimL()+1);
        }
    }
    
    //preguntar si va aca, xq un alumno doctorado se supone q esta graduado, pero no se que es alumno de grado
    //osea si es alumno doctorado es al pedo preguntar si esta graduado o no
    //al parecer va aca porque el string dice que un algumno de grado esta graduado y pone como para poner false o true
    
    //
    public boolean estaGraduado(){
        int cantMatAprob=this.getDimF();
        boolean aux=false;
        boolean estaTesis=false;
        int i=0;
        while((i<this.getDimL())&&(estaTesis==false)){
            if(this.getVectorMatA()[i].getNombre().equals("tesis")){
                estaTesis=true;
            }
            i++;
        }
        if((this.getDimL()==cantMatAprob)&&(estaTesis==true)){//si dimL igual a dimF-1 y esta tesis quiere decir que esta graduado
            aux=true;
        }
        return aux;
    }
    @Override
    public String toString() {
        String aux="DNI: "+this.getDni()+"nombre: "+this.getNombre()+" esta graduado: "+this.estaGraduado()+" y sus materias aprobadas son: "+"\n";
        int i=0;
        while(i<this.getDimL()){
            aux+=(i+1)+this.getVectorMatA()[i].toString();
            i++;
        }
        return aux;
    }
}
