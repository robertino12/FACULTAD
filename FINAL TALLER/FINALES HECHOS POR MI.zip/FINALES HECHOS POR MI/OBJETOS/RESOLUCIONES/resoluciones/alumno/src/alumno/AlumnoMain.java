package alumno;

public class AlumnoMain {
    public static void main(String[] args) {
        AlumnoDoctorado aD=new AlumnoDoctorado("Medicina","UNQ",1,"Axel",3);
        AlumnoDeGrado aG=new AlumnoDeGrado("Informatica",2,"rober",2);
        MateriasAprobadas m1=new MateriasAprobadas("CADP",5,2024);
        MateriasAprobadas m2=new MateriasAprobadas("tesis",10,2024);
        MateriasAprobadas m3=new MateriasAprobadas("anatomia",5,2020);
        MateriasAprobadas m4=new MateriasAprobadas("tesis",8,2021);
        MateriasAprobadas m5=new MateriasAprobadas("biologia",6,2022);
        aD.agregarMateriaAprobada(m3);
        aD.agregarMateriaAprobada(m4);
        aD.agregarMateriaAprobada(m5);
        aG.agregarMateriaAprobada(m1);
        aG.agregarMateriaAprobada(m2);
        System.out.println(aD.toString());
        System.out.println(aG.toString());
    }
    
}
