package alumno;

import java.util.Date;

public class MateriasAprobadas {
    private String nombre;
    private int nota;
    private int fecha;

    public MateriasAprobadas(String nombre, int nota, int fecha) {
        this.nombre = nombre;
        this.nota = nota;
        this.fecha = fecha;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public int getNota() {
        return nota;
    }

    public void setNota(int nota) {
        this.nota = nota;
    }

    public int getFecha() {
        return fecha;
    }

    public void setFecha(int fecha) {
        this.fecha = fecha;
    }

    @Override
    public String toString() {
        return "{" + "nombre=" + this.nombre + ", nota=" + this.nota + ", fecha=" + this.fecha + '}'+"\n";
    }
    
    
}
