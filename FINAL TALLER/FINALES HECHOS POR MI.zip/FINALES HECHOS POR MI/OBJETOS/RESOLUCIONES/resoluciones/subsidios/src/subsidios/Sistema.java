package subsidios;
//empece 12:51
public abstract class Sistema {
    private Solicitud[] solicitudes;
    private int dimF,dimL;
    
    public Sistema(int dimF){
        this.dimF=dimF;
        this.dimL=0;
        this.solicitudes=new Solicitud[this.dimF];
    }

    public Solicitud[] getSolicitudes() {
        return solicitudes;
    }

    private int getDimF() {
        return dimF;
    }

    public int getDimL() {
        return dimL;
    }

    private void setDimL(int dimL) {
        this.dimL = dimL;
    }
    
    public void agregarSolicitud(Solicitud s){
        if(this.getDimL()<this.getDimF()){
            this.getSolicitudes()[this.getDimL()]=s;
            this.setDimL(this.getDimL()+1);
        }
    }
    
    public Solicitud obtenerIesima(int i){
        Solicitud solicitud=this.getSolicitudes()[i-1];
        return solicitud;
    }
    
    public abstract void otorgarSubsidio(double x);

    @Override
    public String toString() {
        String aux="informacion de todos los subsidios otorgados: \n";
        for(int i=0;i<this.getDimL();i++){
            if(this.getSolicitudes()[i].isSubsidioOtorgado()){
                aux+="solicitud "+(i+1)+this.getSolicitudes()[i].toString()+"\n";
            }
        }
        return aux;
    }
    
    
}
