package subsidios;

public class SistemaVersion2 extends Sistema{
    public SistemaVersion2(int dimF){
        super(dimF);
    }
    
    @Override
    public void otorgarSubsidio(double x){
        for(int i=0;i<this.getDimL();i++){
            this.getSolicitudes()[i].otorgarSolicitudV2(x);
        }
    }
}
