package subsidios;

public class MainSistema {

    public static void main(String[] args) {
        SistemaVersion1 sistemaV1=new SistemaVersion1(3);
        SistemaVersion2 sistemaV2=new SistemaVersion2(3);
        Solicitud s1=new Solicitud("gonza","IA","españa",3000,3000,500,10,50);
        Solicitud s2=new Solicitud("dani","fisica","Usa",2000,2000,250,21,30);
        Solicitud s3=new Solicitud("ariel","software","inglaterra",4000,4000,1000,7,100);
        Solicitud s4=new Solicitud("genaro","robots","uruguay",500,500,100,10,25);
        
        sistemaV1.agregarSolicitud(s2);
        sistemaV1.agregarSolicitud(s4);
        sistemaV2.agregarSolicitud(s1);
        sistemaV2.agregarSolicitud(s3);
        
        System.out.println(sistemaV1.obtenerIesima(2).toString());
        System.out.println(sistemaV2.obtenerIesima(1).toString());
        
        System.out.println(sistemaV1.toString());
        System.out.println(sistemaV2.toString());
        
        sistemaV1.otorgarSubsidio(1500);
        sistemaV2.otorgarSubsidio(700);
        
        System.out.println(sistemaV1.toString());
        System.out.println(sistemaV2.toString());
    }
    
}
