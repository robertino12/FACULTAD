package subsidios;

public class SistemaVersion1 extends Sistema {
    public SistemaVersion1(int dimF){
        super(dimF);
    }
    
    @Override
    public void otorgarSubsidio(double x){
        for(int i=0;i<this.getDimL();i++){
            this.getSolicitudes()[i].otorgarSolicitudV1(x);
        }
    }
}
