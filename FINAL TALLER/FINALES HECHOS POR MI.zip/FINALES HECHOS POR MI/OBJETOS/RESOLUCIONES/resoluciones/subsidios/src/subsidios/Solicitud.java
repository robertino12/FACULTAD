package subsidios;

public class Solicitud {
    private String nombreInvestigador;
    private String nombrePlanTrabajo;
    private String destino;
    private double costoPasajeIda;
    private double costoPasajeVuelta;
    private double tasaEmbarque;
    private int cantDiasEstadia;
    private double montoHotelPorDia;
    private boolean subsidioOtorgado;

    public Solicitud(String nombreInvestigador, String nombrePlanTrabajo, String destino, double costoPasajeIda, double costoPasajeVuelta, double tasaEmbarque, int cantDiasEstadia, double montoHotelPorDia) {
        this.nombreInvestigador = nombreInvestigador;
        this.nombrePlanTrabajo = nombrePlanTrabajo;
        this.destino = destino;
        this.costoPasajeIda = costoPasajeIda;
        this.costoPasajeVuelta = costoPasajeVuelta;
        this.tasaEmbarque = tasaEmbarque;
        this.cantDiasEstadia = cantDiasEstadia;
        this.montoHotelPorDia = montoHotelPorDia;
        this.subsidioOtorgado = false;
    }

    private String getNombreInvestigador() {
        return nombreInvestigador;
    }

    private String getNombrePlanTrabajo() {
        return nombrePlanTrabajo;
    }

    private String getDestino() {
        return destino;
    }

    private double getCostoPasajeIda() {
        return costoPasajeIda;
    }

    private double getCostoPasajeVuelta() {
        return costoPasajeVuelta;
    }

    private double getTasaEmbarque() {
        return tasaEmbarque;
    }

    private int getCantDiasEstadia() {
        return cantDiasEstadia;
    }

    private double getMontoHotelPorDia() {
        return montoHotelPorDia;
    }

    public boolean isSubsidioOtorgado() {
        return subsidioOtorgado;
    }

    private void setSubsidioOtorgado(boolean subsidioOtorgado) {
        this.subsidioOtorgado = subsidioOtorgado;
    }
    
    public void otorgarSolicitudV1(double x){
        double montoAvion=this.getCostoPasajeIda()+this.getCostoPasajeVuelta()+this.getTasaEmbarque();
        if(montoAvion<x){
            this.setSubsidioOtorgado(true);
        }
    }
    
    public void otorgarSolicitudV2(double x){
        double montoEstadia=this.getCantDiasEstadia()*this.getMontoHotelPorDia();
        if(montoEstadia<x){
            this.setSubsidioOtorgado(true);
        }
    }

    @Override
    public String toString() {
        return "Solicitud{" + "nombreInvestigador=" + this.getNombreInvestigador() + ", nombrePlanTrabajo=" + this.getNombrePlanTrabajo() + ", destino=" + this.getDestino() + '}';
    }
    
    
}
