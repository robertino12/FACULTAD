package cochera;

public class CocheraMain {

    public static void main(String[] args) {
        Cubierto sectorC=new Cubierto(250);
        Descubierto sectorD=new Descubierto(220);
        Cochera cochera=new Cochera(sectorC,sectorD);
        Coche a1=new Coche("ODV",10);
        Coche a2=new Coche("AAA",5);
        Coche a3=new Coche("BBB",12);
        Coche a4=new Coche("CCC",15);
        System.out.println(sectorC.ingresarPrimerLugarLibreSector(a1));
        System.out.println(sectorD.ingresarPrimerLugarLibreSector(a2));
        System.out.println(cochera.ingresaCochera(a3));
        System.out.println(cochera.ingresaCochera(a4));
        System.out.println(cochera.cantCochesCochera());
    }
    
}
