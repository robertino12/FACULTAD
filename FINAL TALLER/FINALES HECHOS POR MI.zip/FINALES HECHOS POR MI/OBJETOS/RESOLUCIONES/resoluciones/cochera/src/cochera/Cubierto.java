package cochera;

public class Cubierto {
    private int costoXHsCubierto;
    private Coche [] cubierto;
    private int dimLC;

    public Cubierto(int costoXHsCubierto) {
        this.costoXHsCubierto = costoXHsCubierto;
        this.cubierto = new Coche[20];
        this.dimLC = 0;
    }

    public int getCostoXHsCubierto(){
        return this.costoXHsCubierto;
    }
    public void setCostoXHsCubierto(int costo){
        this.costoXHsCubierto=costo;
    }
    public Coche [] getCubierto(){
        return this.cubierto;
    }
    public int getDimLC(){
        return this.dimLC;
    }
    public void setDimLC(int dimLC){
        this.dimLC=dimLC;
    }    
    
    public int ingresarPrimerLugarLibreSector(Coche auto){
        int i=0;
        boolean agregado=false;
        while((i<20)&&(agregado==false)){
            if(this.getCubierto()[i]==null){
                this.getCubierto()[i]=auto;
                agregado=true;
                this.setDimLC(this.getDimLC()+1);
            }
            else
               i++;
        }
        return i;
    }
}
