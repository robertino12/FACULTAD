package cochera;

public class Coche {
    private String patente;
    private int cantHsEstacionado;

    public Coche(String patente, int cantHsEstacionado) {
        this.patente = patente;
        this.cantHsEstacionado = cantHsEstacionado;
    }

    public String getPatente() {
        return patente;
    }

    public void setPatente(String patente) {
        this.patente = patente;
    }

    public int getCantHsEstacionado() {
        return cantHsEstacionado;
    }

    public void setCantHsEstacionado(int cantHsEstacionado) {
        this.cantHsEstacionado = cantHsEstacionado;
    }
    
    
}
