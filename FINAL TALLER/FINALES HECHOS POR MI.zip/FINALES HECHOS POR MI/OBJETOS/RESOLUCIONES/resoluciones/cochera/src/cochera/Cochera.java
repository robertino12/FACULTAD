package cochera;

public class Cochera {
    private Cubierto cubierto;
    private Descubierto descubierto;

    public Cochera(Cubierto cubierto,Descubierto descubierto) {
        this.cubierto=cubierto;
        this.descubierto=descubierto;
    }
    
    public String ingresaCochera (Coche auto){
        int i=0;
        boolean ingresado=false;
        String aux="no hay lugar";
        if(this.cubierto.getDimLC()<20){
            while((i<20)&&(ingresado==false)){
                if(this.cubierto.getCubierto()[i]==null){
                    this.cubierto.getCubierto()[i]=auto;
                    this.cubierto.setDimLC(this.cubierto.getDimLC()+1);
                    ingresado=true;
                    aux="cubierto";
                }
                else
                    i++;
            }
            
        }
        else{
            if(this.descubierto.getDimLD()<20){
                while((i<20)&&(ingresado==false)){
                    if(this.descubierto.getDescubierto()[i]==null){
                        this.descubierto.getDescubierto()[i]=auto;
                        this.descubierto.setDimLD(this.descubierto.getDimLD()+1);
                        ingresado=true;
                        aux="descubierto";
                    }
                    else
                       i++;
                }
            }
        }
        return "Sector: "+aux+" nro lugar que ocupa en el sector: "+i;
    }
    
    public int cantCochesCochera(){
        return this.cubierto.getDimLC()+this.descubierto.getDimLD();
    }
}
