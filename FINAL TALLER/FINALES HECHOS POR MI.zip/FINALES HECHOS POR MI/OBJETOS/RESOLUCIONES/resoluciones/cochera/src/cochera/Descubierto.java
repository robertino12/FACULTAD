package cochera;

public class Descubierto {
    private int costoXHsDescubierto;
    private Coche [] descubierto;
    private int dimLD;

    public Descubierto(int costoXHsDescubierto) {
        this.costoXHsDescubierto = costoXHsDescubierto;
        this.descubierto= new Coche[20];
        this.dimLD = 0;
    }

    public int getCostoXHsDescubierto(){
        return this.costoXHsDescubierto;
    }
    public void setCostoXHsDescubierto(int costo){
        this.costoXHsDescubierto=costo;
    }
    public Coche [] getDescubierto(){
        return this.descubierto;
    }
    public int getDimLD(){
        return this.dimLD;
    }
    public void setDimLD(int dimLD){
        this.dimLD=dimLD;
    }
    
    
    //PREGUNTAR, XQ SI TUVIERAMOS 80 SECTORES, HABRIA Q COPIAR Y PEGAR ESTE CODIGO Y ESTARIA MAL
    //PERO SI LO HACEMOS EN COCHERA Y EN CASO DE QUE LOS DOS TENGAN EL PRIMER LUGAR LIBRE, SE VA A PONER EN EL QUE PONGA PRIMERO YO
    public int ingresarPrimerLugarLibreSector(Coche auto){
        int i=0;
        boolean agregado=false;
        while((i<20)&&(agregado==false)){
            if(this.getDescubierto()[i]==null){
                this.getDescubierto()[i]=auto;
                agregado=true;
                this.setDimLD(this.getDimLD()+1);
            }
            else
               i++;
        }
        return i;
    }
}
