package estanteria;

public class MainEstanteria {

    public static void main(String[] args) {
        Estanteria estanteria=new Estanteria(3,5);
        Libro l1=new Libro("rob capo","rob",10);
        Libro l2=new Libro("sab capo","sab",2);
        Libro l3=new Libro("tom capo","tom",5);
        Libro l4=new Libro("nahue capo","nahue",20);
        Libro l5=new Libro("lu capo","lu",15);
        Libro l6=new Libro("cris capo","cris",32);
        Libro l7=new Libro("omar capo","omar",6);
        
        estanteria.almacenarLibro(l1, 1, 5);
        estanteria.almacenarLibro(l2, 2, 4);
        estanteria.almacenarLibro(l3, 3, 1);
        estanteria.almacenarLibro(l4, 1, 3);
        estanteria.almacenarLibro(l5, 2, 2);
        estanteria.almacenarLibro(l6, 3, 5);
        estanteria.almacenarLibro(l7, 1, 4);
        if(estanteria.sacarLibro("cris capo")!=null){
            System.out.println(estanteria.sacarLibro("cris capo").toString());
        }
        if(estanteria.libroMasPesado()!=null){
            System.out.println(estanteria.libroMasPesado().getTitulo());
        }
        
    }
    
}
