package estanteria;

public class Libro {
    private String titulo;
    private String nombrePrimerAutor;
    private int peso;

    public Libro(String titulo, String nombrePrimerAutor, int peso) {
        this.titulo = titulo;
        this.nombrePrimerAutor = nombrePrimerAutor;
        this.peso = peso;
    }

    public String getTitulo() {
        return titulo;
    }

    private String getNombrePrimerAutor() {
        return nombrePrimerAutor;
    }

    public int getPeso() {
        return peso;
    }

    public boolean esElLibro(String titulo){
        boolean aux=false;
        if(this.getTitulo().equals(titulo)){
            aux=true;
        }
        return aux;
    }
    @Override
    public String toString() {
        return "Libro{" + "titulo=" + this.getTitulo() + ", nombrePrimerAutor=" + this.getNombrePrimerAutor() + ", peso=" + this.getPeso() + '}';
    }
    
    
}
