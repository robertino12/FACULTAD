package estanteria;
//empece 14:27 termine 15:29
public class Estanteria {
    private Libro[][] estanteria;
    private int dimFFila,dimFCol;
    
    public Estanteria(int dimFFila,int dimFCol){
        this.dimFFila=dimFFila;
        this.dimFCol=dimFCol;
        this.estanteria=new Libro[this.dimFFila][this.dimFCol];
    }
    //java por defecto inicializa en vacio la matriz
    
    private Libro[][] getEstanteria() {
        return estanteria;
    }

    private int getDimFFila() {
        return dimFFila;
    }

    private int getDimFCol() {
        return dimFCol;
    }
    
    public void almacenarLibro(Libro l,int estante, int lugar){
        this.getEstanteria()[estante-1][lugar-1]=l;
    }
    
    public Libro sacarLibro(String titulo){
        boolean parar=false;
        int i=0;
        Libro sacado=null;
        while((i<this.getDimFFila())&&(parar==false)){
            int j=0;
            while((j<this.getDimFCol())&&(parar==false)){
                if(this.getEstanteria()[i][j]==null){
                    j++;
                }
                else
                    if(this.getEstanteria()[i][j].esElLibro(titulo)){
                        sacado=this.getEstanteria()[i][j];//VER ESTO X LAS REFERENCIAS DE DIRECCIONES
                        this.getEstanteria()[i][j]=null;
                        parar=true;
                    }
                else
                        j++;
            }
            i++;
        }
        return sacado;
    }
    
    public Libro libroMasPesado(){
        Libro maxLibro=null;
        int maxPeso=0;
        for(int i=0;i<this.getDimFFila();i++){
            for(int j=0;j<this.getDimFCol();j++){
                if(this.getEstanteria()[i][j]!=null){
                   if(this.getEstanteria()[i][j].getPeso()>maxPeso){
                        maxLibro=this.getEstanteria()[i][j];
                        maxPeso=this.getEstanteria()[i][j].getPeso();
                    }
                }
            }
        }
        return maxLibro;
    }
}
