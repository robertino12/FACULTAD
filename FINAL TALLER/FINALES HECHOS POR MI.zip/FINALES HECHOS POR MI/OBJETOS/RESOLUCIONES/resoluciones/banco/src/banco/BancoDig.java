package banco;

public class BancoDig extends Banco{
    private String direccionWeb;

    public BancoDig(String direccionWeb, String nombre, int cantEmple, int N) {
        super(nombre, cantEmple, N);
        this.direccionWeb = direccionWeb;
    }
    
    private String getDireccionWeb() {
        return direccionWeb;
    }

    private void setDireccionWeb(String direccionWeb) {
        this.direccionWeb = direccionWeb;
    }
    
    @Override
    public boolean puedeRecibirTarjeta(int cbu){
        boolean aux=false;
        Cuenta cuentaPuede=this.obtenerCuenta(cbu);
        if(cuentaPuede != null){
            if((cuentaPuede.getMoneda().equals("peso"))&&(cuentaPuede.getMonto()>100000)){
                aux=true;
            }
        }
        return aux;
    }

}
