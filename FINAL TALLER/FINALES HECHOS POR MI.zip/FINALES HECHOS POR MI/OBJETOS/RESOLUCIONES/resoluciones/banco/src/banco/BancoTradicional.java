package banco;

public class BancoTradicional extends Banco {
    private String direccion;
    private String localidad;
    private int cantCuentasDolares;

    public BancoTradicional(String direccion, String localidad, String nombre, int cantEmple, int N) {
        super(nombre, cantEmple, N);
        this.direccion = direccion;
        this.localidad = localidad;
        this.cantCuentasDolares = 0;
    }
    
    private String getDireccion() {
        return direccion;
    }

    private void setDireccion(String direccion) {
        this.direccion = direccion;
    }

    private String getLocalidad() {
        return localidad;
    }

    private void setLocalidad(String localidad) {
        this.localidad = localidad;
    }

    private int getCantCuentasDolares() {
        return cantCuentasDolares;
    }

    private void setCantCuentasDolares(int cantCuentasDolares) {
        this.cantCuentasDolares = cantCuentasDolares;
    }
    
    @Override
    public boolean agregarCuenta (Cuenta c){
        boolean aux=false;
        if(this.getCantCuentasDolares()<100){
            aux=super.agregarCuenta(c);
            if((aux==true)&&(c.getMoneda().equals("dolar"))){
                this.setCantCuentasDolares(this.getCantCuentasDolares()+1);
            }
        }
        return aux;
    }
    
    @Override
    public boolean puedeRecibirTarjeta(int cbu){
        boolean aux=false;
        Cuenta cuentaPuede=this.obtenerCuenta(cbu);
        if(cuentaPuede != null){
            if((cuentaPuede.getMoneda().equals("dolar"))&&(cuentaPuede.getMonto()>500)){
                aux=true;
            }
            else
                if((cuentaPuede.getMoneda().equals("peso"))&&(cuentaPuede.getMonto()>70000)){
                    aux=true;
                }
        }
        return aux;
    }

}
