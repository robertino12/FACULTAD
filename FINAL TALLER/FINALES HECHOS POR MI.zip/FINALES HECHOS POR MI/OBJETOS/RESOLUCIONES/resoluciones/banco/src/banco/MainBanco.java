package banco;

public class MainBanco {
    public static void main(String[] args) {
        BancoTradicional bT= new BancoTradicional("belgrano","buenos aires","jpMorgan",10,3);
        BancoDig bD=new BancoDig("silvester.com","silvester",5,2);
        Cuenta c1=new Cuenta(1,"rober",1,"dolar");
        Cuenta c2=new Cuenta(2,"sabri",2,"peso");
        Cuenta c3=new Cuenta(3,"jorge",3,"dolar");
        Cuenta c4=new Cuenta(4,"fran",4,"peso");
        Cuenta c5=new Cuenta(5,"marcos",5,"peso");
        bT.agregarCuenta(c1);
        bT.agregarCuenta(c2);
        bT.agregarCuenta(c3);
        bD.agregarCuenta(c4);
        bD.agregarCuenta(c5);
        bT.depositarDinero(1, 200);
        bT.depositarDinero(2, 660000);
        bT.depositarDinero(3, 550);
        bD.depositarDinero(4, 50000);
        bD.depositarDinero(5, 150000);
        System.out.println(bT.puedeRecibirTarjeta(1));
        System.out.println(bT.puedeRecibirTarjeta(2));
        System.out.println(bT.puedeRecibirTarjeta(3));
        System.out.println(bD.puedeRecibirTarjeta(4));
        System.out.println(bD.puedeRecibirTarjeta(5));
    }
}
