package banco;

public abstract class Banco {
    private String nombre ;
    private int cantEmple ;
    private Cuenta [] vectorC;
    private int dimF,dimL;
    
    public Banco(String nombre,int cantEmple, int N){
        this.nombre = nombre;
        this.cantEmple = cantEmple;
        this.dimL = 0;
        this.dimF = N;
        this.vectorC = new Cuenta[this.dimF];
    }

    private String getNombre() {
        return nombre;
    }

    private void setNombre(String nombre) {
        this.nombre = nombre;
    }

    private int getCantEmple() {
        return cantEmple;
    }

    private void setCantEmple(int cantEmple) {
        this.cantEmple = cantEmple;
    }

    private Cuenta[] getVectorC() {
        return vectorC;
    }

    private int getDimF() {
        return dimF;
    }

    private int getDimL() {
        return dimL;
    }

    private void setDimL(int dimL) {
        this.dimL = dimL;
    }

    public boolean agregarCuenta(Cuenta c){
        boolean aux=false;
        if(this.getDimL()<this.getDimF()){
          this.getVectorC()[this.getDimL()]=c; 
          this.setDimL(this.getDimL()+1);
          aux=true;
        }
        return aux;
    }
    
    public Cuenta obtenerCuenta (int cbu){
        /*int i=0;
        Cuenta dev=null;
        while((i<this.getDimL())&&(this.getVectorC()[i].getCbu()!=cbu)){
            i++;
        }
        if((i<this.getDimL())&&(this.getVectorC()[i].getCbu()==cbu)){
            dev=this.getVectorC()[i];
        }
        return dev;*/
        //probar a ver si anda c forma tom, pero tampoco
        boolean encontre=false;
        Cuenta aux=null;
        int i=0;
        while(i<this.getDimL() && encontre==false){
          if(this.getVectorC()[i].getCbu()==cbu){
              encontre=true;
              aux=this.getVectorC()[i];
          }
          else
            i++;
        }
        return aux;
    }
    
    public void depositarDinero(int cbu, double monto){
        Cuenta cuentaADepo=this.obtenerCuenta(cbu);
        if(cuentaADepo!=null){
            cuentaADepo.setMonto(cuentaADepo.getMonto()+monto);
        }
    }
    
    public abstract boolean puedeRecibirTarjeta(int cbu);
    
    
}
