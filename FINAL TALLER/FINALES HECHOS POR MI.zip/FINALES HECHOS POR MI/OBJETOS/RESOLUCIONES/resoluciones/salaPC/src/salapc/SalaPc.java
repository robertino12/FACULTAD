package salapc;
//11.20
public class SalaPc {
    private Pc[] espacios;
    private int dimF;
    
    public SalaPc(int dimF){
        this.dimF=dimF;
        this.espacios=new Pc[this.dimF];
    }
    
    private Pc[] getEspacios(){
        return this.espacios;
    }

    private int getDimF() {
        return dimF;
    }
    
    public void agregarPc(int nroEspacio,Pc pc){
        this.getEspacios()[nroEspacio-1]=pc;
    }
    
    public void encenderPc(){
        int menorConsumo=10000;
        Pc pcMin=null;
        for(int i=0;i<this.getDimF();i++){
            if(this.getEspacios()[i]!=null){
                if(this.getEspacios()[i].isEstado()==false){
                    if(this.getEspacios()[i].getConsumoPorHora()<menorConsumo){
                        menorConsumo=this.getEspacios()[i].getConsumoPorHora();
                        pcMin=this.getEspacios()[i];
                    }
                }
            }
        }
        if(pcMin!=null){
            pcMin.setEstado(true);
        }
    }

    public String toStringPcsOn() {
        String aux="";
        for(int i=0;i<this.getDimF();i++){
            if(this.getEspacios()[i]!=null){
                if(this.getEspacios()[i].isEstado()){
                    aux+="el espacio de la pc encendida es: "+(i+1)+"\n";
                }
            }
        }
        return aux;
    }
    
    
}
