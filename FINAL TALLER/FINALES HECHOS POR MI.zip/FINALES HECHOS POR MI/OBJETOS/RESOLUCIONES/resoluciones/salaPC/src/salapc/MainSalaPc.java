package salapc;

public class MainSalaPc {

    public static void main(String[] args) {
        SalaPc sala=new SalaPc(5);
        Pc pc1=new Pc(100);
        Pc pc2=new Pc(50);
        Pc pc3=new Pc(150);
        sala.agregarPc(2, pc1);
        sala.agregarPc(3, pc2);
        sala.agregarPc(5, pc3);
        
        sala.encenderPc();
        sala.encenderPc();
        
        System.out.println(sala.toStringPcsOn());
    }
    
}
