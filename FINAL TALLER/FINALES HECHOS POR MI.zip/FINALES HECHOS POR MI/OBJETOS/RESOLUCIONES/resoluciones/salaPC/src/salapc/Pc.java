package salapc;

public class Pc {
    private boolean estado;
    private int consumoPorHora;
    
    public Pc(int consumoPorHora){
        this.estado=false;
        this.consumoPorHora=consumoPorHora;
    }

    public boolean isEstado() {
        return estado;
    }

    public void setEstado(boolean estado) {
        this.estado = estado;
    }

    public int getConsumoPorHora() {
        return consumoPorHora;
    }
    
}
