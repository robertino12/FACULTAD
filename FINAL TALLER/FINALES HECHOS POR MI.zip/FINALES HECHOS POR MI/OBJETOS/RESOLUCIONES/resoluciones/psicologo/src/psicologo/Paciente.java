package psicologo;

public class Paciente {
    private String nombre;
    private boolean tieneObraSocial;
    private int costoPorSesion;

    public Paciente(String nombre, boolean tieneObraSocial, int costoPorSesion) {
        this.nombre = nombre;
        this.tieneObraSocial = tieneObraSocial;
        this.costoPorSesion = costoPorSesion;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public boolean isTieneObraSocial() {
        return tieneObraSocial;
    }

    public void setTieneObraSocial(boolean tieneObraSocial) {
        this.tieneObraSocial = tieneObraSocial;
    }

    public int getCostoPorSesion() {
        return costoPorSesion;
    }

    public void setCostoPorSesion(int costoPorSesion) {
        this.costoPorSesion = costoPorSesion;
    }
    
    
}
