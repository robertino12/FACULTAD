package psicologo;

public class MainAgendaSemanal {

    public static void main(String[] args) {
        AgendaSemanal agenda=new AgendaSemanal();
        Paciente p1=new Paciente("rob",true,1000);
        Paciente p2=new Paciente("tom",false,3000);
        Paciente p3=new Paciente("lu",true,1000);
        Paciente p4=new Paciente("nahue",false,3000);
        Paciente p5=new Paciente("sabri",true,1000);
        Paciente p6=new Paciente("jorge",false,3000);
        
        agenda.agendarPaciente(p1, 2, 3);
        agenda.agendarPaciente(p2, 3, 4);
        agenda.agendarPaciente(p3, 1, 5);
        agenda.agendarPaciente(p4, 4, 3);
        agenda.agendarPaciente(p5, 5, 6);
        agenda.agendarPaciente(p6, 1, 4);
        agenda.agendarPaciente(p1, 1, 2);
        
        agenda.liberarTurnosPaciente("rob");
        
        System.out.println(agenda.tieneTurno(4, "nahue"));
    }
    
}
