package psicologo;
//empece 10:45 termine 11:20
public class AgendaSemanal {
    private Paciente[][] agenda;
    private int dimFFila,dimFCol;
    
    public AgendaSemanal(){
        this.dimFFila=5;
        this.dimFCol=6;
        this.agenda=new Paciente[this.dimFFila][this.dimFCol];
    }
    //las matrices se inicializan vacias por defecto

    public Paciente[][] getAgenda() {
        return agenda;
    }

    public int getDimFFila() {
        return dimFFila;
    }

    public int getDimFCol() {
        return dimFCol;
    }
    
    public void agendarPaciente (Paciente p, int dia, int turno){
        this.getAgenda()[dia-1][turno-1]=p;
    }
    
    public void liberarTurnosPaciente(String nombre){
        for(int i=0;i<this.getDimFFila();i++){
            for(int j=0;j<this.getDimFCol();j++){
                if(this.getAgenda()[i][j]!=null){
                    if(this.getAgenda()[i][j].getNombre().equals(nombre)){
                        this.getAgenda()[i][j]=null;
                    }
                }
            }
        }
    }
    
    public boolean tieneTurno (int dia,String nombre){
        boolean turno=false;
        for(int j=0;j<this.getDimFCol()&&turno==false;j++){
            if(this.getAgenda()[dia-1][j]!=null){
                if(this.getAgenda()[dia-1][j].getNombre().equals(nombre)){
                        turno=true;
                }
            }
            
        }
        return turno;
    }
}
