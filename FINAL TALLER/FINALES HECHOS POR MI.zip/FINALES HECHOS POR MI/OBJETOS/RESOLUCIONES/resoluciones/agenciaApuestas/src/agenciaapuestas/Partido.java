package agenciaapuestas;
//empece 16:33 tarde 1:40
public class Partido {
    private String nombreLocal;
    private String nombreVisitante;
    private String resultado;
    private double factorPagoWinLocal;
    private double factorPagoWinVis;
    private double factorPagoEmpate;

    public Partido(String nombreLocal, String nombreVisitante, double factorPagoWinLocal, double factorPagoWinVis, double factorPagoEmpate) {
        this.nombreLocal = nombreLocal;
        this.nombreVisitante = nombreVisitante;
        this.resultado = "";
        this.factorPagoWinLocal = factorPagoWinLocal;
        this.factorPagoWinVis = factorPagoWinVis;
        this.factorPagoEmpate = factorPagoEmpate;
    }

    public String getNombreLocal() {
        return nombreLocal;
    }

    public void setNombreLocal(String nombreLocal) {
        this.nombreLocal = nombreLocal;
    }

    public String getNombreVisitante() {
        return nombreVisitante;
    }

    public void setNombreVisitante(String nombreVisitante) {
        this.nombreVisitante = nombreVisitante;
    }

    public String getResultado() {
        return resultado;
    }

    public void setResultado(String resultado) {
        this.resultado = resultado;
    }

    public double getFactorPagoWinLocal() {
        return factorPagoWinLocal;
    }

    public void setFactorPagoWinLocal(double factorPagoWinLocal) {
        this.factorPagoWinLocal = factorPagoWinLocal;
    }

    public double getFactorPagoWinVis() {
        return factorPagoWinVis;
    }

    public void setFactorPagoWinVis(double factorPagoWinVis) {
        this.factorPagoWinVis = factorPagoWinVis;
    }

    public double getFactorPagoEmpate() {
        return factorPagoEmpate;
    }

    public void setFactorPagoEmpate(double factorPagoEmpate) {
        this.factorPagoEmpate = factorPagoEmpate;
    }
    
    public void agregarResultado(String resultado){
        this.setResultado(resultado);
    }
    
    public double devolverFactorPago(String eleccion){
        double factor=0;
        if(eleccion.equals("victoria local")){
            factor=this.getFactorPagoWinLocal();
        }
        else
            if(eleccion.equals("vicotira visitante")){
                factor=this.getFactorPagoWinVis();
            }
            else
                factor=this.getFactorPagoEmpate();
        return factor;
    }
}
