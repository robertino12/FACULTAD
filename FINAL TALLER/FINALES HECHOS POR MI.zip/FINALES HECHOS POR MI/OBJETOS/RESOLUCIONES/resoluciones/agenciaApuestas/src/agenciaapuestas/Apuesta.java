package agenciaapuestas;

public class Apuesta {
    private String nombreCliente;
    private int dniCliente;
    private int idPartido;
    private String eleccionApuesta;
    private double montoApostado;

    public Apuesta(String nombreCliente, int dniCliente, int idPartido, String eleccionApuesta, double montoApostado) {
        this.nombreCliente = nombreCliente;
        this.dniCliente = dniCliente;
        this.idPartido = idPartido;
        this.eleccionApuesta = eleccionApuesta;
        this.montoApostado = montoApostado;
    }

    public String getNombreCliente() {
        return nombreCliente;
    }

    public void setNombreCliente(String nombreCliente) {
        this.nombreCliente = nombreCliente;
    }

    public int getDniCliente() {
        return dniCliente;
    }

    public void setDniCliente(int dniCliente) {
        this.dniCliente = dniCliente;
    }

    public int getIdPartido() {
        return idPartido;
    }

    public void setIdPartido(int idPartido) {
        this.idPartido = idPartido;
    }

    public String getEleccionApuesta() {
        return eleccionApuesta;
    }

    public void setEleccionApuesta(String eleccionApuesta) {
        this.eleccionApuesta = eleccionApuesta;
    }

    public double getMontoApostado() {
        return montoApostado;
    }

    public void setMontoApostado(double montoApostado) {
        this.montoApostado = montoApostado;
    }
    
    public boolean acertoResultado(int id, String resultado){
        boolean aux=false;
        if(((this.getIdPartido()-1)==id)&&(this.getEleccionApuesta().equals(resultado))){
            aux=true;
        }
        return aux;
    }

    @Override
    public String toString() {
        return "Apuesta{" + "nombreCliente=" + this.getNombreCliente() + ", dniCliente=" + this.getDniCliente()+'}';
    }
    
    
}
