package agenciaapuestas;

public class AgenciaMain {

public static void main(String[] args) {
        Agencia agencia=new Agencia();
        
        Partido p1=new Partido("river","gimnasia",1.2,2.5,1.7);
        Partido p2=new Partido("boca","gimnasia",1.4,2.0,1.5);
        Partido p3=new Partido("arsenal","gimnasia",1.7,1.5,2.0);
        Partido p4=new Partido("velez","gimnasia",1.4,1.7,1.8);
        Partido p5=new Partido("banfield","gimnasia",1.4,1.5,1.7);
        Partido p6=new Partido("barcelona","gimnasia",1.1,3.0,2.5);
        
        System.out.println(agencia.agregarPartido(p1));
        System.out.println(agencia.agregarPartido(p2));
        System.out.println(agencia.agregarPartido(p3));
        System.out.println(agencia.agregarPartido(p4));
        System.out.println(agencia.agregarPartido(p5));
        System.out.println(agencia.agregarPartido(p6));
        
        Apuesta a1=new Apuesta("rob",1,1,"victoria visitante",1000);
        Apuesta a2=new Apuesta("santi",2,1,"victoria local",1000);
        Apuesta a3=new Apuesta("fabri",3,2,"victoria visitante",1000);
        Apuesta a4=new Apuesta("rob",1,6,"empate",1000);
        Apuesta a5=new Apuesta("sabri",4,3,"victoria visitante",1000);
        Apuesta a6=new Apuesta("jorge",5,4,"victoria visitante",1000);
        Apuesta a7=new Apuesta("mati",6,5,"victoria visitante",1000);
        Apuesta a8=new Apuesta("sabri",4,4,"victoria visitante",1000);
        
        agencia.agregarApuesta(a1);
        agencia.agregarApuesta(a2);
        agencia.agregarApuesta(a3);
        agencia.agregarApuesta(a4);
        agencia.agregarApuesta(a5);
        agencia.agregarApuesta(a6);
        agencia.agregarApuesta(a7);
        agencia.agregarApuesta(a8);
        
        agencia.ingresarResultadoPartido(1, "victoria local");
        agencia.ingresarResultadoPartido(2, "victoria visitante");
        agencia.ingresarResultadoPartido(3, "victoria visitante");
        agencia.ingresarResultadoPartido(4, "victoria local");
        agencia.ingresarResultadoPartido(5, "victoria visitante");
        agencia.ingresarResultadoPartido(6, "empate");
        
        System.out.println(agencia.cerrarApuesta(5));
        System.out.println(agencia.cerrarApuesta(3));
        System.out.println(agencia.cerrarApuesta(2));
    }
    
}
