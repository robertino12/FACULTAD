package agenciaapuestas;

public class Agencia {
    private Partido[] partidos;
    private int dimFP,dimFA,dimLP,dimLA;
    private Apuesta[] apuestas;
    
    public Agencia(){
        this.dimLP=0;
        this.dimLA=0;
        this.dimFP=20;
        this.dimFA=100;
        this.apuestas=new Apuesta[this.dimFA];
        this.partidos=new Partido[this.dimFP];
    }

    public Partido[] getPartidos() {
        return partidos;
    }

    public int getDimFP() {
        return dimFP;
    }

    public int getDimFA() {
        return dimFA;
    }

    public int getDimLP() {
        return dimLP;
    }

    public void setDimLP(int dimLP) {
        this.dimLP = dimLP;
    }

    public int getDimLA() {
        return dimLA;
    }

    public void setDimLA(int dimLA) {
        this.dimLA = dimLA;
    }

    public Apuesta[] getApuestas() {
        return apuestas;
    }
    
    public int agregarPartido(Partido p){
        int id=0;
        if(this.getDimLP()<this.getDimFP()){
            this.getPartidos()[this.getDimLP()]=p;
            id=this.getDimLP()+1;
            this.setDimLP(this.getDimLP()+1);
        }
        return id;//como dice q es un numero entre 1 y 20 y dimL empieza en 0, le aumento 1
    }
    
    public void agregarApuesta(Apuesta a){
        if(this.getDimLA()<this.getDimFA()){
            this.getApuestas()[this.getDimLA()]=a;
            this.setDimLA(this.getDimLA()+1);
        }
    }
    
    public void ingresarResultadoPartido(int id,String resultado){
        if(id<=this.getDimFP()){
            if(this.getPartidos()[id-1]!=null){
                this.getPartidos()[id-1].agregarResultado(resultado);
            }
        }
    }
    
    public String cerrarApuesta(int id){
        String aux="";
        double factorPago=0;
        for(int i=0;i<this.getDimLA();i++){
            if(this.getApuestas()[i].acertoResultado(id-1, this.getPartidos()[id-1].getResultado())){
                factorPago=this.getPartidos()[id-1].devolverFactorPago(this.getApuestas()[i].getEleccionApuesta());
                aux+=this.getApuestas()[i].toString()+" dinero ganado: "+factorPago*this.getApuestas()[i].getMontoApostado()+"\n";
            }
        }
        return aux;
    }
    
    public void limpiarElSistema(){
        for(int i=0;i<this.getDimLP();i++){
            this.getPartidos()[i]=null;
        }
        for(int i=0;i<this.getDimLA();i++){
            this.getApuestas()[i]=null;
        }
    }
}
