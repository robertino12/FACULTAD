package finalesHechosDeNuevo.GNC;

public class Estacion {
    private String direccion;
    private double precioPorM3;
    private Surtidor[] surtidores;
    private int dimF;
    
    public Estacion(String direccion, double precioPorM3){
        this.direccion=direccion;
        this.precioPorM3=precioPorM3;
        this.dimF=6;
        this.surtidores=new Surtidor[this.dimF];
        for(int i=0;i<this.dimF;i++){
            this.surtidores[i]=new Surtidor(3);
        }
    }

    public String getDireccion() {
        return direccion;
    }

    public void setDireccion(String direccion) {
        this.direccion = direccion;
    }

    public double getPrecioPorM3() {
        return precioPorM3;
    }

    public void setPrecioPorM3(double precioPorM3) {
        this.precioPorM3 = precioPorM3;
    }

    public Surtidor[] getSurtidores() {
        return surtidores;
    }

    public int getDimF() {
        return dimF;
    }
    
    public void generarVenta(int n,int dniCliente,int cantM3,String pago){
        this.getSurtidores()[n-1].generarVenta(dniCliente, cantM3, pago,this.getPrecioPorM3());
    }
    
    public void marcarFueraServicio(int x){
        for(int i=0;i<this.getDimF();i++){
            this.getSurtidores()[i].fueraServicio(x);
        }
    }
    
    public Venta ventaMayorAbono(){
        Venta ventaMax=null;
        double maxMonto=-1;
        for(int i=0;i<this.getDimF();i++){
            if(!this.getSurtidores()[i].isFueraServicio()){//sino esta en servicio q no entre al surtidor
                if(this.getSurtidores()[i].mayorVenta().getMontoAbonado()>maxMonto){
                    maxMonto=this.getSurtidores()[i].mayorVenta().getMontoAbonado();
                    ventaMax=this.getSurtidores()[i].mayorVenta();
                }
           }
        }
        return ventaMax;
    }
    
    @Override
    public String toString(){
        String aux="estacion de servicio: Direccion: "+this.getDireccion()+" precio por m3: "+this.getPrecioPorM3()+" informacion surtidores \n";
        for(int i=0;i<this.getDimF();i++){
            aux+="surtidor "+(i+1)+": "+this.getSurtidores()[i].toString()+"\n";
        }
        return aux;
    }
}
