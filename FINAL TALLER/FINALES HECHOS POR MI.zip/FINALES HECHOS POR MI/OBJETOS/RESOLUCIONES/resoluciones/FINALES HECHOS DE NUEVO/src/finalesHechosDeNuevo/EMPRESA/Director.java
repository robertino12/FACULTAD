package finalesHechosDeNuevo.EMPRESA;

public class Director extends Empleado {
    private double montoDestinadoBiaticos;

    public Director(double montoDestinadoBiaticos, String nombre, int dni, int anioIngresoEmpresa, double sueldoBasico) {
        super(nombre, dni, anioIngresoEmpresa, sueldoBasico);
        this.montoDestinadoBiaticos = montoDestinadoBiaticos;
    }

    private double getMontoDestinadoBiaticos() {
        return montoDestinadoBiaticos;
    }
    
    @Override
    public double sueldo(){
        double aux=this.superaVeinteAnios();
        return aux+this.getMontoDestinadoBiaticos();
    }
    
    
}
