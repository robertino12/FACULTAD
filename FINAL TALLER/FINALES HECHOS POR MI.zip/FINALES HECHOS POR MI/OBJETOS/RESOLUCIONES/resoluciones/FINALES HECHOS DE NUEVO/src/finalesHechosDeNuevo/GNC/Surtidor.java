package finalesHechosDeNuevo.GNC;

public class Surtidor {
    private boolean fueraServicio;
    private Venta[] ventas;
    private int dimF,dimL;
    
    public Surtidor(int dimF){
        this.fueraServicio=false;
        this.dimF=dimF;
        this.dimL=0;
        this.ventas=new Venta[this.dimF];
    }

    public boolean isFueraServicio() {
        return fueraServicio;
    }

    public void setFueraServicio(boolean fueraServicio) {
        this.fueraServicio = fueraServicio;
    }

    public Venta[] getVentas() {
        return ventas;
    }

    public int getDimF() {
        return dimF;
    }

    public int getDimL() {
        return dimL;
    }

    public void setDimL(int dimL) {
        this.dimL = dimL;
    }
    
    public void generarVenta(int dniCliente, int cantM3,String pago, double precioXM3){
        if(this.getDimL()<this.getDimF()){
            Venta v=new Venta(dniCliente,cantM3,cantM3*precioXM3,pago);
            this.ventas[this.getDimL()]=v;
            this.setDimL(this.getDimL()+1);
        }
    }
    
    public void fueraServicio(int x){
        if(this.isFueraServicio()){
            System.out.println("ya esta fuera de servicio");
        }
        else{
            double total=0;
            for(int i=0;i<this.getDimL();i++){
                total+=this.getVentas()[i].totalM3Cargado();
            }
            if(total<x){
                this.setFueraServicio(true);
            }
        }
    }
    
    public Venta mayorVenta(){
        Venta maxVenta=null;
        double maxAporte=-1;
        for(int i=0;i<this.getDimL();i++){
            if(this.getVentas()[i].getMontoAbonado()>maxAporte){
                maxVenta=this.getVentas()[i];
                maxAporte=this.getVentas()[i].getMontoAbonado();
            }
        }
        return maxVenta;
    }

    @Override
    public String toString() {
        String aux="fuera servicio: ";
        if(this.isFueraServicio()){
            aux+="esta fuera de servicio";
        }
        else{
            aux+="esta andando \n";
            for(int i=0;i<this.getDimL();i++){
                aux+="venta: "+(i+1)+" "+this.getVentas()[i].toString()+"\n";
            }
        }
        return aux;
    }
    
    
}
