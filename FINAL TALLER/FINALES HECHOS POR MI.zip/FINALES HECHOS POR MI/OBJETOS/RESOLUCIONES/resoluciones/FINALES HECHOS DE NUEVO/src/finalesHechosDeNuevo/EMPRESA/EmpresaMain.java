package finalesHechosDeNuevo.EMPRESA;

public class EmpresaMain {

    public static void main(String[] args) {
        Director rober=new Director(2500,"rober",1,2000,10000);
        Empresa e=new Empresa("roberTech","122",rober,5);
        Encargado e1=new Encargado(10,"pepe",2,2002,2000);
        Encargado e2=new Encargado(2,"jesus",3,2015,1000);
        Encargado e3=new Encargado(4,"caeles",3,2004,1500);
        
        e.asignarEncargado(1, e1);
        e.asignarEncargado(3, e2);
        e.asignarEncargado(5, e3);
        System.out.println(e.toString());
    }
    
}
