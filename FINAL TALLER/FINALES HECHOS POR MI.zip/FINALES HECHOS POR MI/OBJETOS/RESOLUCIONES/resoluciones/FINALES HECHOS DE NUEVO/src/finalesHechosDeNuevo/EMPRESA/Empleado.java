package finalesHechosDeNuevo.EMPRESA;

public abstract class Empleado {
    private String nombre;
    private int dni;
    private int anioIngresoEmpresa;
    private double sueldoBasico;

    public Empleado(String nombre, int dni, int anioIngresoEmpresa, double sueldoBasico) {
        this.nombre = nombre;
        this.dni = dni;
        this.anioIngresoEmpresa = anioIngresoEmpresa;
        this.sueldoBasico = sueldoBasico;
    }

    public String getNombre() {
        return nombre;
    }

    public int getDni() {
        return dni;
    }

    public int getAnioIngresoEmpresa() {
        return anioIngresoEmpresa;
    }

    public double getSueldoBasico() {
        return sueldoBasico;
    }

    public void setSueldoBasico(double sueldoBasico) {
        this.sueldoBasico = sueldoBasico;
    }
    
    public double superaVeinteAnios(){
        double aux=this.getSueldoBasico();
        if((2024-this.getAnioIngresoEmpresa())>20){
            aux=this.getSueldoBasico()+10*this.getSueldoBasico()/100;//sacamos el 10% y se lo sumamos al sueldo basico
        }
        return aux;
    }

    @Override
    public String toString() {
        return "Empleado{" + "nombre=" + nombre + ", dni=" + dni + "sueldo a cobrar: "+this.sueldo()+'}';
    }//hago this.sueldo xq este toString cuando lo ejecute x ej un encargado, el this.sueldo va a ejecutar el metodo sueldo q el tenga
    
    public abstract double sueldo();
}
