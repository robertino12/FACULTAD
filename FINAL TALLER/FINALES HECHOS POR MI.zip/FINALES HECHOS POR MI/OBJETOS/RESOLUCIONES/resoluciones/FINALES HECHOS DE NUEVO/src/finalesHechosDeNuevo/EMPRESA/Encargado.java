package finalesHechosDeNuevo.EMPRESA;

public class Encargado extends Empleado {
    int cantEmpleadosACargo;
    
    public Encargado(int cant,String nombre, int dni, int anioIngresoEmpresa,double sueldoBasico){
        super(nombre,dni,anioIngresoEmpresa,sueldoBasico);
        this.cantEmpleadosACargo=cant;
    }

    private int getCantEmpleadosACargo() {
        return cantEmpleadosACargo;
    }
    
    @Override
    public double sueldo(){
        double aux=this.superaVeinteAnios();
        return aux+1000*this.getCantEmpleadosACargo();
    }
}
