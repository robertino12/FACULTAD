package finalesHechosDeNuevo.EMPRESA;
//empece 23:10 termine 00:21

public class Empresa {
    private String nombre;
    private String direccion;
    private Director ejecutivo;
    private Encargado[] sucursales;
    private int dimF;//no tiene sentido tener dimL si pide asignar un encargado en cualq lado
    //xq si agrego en la 3, voy a sumar una a diml y esta no va a vale 3 va a valer 1 en caso q sea el primero en ingresar

    public Empresa(String nombre, String direccion, Director ejecutivo,int dimF) {
        this.nombre = nombre;
        this.direccion = direccion;
        this.ejecutivo = ejecutivo;
        this.dimF = dimF;
        this.sucursales = new Encargado[this.dimF];
    }

    private String getNombre() {
        return nombre;
    }

    private String getDireccion() {
        return direccion;
    }

    private Director getEjecutivo() {
        return ejecutivo;
    }

    private Encargado[] getSucursales() {
        return sucursales;
    }

    private int getDimF() {
        return dimF;
    }

    
    public void asignarEncargado(int x,Encargado e){
        this.getSucursales()[x-1]=e;
    }

    @Override
    public String toString() {
        String aux= "Empresa{" + "nombre=" + nombre + ", direccion=" + direccion + ", ejecutivo=" + this.getEjecutivo().toString() + ", info sucursales: "+'}';
        for(int i=0;i<this.getDimF();i++){
            if(this.getSucursales()[i]!=null){
                aux+="numero sucursal: "+(i+1)+" representacion encargado: "+this.getSucursales()[i].toString()+"\n";
            }
            else
                aux+="la sucursal: "+(i+1)+" no tiene encargado";
        }
        return aux;
    }
    
    
}
