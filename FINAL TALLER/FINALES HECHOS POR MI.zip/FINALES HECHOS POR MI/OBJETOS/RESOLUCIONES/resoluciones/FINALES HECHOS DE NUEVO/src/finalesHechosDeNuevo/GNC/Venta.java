package finalesHechosDeNuevo.GNC;

public class Venta {
    private int dniCliente;
    private int cantM3Cargado;
    private double montoAbonado;
    private String medioPago;

    public Venta(int dniCliente, int cantM3Cargado, double montoAbonado, String medioPago) {
        this.dniCliente = dniCliente;
        this.cantM3Cargado = cantM3Cargado;
        this.montoAbonado = montoAbonado;
        this.medioPago = medioPago;
    }

    public int getDniCliente() {
        return dniCliente;
    }

    public void setDniCliente(int dniCliente) {
        this.dniCliente = dniCliente;
    }

    public int getCantM3Cargado() {
        return cantM3Cargado;
    }

    public void setCantM3Cargado(int cantM3Cargado) {
        this.cantM3Cargado = cantM3Cargado;
    }

    public double getMontoAbonado() {
        return montoAbonado;
    }

    public void setMontoAbonado(double montoAbonado) {
        this.montoAbonado = montoAbonado;
    }

    public String getMedioPago() {
        return medioPago;
    }

    public void setMedioPago(String medioPago) {
        this.medioPago = medioPago;
    }
    
    public int totalM3Cargado(){
        return this.getCantM3Cargado();
    }

    @Override
    public String toString() {
        return "Venta{" + "dniCliente=" + this.getDniCliente() + ", cantM3Cargado=" + this.getCantM3Cargado() + ", montoAbonado=" + this.getMontoAbonado() + ", medioPago=" + this.getMedioPago() + '}';
    }
    
    
    
}
