package finalesHechosDeNuevo.GNC;

public class GNCMain {

    public static void main(String[] args) {
        Estacion e=new Estacion("122",1000);
        
        e.generarVenta(1, 1, 20, "tarjeta");
        e.generarVenta(1, 2, 10, "tarjeta");
        e.generarVenta(2, 3, 25, "efectivo");
        e.generarVenta(3, 4, 70, "debito");
        e.generarVenta(4, 5, 35, "efectivo");
        e.generarVenta(5, 6, 40, "tarjeta");
        
        e.marcarFueraServicio(35);
        
        System.out.println(e.toString());
        System.out.println(e.ventaMayorAbono());
    }
    
}
