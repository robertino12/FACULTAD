package conciertosagain;

public class Concierto {
    private String nombreArtista;
    private double precioEntrada;
    private int cantEntradasVendidas;

    public Concierto(String nombreArtista, double precioEntrada, int cantEntradasVendidas) {
        this.nombreArtista = nombreArtista;
        this.precioEntrada = precioEntrada;
        this.cantEntradasVendidas = cantEntradasVendidas;
    }

    private String getNombreArtista() {
        return nombreArtista;
    }

    private double getPrecioEntrada() {
        return precioEntrada;
    }

    private int getCantEntradasVendidas() {
        return cantEntradasVendidas;
    }

    @Override
    public String toString() {
        return "Concierto{" + "nombreArtista=" + this.getNombreArtista() + ", precioEntrada=" + this.getPrecioEntrada() + ", cantEntradasVendidas=" + this.getCantEntradasVendidas() + '}';
    }
    
    public double recaudacionConcierto(){
        return (this.getCantEntradasVendidas()*this.getPrecioEntrada())/2;
    }
}
