package conciertosagain;

public class Estadio {
    private String nombre;
    private String direccion;
    private int capacidad;
    private Concierto[][] agenda;
    private int dimFFila,dimFCol;
    private int[] dimL;
    
    public Estadio(String nombre,String direccion,int capacidad){
        this.nombre=nombre;
        this.direccion=direccion;
        this.capacidad=capacidad;
        this.dimFFila=12;
        this.dimFCol=31;
        this.agenda=new Concierto[this.dimFFila][this.dimFCol];
        //las matrices ya se inicializan vacias por defecto
        this.dimL=new int[this.dimFFila];
        for(int i=0;i<this.dimFFila;i++){
            this.dimL[i]=0;
        }
    }

    private String getNombre() {
        return nombre;
    }

    private String getDireccion() {
        return direccion;
    }

    private int getCapacidad() {
        return capacidad;
    }

    private Concierto[][] getAgenda() {
        return agenda;
    }

    private int getDimFFila() {
        return dimFFila;
    }

    private int getDimFCol() {
        return dimFCol;
    }

    private int[] getDimL() {
        return dimL;
    }
    
    public void registrarConcierto(Concierto c,int mes){
        if(mes<=this.getDimFFila()){
            if(this.getDimL()[mes-1]<this.getDimFCol()){
                this.getAgenda()[mes-1][this.getDimL()[mes-1]]=c;
                this.getDimL()[mes-1]++;
            }
        }
    }
    
    public String listarConciertosMesM(int mes){
        String aux=" ";
        if(mes<=this.getDimFFila()){
            for(int j=0;j<this.getDimL()[mes-1];j++){
                aux+=this.getAgenda()[mes-1][j].toString()+"\n";
            }
        }
        return aux;
    }
    
    public double gananciaEstadio (int mes){
        double ganancia=0;
        if(mes<=this.getDimFFila()){
            for(int j=0;j<this.getDimL()[mes-1];j++){
                ganancia+=this.getAgenda()[mes-1][j].recaudacionConcierto();
            }
        }
        return ganancia;
    }

    @Override
    public String toString() {
        String aux="Estadio{" + "nombre=" + this.getNombre() + ", direccion=" + this.getDireccion() + ", capacidad=" + this.getCapacidad()+"\n";
        for(int i=0;i<this.getDimFFila();i++){
            aux+="mes "+(i+1)+"\n";
            for(int j=0;j<this.getDimL()[i];j++){
                aux+="dia "+(j+1)+this.getAgenda()[i][j].toString()+"\n";
            }
        }
        return aux;
    }
    
    
}
