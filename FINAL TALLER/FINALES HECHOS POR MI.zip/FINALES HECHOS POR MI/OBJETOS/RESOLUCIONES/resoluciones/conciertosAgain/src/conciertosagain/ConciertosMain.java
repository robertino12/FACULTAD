package conciertosagain;

public class ConciertosMain {

    public static void main(String[] args) {
        Estadio estadio=new Estadio("river","belgrano",90000);
        Concierto c1=new Concierto("duki",3000,10000);
        Concierto c2=new Concierto("maria",2000,10000);
        Concierto c3=new Concierto("khea",1500,10000);
        Concierto c4=new Concierto("cro",1800,10000);
        Concierto c5=new Concierto("billie",5000,10000);
        
        estadio.registrarConcierto(c1, 12);
        estadio.registrarConcierto(c2, 8);
        estadio.registrarConcierto(c3, 5);
        estadio.registrarConcierto(c4, 5);
        estadio.registrarConcierto(c5, 3);
        
        System.out.println(estadio.listarConciertosMesM(5));
        System.out.println(estadio.listarConciertosMesM(12));
        
        System.out.println(estadio.gananciaEstadio(5));
        System.out.println(estadio.gananciaEstadio(12));
        
        System.out.println(estadio.toString());
    }
    
}
