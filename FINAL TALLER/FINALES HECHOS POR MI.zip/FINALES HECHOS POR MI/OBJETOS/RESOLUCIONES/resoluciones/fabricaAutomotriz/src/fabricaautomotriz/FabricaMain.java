package fabricaautomotriz;

public class FabricaMain {

    public static void main(String[] args) {
        Sector sectorMotos=new Sector("skua",2);
        Empleado jefe=new Empleado("rober","lucen",15);
        Empleado t1=new Empleado("javi","nen",12);
        Empleado t2=new Empleado("ronaldo","nazario",9);
        Producto motor=new Producto(10);
        Producto escape=new Producto(15);
        
        sectorMotos.agregarEmpleado(jefe, true);
        sectorMotos.agregarEmpleado(t1, false);
        sectorMotos.agregarEmpleado(t2, false);
        sectorMotos.agregarProducto(motor);
        sectorMotos.agregarProducto(escape);
        sectorMotos.cambiarEtapa(10, 1000);
        sectorMotos.cambiarEtapa(15, 500);
        System.out.println(sectorMotos.costoTotal(2));
        
        sectorMotos.cambiarEtapa(10, 1500);
        sectorMotos.cambiarEtapa(10, 2000);
        sectorMotos.cambiarEtapa(10, 2500);
        
        System.out.println(sectorMotos.toString());
    }
    
}
