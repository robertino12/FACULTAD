package fabricaautomotriz;

public class Producto {
    private int codigo;
    private double costoTotal;
    private int etapaSeEncuentra;

    public Producto(int codigo) {
        this.codigo = codigo;
        this.costoTotal = 0;
        this.etapaSeEncuentra = 1;
    }

    private int getCodigo() {
        return codigo;
    }

    public double getCostoTotal() {
        return costoTotal;
    }

    private void setCostoTotal(double costoTotal) {
        this.costoTotal = costoTotal;
    }

    private int getEtapaSeEncuentra() {
        return etapaSeEncuentra;
    }

    private void setEtapaSeEncuentra(int etapaSeEncuentra) {
        this.etapaSeEncuentra = etapaSeEncuentra;
    }
    
    public boolean esEtapa(int etapa){
        boolean aux=false;
        if(this.getEtapaSeEncuentra()==etapa){
            aux=true;
        }
        return aux;
    }
    
    public boolean esCodigo(int cod){
        boolean aux=false;
        if(this.getCodigo()==cod){
            aux=true;
        }
        return aux;
    }
    
    public void aumentarEtapa(){
        this.setEtapaSeEncuentra(this.getEtapaSeEncuentra()+1);
    }
    
    public void sumarCosto(double costo){
        this.setCostoTotal(this.getCostoTotal()+costo);
    }
}
