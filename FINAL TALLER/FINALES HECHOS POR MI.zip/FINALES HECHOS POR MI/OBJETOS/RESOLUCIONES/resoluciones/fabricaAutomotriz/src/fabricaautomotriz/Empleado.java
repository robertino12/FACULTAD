package fabricaautomotriz;

public class Empleado {
    private String nombre;
    private String apellido;
    private int antiguedad;

    public Empleado(String nombre, String apellido, int antiguedad) {
        this.nombre = nombre;
        this.apellido = apellido;
        this.antiguedad = antiguedad;
    }

    private String getNombre() {
        return nombre;
    }

    public String getApellido() {
        return apellido;
    }

    public int getAntiguedad() {
        return antiguedad;
    }

    public boolean antiguedadMayor(){
        boolean aux=false;
        if(this.getAntiguedad()>10){
            aux=true;
        }
        return aux;
    }

    @Override
    public String toString() {
        return "Empleado{" + "nombre=" + this.getNombre() + ", apellido=" + this.getApellido() + ", antiguedad=" + this.getAntiguedad() + '}';
    }
    
    
}
