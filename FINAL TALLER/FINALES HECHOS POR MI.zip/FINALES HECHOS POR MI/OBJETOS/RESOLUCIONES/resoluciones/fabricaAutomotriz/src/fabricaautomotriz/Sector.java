//empece 11:05 temrine 00:04
package fabricaautomotriz;

public class Sector {
    private String nombre;
    private Empleado jefe;
    private Empleado[] empleados;
    private int dimLE,dimFE;
    private Producto[] productos;
    private int dimLP,dimFP;
    
    public Sector(String nombre,int dimFP){
        this.nombre=nombre;
        this.jefe=null;
        this.dimFE=50;
        this.dimLE=0;
        this.empleados=new Empleado[this.dimFE];
        this.dimFP=dimFP;
        this.dimLP=0;
        this.productos=new Producto[this.dimFP];
    }

    private String getNombre() {
        return nombre;
    }

    private Empleado getJefe() {
        return jefe;
    }

    private void setJefe(Empleado jefe) {
        this.jefe = jefe;
    }

    private Empleado[] getEmpleados() {
        return empleados;
    }

    private int getDimLE() {
        return dimLE;
    }

    private void setDimLE(int dimLE) {
        this.dimLE = dimLE;
    }

    private Producto[] getProductos() {
        return productos;
    }

    private int getDimLP() {
        return dimLP;
    }

    private void setDimLP(int dimLP) {
        this.dimLP = dimLP;
    }

    public void agregarEmpleado(Empleado e,boolean esJefe){
        if(esJefe==true){
            this.setJefe(e);
        }
        else {
            this.getEmpleados()[this.getDimLE()]=e;
            this.setDimLE(this.getDimLE()+1);
        }
            
    }
    
    public void agregarProducto(Producto p){
        this.getProductos()[this.getDimLP()]=p;
        this.setDimLP(this.getDimLP()+1);
    }
    
    public double costoTotal(int etapa){
        double costo=0;
        for(int i=0;i<this.getDimLP();i++){
            if(this.getProductos()[i].esEtapa(etapa)){
                costo+=this.getProductos()[i].getCostoTotal();
            }
        }
        return costo;
    }
    
    public void cambiarEtapa(int codProd,double costo){
        int i=0;
        boolean encontro=false;
        while((i<this.getDimLP())&&(encontro==false)){
            if(this.getProductos()[i].esCodigo(codProd)){
                this.getProductos()[i].aumentarEtapa();
                this.getProductos()[i].sumarCosto(costo);
                encontro=true;
            }
            else
                i++;
        }
    }
    
    @Override
    public String toString(){
        String aux="nombre sector: "+this.getNombre()+", datos jefe: "+this.getJefe().toString()+", la cantidad total de productos: "+this.getDimLP()+", costo total de todos los productos finalizados: "+this.costoTotal(5)+"\n";
        for(int i=0;i<this.getDimLE();i++){
            if(this.getEmpleados()[i].antiguedadMayor()){
                aux+=this.getEmpleados()[i].toString()+"\n";
            }
        }
        return aux;
    }
}
