package compras;

public class PorMayor extends Compra{
    private int cuit;
    private String nombre;

    public PorMayor(int cuit, String nombre, int numero, String fecha, int dimF) {
        super(numero, fecha, dimF);
        this.cuit = cuit;
        this.nombre = nombre;
    }

    private int getCuit() {
        return cuit;
    }


    private String getNombre() {
        return nombre;
    }

    
    @Override
    public void agregarProducto(Producto p){
        if((this.getDimL()<this.getDimF())&&(p.getCantidadUnidades()>6)){
            this.getProductos()[this.getDimL()]=p;
            this.setDimL(this.getDimL()+1);
        }
    }
    
    @Override
    public double obtenerPrecioFinalCompra(){
        double precioFinal=super.obtenerPrecioFinalCompra();
        double descuento=precioFinal*0.21;
        return precioFinal-descuento;
    }
    
    @Override
    public String toString(){
        String aux=super.toString();
        return aux+" el cuit del consumidor final es: "+this.getCuit()+" el nombre del consumidor final es: "+this.getNombre();
    }
}
