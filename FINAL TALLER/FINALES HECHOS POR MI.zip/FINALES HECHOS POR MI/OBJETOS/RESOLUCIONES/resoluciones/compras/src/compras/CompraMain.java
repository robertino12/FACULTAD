package compras;

public class CompraMain {

    public static void main(String[] args) {
        Compra compra=new Compra(1,"12/12/12",10);
        PorMayor compraM=new PorMayor(12,"rober",2,"14/6/24",10);
        Producto p1=new Producto(1,"a",10,2);
        Producto p2=new Producto(2,"b",20,3);
        Producto p3=new Producto(3,"c",30000,400);
        Producto p4=new Producto(4,"d",40,5);
        Producto p5=new Producto(5,"e",50,6);
        Producto p6=new Producto(6,"f",60,7);
        Producto p7=new Producto(7,"g",7000,800);
        compra.agregarProducto(p1);
        compra.agregarProducto(p2);
        compra.agregarProducto(p3);
        compraM.agregarProducto(p4);//esta no se agrega en mayor
        compraM.agregarProducto(p5);//esta no se agrega en mayor
        compraM.agregarProducto(p6);
        compraM.agregarProducto(p7);
        System.out.println(compra.obtenerPrecioFinalCompra());
        System.out.println(compraM.obtenerPrecioFinalCompra());
        System.out.println(compra.toString());
        System.out.println(compraM.toString());
        System.out.println(compra.esAbonable());
        System.out.println(compraM.esAbonable());
    }
    
}
