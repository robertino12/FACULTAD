package compras;

public class Compra {
    private int numero;
    private String fecha;
    private Producto [] productos;
    private int dimL,dimF;

    public Compra(int numero, String fecha, int dimF) {
        this.numero = numero;
        this.fecha = fecha;
        this.dimF = dimF;
        this.dimL = 0;
        this.productos = new Producto[this.dimF];
    }

    public int getNumero() {
        return numero;
    }

    public String getFecha() {
        return fecha;
    }

    public Producto[] getProductos() {
        return productos;
    }

    public int getDimL() {
        return dimL;
    }

    public void setDimL(int dimL) {
        this.dimL = dimL;
    }

    public int getDimF() {
        return dimF;
    }
    
    public void agregarProducto(Producto p){
        if(this.getDimL()<this.getDimF()){
            this.getProductos()[this.getDimL()]=p;
            this.setDimL(this.getDimL()+1);
        }
    }
    
    public double obtenerPrecioFinalCompra(){
        double precioFinal=0;
        int i;
        for(i=0;i<this.getDimL();i++){
            precioFinal+=this.getProductos()[i].getCantidadUnidades()*this.getProductos()[i].getPrecioUnitario();
        }
        return precioFinal;
    }
    
    @Override
    public String toString(){
        String aux="Resumen compra, numero: "+this.getNumero()+" fecha: "+this.getFecha()+"\n";
        int i=0;
        for(i=0;i<this.getDimL();i++){
            aux+=this.getProductos()[i].toString()+"\n";
        }
        return aux+" precio final compra: "+this.obtenerPrecioFinalCompra();
    }
    
    public boolean esAbonable(){
        return this.obtenerPrecioFinalCompra()>100000;
    }
}
