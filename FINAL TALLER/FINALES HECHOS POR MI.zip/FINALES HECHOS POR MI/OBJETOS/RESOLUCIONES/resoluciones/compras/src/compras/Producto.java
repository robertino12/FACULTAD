package compras;

public class Producto {
    private int codigo;
    private String descripcion;
    private double precioUnitario;
    private int cantidadUnidades;

    public Producto(int codigo, String descripcion, double precioUnitario, int cantidadUnidades) {
        this.codigo = codigo;
        this.descripcion = descripcion;
        this.precioUnitario = precioUnitario;
        this.cantidadUnidades = cantidadUnidades;
    }

    private int getCodigo() {
        return codigo;
    }

    private String getDescripcion() {
        return descripcion;
    }


    public double getPrecioUnitario() {
        return precioUnitario;
    }

    public int getCantidadUnidades() {
        return cantidadUnidades;
    }

    @Override
    public String toString() {
        return "Producto{" + "codigo=" + this.getCodigo() + ", descripcion=" + this.getDescripcion() + ", precioFinal=" + this.getPrecioUnitario()*this.getCantidadUnidades() + '}';
    }
    
    
    
}
