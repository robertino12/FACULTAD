package fechaparciales;

public class MainFechaParcial {

    public static void main(String[] args) {
        FechaParcial fecha=new FechaParcial(2,4);
        Alumno a1=new Alumno("rpber",1);
        Alumno a2=new Alumno("sabri",2);
        Alumno a3=new Alumno("jorge",3);
        Alumno a4=new Alumno("fran",4);
        Alumno a5=new Alumno("tom",5);
        Alumno a6=new Alumno("imanol",6);
        fecha.agregarAlumno(a1, 2);
        fecha.agregarAlumno(a2, 1);
        fecha.agregarAlumno(a3, 2);
        fecha.agregarAlumno(a4, 1);
        fecha.agregarAlumno(a5, 2);
        fecha.agregarAlumno(a6, 1);
        fecha.asignarTema();
        System.out.println(fecha.infoAlumnos(2));
        System.out.println(fecha.infoAlumnos(1));
    }
    
}
