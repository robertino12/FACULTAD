package fechaparciales;
//tiempo comienzo 17:37 termine 18:28
import java.util.Random;

public class FechaParcial {
    private Alumno[][] fechaParcial;
    private int dimFFila,dimFCol;
    private int[] dimL;
    
    public FechaParcial(int dimFFila,int dimFCol){
        this.dimFFila=dimFFila;
        this.dimFCol=dimFCol;
        this.fechaParcial=new Alumno[dimFFila][dimFCol];
        this.dimL=new int[this.dimFFila];
        for(int i=0;i<this.dimFFila;i++){
            this.dimL[i]=0;
        }
    }
    //las matrices por defecto incializan en null las matrices

    private Alumno[][] getFechaParcial() {
        return fechaParcial;
    }

    private int getDimFFila() {
        return dimFFila;
    }

    private int getDimFCol() {
        return dimFCol;
    }

    private int[] getDimL() {
        return dimL;
    }

    public void agregarAlumno(Alumno a,int sala){
        this.getFechaParcial()[sala-1][this.getDimL()[sala-1]]=a;
        this.getDimL()[sala-1]++;
    } 
    
    public void asignarTema(){
        Random random=new Random();
        int aletorio=random.nextInt(2)+1;//numero random entre 1-2
        for(int i=0;i<this.dimFFila;i++){
            for(int j=0;j<this.getDimL()[i];j++){
                this.getFechaParcial()[i][j].setNroTemaAsignado(aletorio);
                aletorio=random.nextInt(2)+1;
            }
        }
    }
    
    public String infoAlumnos(int t){
        String aux="";
        for(int i=0;i<this.dimFFila;i++){
            for(int j=0;j<this.getDimL()[i];j++){
                if(this.getFechaParcial()[i][j].getNroTemaAsignado()==t){
                    aux+=this.getFechaParcial()[i][j].toString()+"\n";
                }
            }
        }
        return aux;
    }
}
