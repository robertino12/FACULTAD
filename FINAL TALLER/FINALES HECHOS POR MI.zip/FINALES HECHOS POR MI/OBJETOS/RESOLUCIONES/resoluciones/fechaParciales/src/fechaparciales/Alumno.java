package fechaparciales;

public class Alumno {
    private String nombre;
    private int dni;
    private int nroTemaAsignado;

    public Alumno(String nombre, int dni) {
        this.nombre = nombre;
        this.dni = dni;
        this.nroTemaAsignado = -1;
    }

    private String getNombre() {
        return nombre;
    }

    private int getDni() {
        return dni;
    }

    public int getNroTemaAsignado() {
        return nroTemaAsignado;
    }

    public void setNroTemaAsignado(int nroTemaAsignado) {
        this.nroTemaAsignado = nroTemaAsignado;
    }

    @Override
    public String toString() {
        return "Alumno{" + "nombre=" + this.getNombre() + ", dni=" + this.getDni()+"tema asignado= "+this.getNroTemaAsignado()+'}';
    }
    
    
}
