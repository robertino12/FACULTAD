package concurso;

public class Concurso {
   private Pareja[] parejas; 
   private int dimF,dimL;
   
   public Concurso(int dimF){
       this.dimF=dimF;
       this.dimL=0;
       this.parejas=new Pareja[this.dimF];
   }
   
   public Pareja[] getParejas(){
       return this.parejas;
   }
   
   public int getDimF(){
       return this.dimF;
   }
   
   public int getDimL(){
       return this.dimL;
   }
   
   public void setDimL(int dimL){
       this.dimL=dimL;
   }
   
   public void agregarPareja(Pareja p){
       this.getParejas()[this.getDimL()]=p;
       this.setDimL(this.getDimL()+1);
   }
   
   public Pareja obtenerParejaMaxDiferencia(){
       Pareja parejaMax=null;
       int difMax=-1;
       for(int i=0;i<this.getDimL();i++){
           if(this.getParejas()[i].obtenerDiferenciaEdadPareja()>difMax){
               difMax=this.getParejas()[i].obtenerDiferenciaEdadPareja();
               parejaMax=this.getParejas()[i];
           }
       }
       return parejaMax;
   }
}
