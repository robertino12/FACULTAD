package concurso;

public class Pareja {
    private Participante[] participantes;
    private String estiloBaile;

    public Pareja(Participante p1,Participante p2,String estiloBaile) {
        this.participantes=new Participante[2];
        this.participantes[0]=p1;
        this.participantes[1]=p2;
        this.estiloBaile = estiloBaile;
    }

    public Participante[] getParticipantes() {
        return this.participantes;
    }

    public String getEstiloBaile() {
        return estiloBaile;
    }

    public int obtenerDiferenciaEdadPareja (){
       int diferencia=(this.getParticipantes()[0].getEdad()-this.getParticipantes()[1].getEdad());
       if(diferencia<0){
           return diferencia*(-1);
       }
       return diferencia;
   }
    
}
