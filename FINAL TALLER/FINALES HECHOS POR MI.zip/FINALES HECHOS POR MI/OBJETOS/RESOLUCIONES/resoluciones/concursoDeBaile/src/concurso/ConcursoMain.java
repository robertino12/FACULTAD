package concurso;

public class ConcursoMain {

    public static void main(String[] args) {
        Concurso concurso=new Concurso(4);
        Participante p1=new Participante(1,"rob",221);
        Participante p2= new Participante(2,"sab",18);
        Pareja pareja1=new Pareja(p1,p2,"salsa");
        Participante p3=new Participante(3,"lu",27);
        Participante p4= new Participante(4,"nahue",32);
        Pareja pareja2=new Pareja(p3,p4,"tango");
        Participante p5=new Participante(5,"cris",80);
        Participante p6= new Participante(6,"omar",56);
        Pareja pareja3=new Pareja(p5,p6,"chamame");
        concurso.agregarPareja(pareja1);
        concurso.agregarPareja(pareja2);
        concurso.agregarPareja(pareja3);
        System.out.println("nombres pareja con mayor diferencia de edad: "+concurso.obtenerParejaMaxDiferencia().getParticipantes()[0].getNombre()+" y "+concurso.obtenerParejaMaxDiferencia().getParticipantes()[1].getNombre());
    }
    
}
