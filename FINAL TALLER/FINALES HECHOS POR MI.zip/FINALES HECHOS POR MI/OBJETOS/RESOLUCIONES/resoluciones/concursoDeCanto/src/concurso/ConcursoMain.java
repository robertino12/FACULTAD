package concurso;

public class ConcursoMain {

    public static void main(String[] args) {
        Concurso concurso=new Concurso(3,5);
        Estudiante e1=new Estudiante("rober","lucen",1);
        Estudiante e2=new Estudiante("sabri","ona",2);
        Estudiante e3=new Estudiante("tom","luce",3);
        Estudiante e4=new Estudiante("lucia","gonzales",4);
        Estudiante e5=new Estudiante("nahue","perez",5);
        Cancion c1=new Cancion("quavo","duki",10);
        Cancion c2=new Cancion("loca","khea",2);
        Cancion c3=new Cancion("sin frenos","eladio",5);
        Cancion c4=new Cancion("moon","becerra",7);
        Cancion c5=new Cancion("sigo fresh","fuego",12);
        concurso.agregarCancion(c1, 1);
        concurso.agregarCancion(c2, 1);
        concurso.agregarCancion(c3, 3);
        concurso.agregarCancion(c4, 2);
        concurso.agregarCancion(c5, 3);
        concurso.interpretarCancion(12, e5, 5);
        concurso.interpretarCancion(12, e4, 8);
        concurso.interpretarCancion(5, e1, 8);
        concurso.interpretarCancion(5, e2, 10);
        concurso.interpretarCancion(7, e3, 6);
        if(concurso.conocerEstudianteGanador(5)==null){
            System.out.println("nadie");
        }
        else
            System.out.println(concurso.conocerEstudianteGanador(5).toString());
        
        System.out.println(concurso.conocerCancionMasPuntaje(0).toString());
        System.out.println(concurso.conocerCancionMasPuntaje(1).toString());
        System.out.println(concurso.conocerCancionMasPuntaje(2).toString());
    }
    
}
