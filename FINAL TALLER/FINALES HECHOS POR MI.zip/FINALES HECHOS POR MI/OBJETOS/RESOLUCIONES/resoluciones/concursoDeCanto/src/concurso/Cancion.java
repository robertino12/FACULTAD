package concurso;

public class Cancion {
    private String nombre;
    private String compositor;
    private int identificador;
    private Estudiante mejorEstudianteInterpretador;
    private double puntaje;

    public Cancion(String nombre, String compositor, int identificador) {
        this.nombre = nombre;
        this.compositor = compositor;
        this.identificador = identificador;
        this.mejorEstudianteInterpretador = null;
        this.puntaje = 0;
    }

    public String getNombre() {
        return this.nombre;
    }

    public String getCompositor() {
        return this.compositor;
    }

    public int getIdentificador() {
        return this.identificador;
    }

    public Estudiante getMejorEstudianteInterpretador() {
        return this.mejorEstudianteInterpretador;
    }

    public double getPuntaje(){
        return this.puntaje;
    }
    
    public void setPuntaje(double p){
        this.puntaje=p;
    }
    
    public void setMejorEstudianteInterpretador(Estudiante e){
        this.mejorEstudianteInterpretador=e;
    }
    
    public void actualizarInterpretacion(Estudiante e,double puntaje){
        if(this.getMejorEstudianteInterpretador()==null){
            this.setMejorEstudianteInterpretador(e);
        }
        else
        if(this.getPuntaje()>puntaje){
            this.setPuntaje(puntaje);
            this.setMejorEstudianteInterpretador(e);
        }
    }
    
    public Estudiante mayorPuntaje(){
        Estudiante e=null;
        if(this.getMejorEstudianteInterpretador()!=null){
            e=this.getMejorEstudianteInterpretador();
        }
        return e;
    }

    @Override
    public String toString() {
        return "Cancion= " + "nombre=" + this.getNombre()+ ", compositor=" + this.getCompositor();
    }
    
    
}
