package concurso;

public class Concurso {
    private Cancion[][] concurso;
    private int dimFCategorias;//filas
    private int dimFCanciones;//columnas
    private int[] dimLCanciones;//diml columnas

    public Concurso(int dimFCategorias, int dimFCanciones) {
        this.dimFCategorias = dimFCategorias;
        this.dimFCanciones=dimFCanciones;
        this.concurso = new Cancion[this.dimFCategorias][this.dimFCanciones];
        this.dimLCanciones=new int[this.dimFCategorias];
        for(int i=0;i<this.dimFCategorias;i++){
            this.dimLCanciones[i]=0;
        }
    }

    public Cancion[][] getConcurso() {
        return concurso;
    }

    public int getDimFCategorias() {
        return dimFCategorias;
    }

    public int getDimFCanciones() {
        return dimFCanciones;
    }
    
    public int[] getDimLCanciones(){
        return this.dimLCanciones;
    }
    
    public void agregarCancion(Cancion c,int categoria){
        boolean parar=false;
        if(categoria<this.getDimFCategorias()){
                this.getConcurso()[categoria-1][this.getDimLCanciones()[categoria-1]]=c;
                this.getDimLCanciones()[categoria-1]+=1;
        }//para agregar en la fila categoria en la primer columna libre
            
    }
    
    public void interpretarCancion(int identificador, Estudiante e, double puntaje){
        boolean parar=false;
        int i=0;
        while(parar==false){//no pongo menor a la dimF xq dice que seguro existe osea lo va a encontrar
            int j=0;
            while((j<this.getDimLCanciones()[i])&&(parar==false)){
                if(this.getConcurso()[i][j].getIdentificador()==identificador){
                    this.getConcurso()[i][j].actualizarInterpretacion(e, puntaje);
                    parar=true;
                }
                else
                    j++;
            }
            i++;
        }
    }
    
    public Estudiante conocerEstudianteGanador(int identificador){
        Estudiante e=null;
        boolean parar=false;
        int i=0;
        while(parar==false){//no pongo menor a la dimF xq dice que seguro existe osea lo va a encontrar
            int j=0;
            while((j<this.getDimLCanciones()[i])&&(parar==false)){
                if(this.getConcurso()[i][j].getIdentificador()==identificador){
                    e=this.getConcurso()[i][j].mayorPuntaje();
                    parar=true;
                }
                else
                    j++;
            }
            i++;
        }
        return e;
    }
    
    public Cancion conocerCancionMasPuntaje (int categoria){
        int i=0;
        Cancion maxCancion=null;
        double maxPuntaje=0;
        if(categoria<this.getDimFCategorias()){
            while(i<this.getDimLCanciones()[categoria]){
                if(this.getConcurso()[categoria][i].getPuntaje()>maxPuntaje){
                    maxPuntaje=this.getConcurso()[categoria][i].getPuntaje();
                    maxCancion=this.getConcurso()[categoria][i];
                }
                i++;
            }
        }
        
        return maxCancion;
    }
}
