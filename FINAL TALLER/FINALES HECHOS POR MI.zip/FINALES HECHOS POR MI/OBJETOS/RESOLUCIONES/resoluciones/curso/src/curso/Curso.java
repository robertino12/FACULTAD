package curso;
//EMPECE 13:05 termine 14:11 1hs aprox
public abstract class Curso {
    private int anioCursada;
    private Alumno[] alumnos;
    private int dimF,dimL;
    
    public Curso(int anioCursada,int dimF){
        this.anioCursada=anioCursada;
        this.dimF=dimF;
        this.alumnos=new Alumno[this.dimF];
        this.dimL=0;
    }

    public int getAnioCursada() {
        return anioCursada;
    }

    public void setAnioCursada(int anioCursada) {
        this.anioCursada = anioCursada;
    }

    public Alumno[] getAlumnos() {
        return alumnos;
    }

    public int getDimF() {
        return dimF;
    }

    public int getDimL() {
        return dimL;
    }

    public void setDimL(int dimL) {
        this.dimL = dimL;
    }
    
    public boolean agregarAlumno(Alumno a){
        boolean aux=false;
        if(this.getDimL()<this.getDimF()){
            this.getAlumnos()[this.getDimL()]=a;
            this.setDimL(this.getDimL()+1);
            aux=true;
        }
        return aux;
    }
    
    public void incrementarAsistencia(int dni){
        boolean encontro=false;
        int i=0;
        while((i<this.getDimL())&&(encontro==false)){
            if(this.getAlumnos()[i].incrementarA(dni)){
                encontro=true;
            }
            else
                i++;
        }
    }
    
    public void aprobarAutoevaluacion(int dni){
        boolean encontro=false;
        int i=0;
        while((i<this.getDimL())&&(encontro==false)){
            if(this.getAlumnos()[i].incrementarAutoevaluacion(dni)){
                encontro=true;
            }
            else
                i++;
        }
    }
    
    public abstract boolean puedeRendir(Alumno a);
    
    public int cantidadAlumnosPuedenRendir(){
        int cantidad=0;
        for(int i=0;i<this.getDimL();i++){
            if(this.puedeRendir(this.getAlumnos()[i])){
                cantidad++;
            }
        }
        return cantidad;
    }
}
