package curso;

public class Alumno {
    private int dni;
    private String nombre;
    private int asistencias;
    private int cantEvaluacionesAprobadas;

    public Alumno(int dni, String nombre) {
        this.dni = dni;
        this.nombre = nombre;
        this.asistencias = 0;
        this.cantEvaluacionesAprobadas = 0;
    }

    public int getDni() {
        return dni;
    }

    public void setDni(int dni) {
        this.dni = dni;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public int getAsistencias() {
        return asistencias;
    }

    public void setAsistencias(int asistencias) {
        this.asistencias = asistencias;
    }

    public int getCantEvaluacionesAprobadas() {
        return cantEvaluacionesAprobadas;
    }

    public void setCantEvaluacionesAprobadas(int cantEvaluacionesAprobadas) {
        this.cantEvaluacionesAprobadas = cantEvaluacionesAprobadas;
    }
    
    public boolean incrementarA(int dni){
        boolean aux=false;
        if(this.getDni()==dni){
            this.setAsistencias(this.getAsistencias()+1);
            aux=true;
        }   
        return aux;
    }
    
    public boolean incrementarAutoevaluacion(int dni){
        boolean aux=false;
        if(this.getDni()==dni){
            this.setCantEvaluacionesAprobadas(this.getCantEvaluacionesAprobadas()+1);
            aux=true;
        }   
        return aux;
    }
    
    public boolean alMenosTresAsistencias(){
        boolean aux=false;
        if(this.getAsistencias()>=3){
            aux=true;
        }
        return aux;
    }
    
    public boolean puedenAdistancia(){
        boolean aux=false;
        if((this.getCantEvaluacionesAprobadas()==3)&&(this.getAsistencias()>=1)){
            aux=true;
        }
        return aux;
    }
}
