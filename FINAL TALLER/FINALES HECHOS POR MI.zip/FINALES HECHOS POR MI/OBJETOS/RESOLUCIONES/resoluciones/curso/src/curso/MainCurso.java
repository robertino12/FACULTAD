package curso;

public class MainCurso {

    public static void main(String[] args) {
        CursoPresencial cursoPresencial=new CursoPresencial(1,2020,4);
        CursoDistancia cursoDistancia=new CursoDistancia("matematica.zoom",2022,5);
        Alumno a1=new Alumno(1,"rober");
        Alumno a2=new Alumno(2,"sabri");
        Alumno a3=new Alumno(3,"jorge");
        Alumno a4=new Alumno(4,"fran");
        Alumno a5=new Alumno(5,"tom");
        Alumno a6=new Alumno(6,"mati");
        cursoPresencial.agregarAlumno(a1);
        cursoPresencial.agregarAlumno(a2);
        cursoPresencial.agregarAlumno(a3);
        cursoDistancia.agregarAlumno(a4);
        cursoDistancia.agregarAlumno(a5);
        cursoDistancia.agregarAlumno(a6);
        cursoPresencial.incrementarAsistencia(1);
        cursoPresencial.incrementarAsistencia(1);
        cursoPresencial.incrementarAsistencia(1);
        cursoPresencial.incrementarAsistencia(2);//solo sabri podria rendir presencial
        cursoPresencial.incrementarAsistencia(2);
        cursoPresencial.incrementarAsistencia(2);
        cursoPresencial.incrementarAsistencia(3);
        cursoPresencial.aprobarAutoevaluacion(2);
        cursoPresencial.aprobarAutoevaluacion(1);
        cursoDistancia.incrementarAsistencia(4);
        cursoDistancia.incrementarAsistencia(5);
        cursoDistancia.incrementarAsistencia(6);
        cursoDistancia.aprobarAutoevaluacion(4);
        cursoDistancia.aprobarAutoevaluacion(4);
        cursoDistancia.aprobarAutoevaluacion(4);
        cursoDistancia.aprobarAutoevaluacion(5);
        cursoDistancia.aprobarAutoevaluacion(5);
        cursoDistancia.aprobarAutoevaluacion(6);
        cursoDistancia.aprobarAutoevaluacion(6);//el 4 y 6 pueden rendir a distancia
        cursoDistancia.aprobarAutoevaluacion(6);
        System.out.println(cursoPresencial.cantidadAlumnosPuedenRendir());
        System.out.println(cursoDistancia.cantidadAlumnosPuedenRendir());
    }
    
}
