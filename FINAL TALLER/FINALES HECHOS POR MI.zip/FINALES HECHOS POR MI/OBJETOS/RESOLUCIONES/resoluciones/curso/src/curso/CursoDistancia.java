package curso;

public class CursoDistancia extends Curso {
    private String linkSalaVirtual;

    public CursoDistancia(String linkSalaVirtual, int anioCursada, int dimF) {
        super(anioCursada, dimF);
        this.linkSalaVirtual = linkSalaVirtual;
    }

    public String getLinkSalaVirtual() {
        return linkSalaVirtual;
    }
    
    @Override
    public boolean puedeRendir(Alumno a){
        return a.puedenAdistancia();
    }
   
}
