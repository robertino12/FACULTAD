package curso;

public class CursoPresencial extends Curso {
    private int numeroAula;

    public CursoPresencial(int numeroAula, int anioCursada, int dimF) {
        super(anioCursada, dimF);
        this.numeroAula = numeroAula;
    }

    public int getNumeroAula() {
        return numeroAula;
    }

    public void setNumeroAula(int numeroAula) {
        this.numeroAula = numeroAula;
    }
    
    @Override
    public boolean puedeRendir(Alumno a){
        return a.alMenosTresAsistencias();
    }
}
