package gnc;

public class MainGnc {

    public static void main(String[] args) {
        Estacion estacion=new Estacion("122",900,3);
        estacion.agregarVentaSurtidor(3, 1, 20, "efectivo");
        estacion.agregarVentaSurtidor(3, 2, 10, "debito");
        estacion.agregarVentaSurtidor(1, 3, 30, "credito");
        estacion.agregarVentaSurtidor(1, 4, 40, "efectivo");
        estacion.agregarVentaSurtidor(4, 5, 50, "debito");
        estacion.agregarVentaSurtidor(4, 6, 60, "credito");
        estacion.agregarVentaSurtidor(5, 7, 100, "efectivo");
        estacion.agregarVentaSurtidor(5, 8, 25, "debitoo");
        estacion.agregarVentaSurtidor(2, 9, 22, "creditoo");
        estacion.agregarVentaSurtidor(2, 10, 23, "efectivo");
        estacion.agregarVentaSurtidor(6, 11, 200, "debito");
        estacion.agregarVentaSurtidor(6, 12, 2, "credito");
        
        estacion.marcarSurtidoresFueraServicio(80);
        
        System.out.println(estacion.mayorAbono());//ejecuta el toString definido cuando no le ponemos nada e imprimimos el objeto
        
        System.out.println(estacion.toString());
    }
    
}
