package gnc;
//empece 22:40 termine 12
public class Estacion {
    private String direccion;
    private double precioPorM3;
    private Surtidor[] surtidores;
    private int dimF;
    
    public Estacion(String direccion, double precioPorM3, int dimFVentas){
        this.direccion=direccion;
        this.precioPorM3=precioPorM3;
        this.dimF=6;
        this.surtidores=new Surtidor[this.dimF];
        for(int i=0;i<this.dimF;i++){
            Surtidor surtidor=new Surtidor(dimFVentas);
            this.surtidores[i]=surtidor;
        }
    }

    private String getDireccion() {
        return direccion;
    }

    private double getPrecioPorM3() {
        return precioPorM3;
    }

    private Surtidor[] getSurtidores() {
        return surtidores;
    }

    private int getDimF() {
        return dimF;
    }
    
    public void agregarVentaSurtidor(int numSurti,int dni, int cantM3, String formaPago){
        this.getSurtidores()[numSurti-1].generarVenta(dni, cantM3, formaPago, this.getPrecioPorM3());
    }
    
    public void marcarSurtidoresFueraServicio(int x){
        for(int i=0;i<this.getDimF();i++){
            this.getSurtidores()[i].marcarServicio(x);
        }
    }
    
    public Venta mayorAbono(){
        double maxMonto=0;
        Venta maxVenta=null;
        for(int i=0;i<this.getDimF();i++){
            if(this.getSurtidores()[i].mayorVenta()!=null){
                if(this.getSurtidores()[i].mayorVenta().getMontoAbonado()>maxMonto){
                    maxMonto=this.getSurtidores()[i].mayorVenta().getMontoAbonado();
                    maxVenta=this.getSurtidores()[i].mayorVenta();
                }
            }
        }
        return maxVenta;
    }
    
    @Override
    public String toString() {
        String aux="Estacion de servicio: direccion= "+this.getDireccion()+", precio por M3: "+this.getPrecioPorM3()+", info de surtidores \n";
        for(int i=0;i<this.getDimF();i++){
            aux+="\n surtidor "+(i+1)+this.getSurtidores()[i].toString();
        }
        return aux;
    }
}
