package gnc;

public class Venta {
    private int dniCliente;
    private int cantM3Cargados;
    private String medioPago;
    private double montoAbonado;

    public Venta(int dniCliente, int cantM3Cargados, String medioPago, double montoAbonado) {
        this.dniCliente = dniCliente;
        this.cantM3Cargados = cantM3Cargados;
        this.medioPago = medioPago;
        this.montoAbonado=montoAbonado;
    }

    private int getDniCliente() {
        return dniCliente;
    }

    public int getCantM3Cargados() {
        return cantM3Cargados;
    }

    private String getMedioPago() {
        return medioPago;
    }

    public double getMontoAbonado() {
        return montoAbonado;
    }

    @Override
    public String toString() {
        return "dniCliente=" + this.getDniCliente() + ", cantM3Cargados=" + this.getCantM3Cargados() + ", medioPago=" + this.getMedioPago() + ", montoAbonado=" + this.getMontoAbonado() + '}';
    }
    
    
}
