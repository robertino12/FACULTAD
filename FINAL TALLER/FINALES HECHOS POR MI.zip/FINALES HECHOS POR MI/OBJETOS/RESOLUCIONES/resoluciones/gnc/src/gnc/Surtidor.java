package gnc;

public class Surtidor {
    private boolean fueraServicio;
    private Venta[]ventas;
    private int dimF,dimL;
    
    public Surtidor(int dimF){
        this.fueraServicio=false;
        this.dimF=dimF;
        this.dimL=0;
        this.ventas=new Venta[this.dimF];
    }

    private boolean isFueraServicio() {
        return fueraServicio;
    }

    private void setFueraServicio(boolean fueraServicio) {
        this.fueraServicio = fueraServicio;
    }

    private Venta[] getVentas() {
        return ventas;
    }

    private int getDimF() {
        return dimF;
    }

    private int getDimL() {
        return dimL;
    }

    private void setDimL(int dimL) {
        this.dimL = dimL;
    }
    
    public void generarVenta (int dni,int cantM3, String formaPago, double monto){
        Venta v=new Venta(dni,cantM3,formaPago,monto*cantM3);
        if(this.getDimL()<this.getDimF()&&(this.isFueraServicio()==false)){
            this.getVentas()[this.getDimL()]=v;
            this.setDimL(this.getDimL()+1);
        }
    }
    
    public void marcarServicio (int x){
        int totalM3=0;
        for(int i=0;i<this.getDimL();i++){
            totalM3+=this.getVentas()[i].getCantM3Cargados();
        }
        if(totalM3<x){
            this.setFueraServicio(true);
        }
    }
    
    public Venta mayorVenta(){
        double maxMonto=0;
        Venta maxVenta=null;
        for(int i=0;i<this.getDimL();i++){
            if(this.getVentas()[i].getMontoAbonado()>maxMonto){
                maxMonto=this.getVentas()[i].getMontoAbonado();
                maxVenta=this.getVentas()[i];
            }
        }
        return maxVenta;
    }

    @Override
    public String toString() {
        String aux=": fueraServicio? =" + this.isFueraServicio() + ", info ventas: \n";
        for(int i=0;i<this.getDimL();i++){
            aux+="venta: "+(i+1)+ this.getVentas()[i].toString();
        }
        return aux;
    }
    
    
}
