package concursodecantodenuevopracticar;

public class Concurso {
    private Cancion[][] concurso;
    private int dimFFila,dimFC;
    private int[] dimL;
    
    public Concurso(int dimFFila,int dimFC){
        this.dimFFila=dimFFila;
        this.dimFC=dimFC;
        this.concurso=new Cancion[dimFFila][dimFC];
        this.dimL=new int[dimFFila];
        for(int i=0;i<dimFFila;i++){
            this.dimL[i]=0;
        }
    }

    public Cancion[][] getConcurso() {
        return concurso;
    }
    private int getDimFFila() {
        return dimFFila;
    }

    private int getDimFC() {
        return dimFC;
    }

    private int[] getDimL() {
        return dimL;
    }
    
    public void agregarCancion(Cancion c,int categoria){
        this.getConcurso()[categoria-1][this.getDimL()[categoria-1]]=c;
        this.getDimL()[categoria-1]++;
    }
    
    public void interpretarCacion(int identificador, Estudiante interpretador, double puntajeOtorgado){
        boolean encontro=false;
        int i=0;
        while(encontro==false){
            int j=0;
            while((j<this.getDimL()[i])&&(encontro==false)){
                if(this.getConcurso()[i][j].esCancion(identificador)){
                    this.getConcurso()[i][j].actualizarPuntaje(interpretador, puntajeOtorgado);
                    encontro=true;
                }
                else
                    j++;
            }
            i++;
        }
    }
    
    public Estudiante conocerEstudianteGanador(int id){
        Estudiante ganador=null;
        boolean encontro=false;
        int i=0;
        while(encontro==false){
            int j=0;
            while((j<this.getDimL()[i])&&(encontro==false)){
                if(this.getConcurso()[i][j].esCancion(id)){
                    ganador=this.getConcurso()[i][j].puntajeMasAlto();
                    encontro=true;
                }
                else
                    j++;
            }
            i++;
        }
        return ganador;
    }
    
    public Cancion puntajeMasGrande(int categoria){
        Cancion maxCancion=null;
        double maxPuntaje=-1;
        if((categoria-1)<(this.getDimFFila())){
            for(int j=0;j<this.getDimL()[categoria-1];j++){
                    if(this.getConcurso()[categoria-1][j].getPuntajeOtorgado()>maxPuntaje){
                        maxPuntaje=this.getConcurso()[categoria-1][j].getPuntajeOtorgado();
                        maxCancion=this.getConcurso()[categoria-1][j];
                    }

            }
        }
        
        return maxCancion;
    }
}
