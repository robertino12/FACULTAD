package concursodecantodenuevopracticar;

public class Cancion {
    private String nombre;
    private String compositor;
    private int identificadorUnico;
    private Estudiante estMejorInter;
    private double puntajeOtorgado;

    public Cancion(String nombre, String compositor, int identificadorUnico) {
        this.nombre = nombre;
        this.compositor = compositor;
        this.identificadorUnico = identificadorUnico;
        this.puntajeOtorgado = 0;
        this.estMejorInter=null;
    }

    public String getNombre() {
        return nombre;
    }

    public String getCompositor() {
        return compositor;
    }

    private int getIdentificadorUnico() {
        return identificadorUnico;
    }

    private Estudiante getEstMejorInter() {
        return estMejorInter;
    }

    private void setEstMejorInter(Estudiante estMejorInter) {
        this.estMejorInter = estMejorInter;
    }

    public double getPuntajeOtorgado() {
        return puntajeOtorgado;
    }

    private void setPuntajeOtorgado(double puntajeOtorgado) {
        this.puntajeOtorgado = puntajeOtorgado;
    }
    
    public void actualizarPuntaje(Estudiante interpretador,double puntajeOtorgado){
        if(puntajeOtorgado>this.getPuntajeOtorgado()){
            this.setPuntajeOtorgado(puntajeOtorgado);
            this.setEstMejorInter(interpretador);
        }
    }
    
    public boolean esCancion(int identificador){
        boolean aux=false;
        if(this.getIdentificadorUnico()==identificador){
            aux=true;
        }
        return aux;
    }
    
    public Estudiante puntajeMasAlto(){
        Estudiante maxPuntaje=null;
        if(this.getEstMejorInter()!=null){
            maxPuntaje=this.getEstMejorInter();
        }
        return maxPuntaje;
    }
    
}
