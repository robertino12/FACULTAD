package concursodecantodenuevopracticar;
import java.util.Scanner;
public class ConcursoMain {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        Concurso concurso=new Concurso(3,5);
        Cancion c1=new Cancion("loca","khea",5);
        Cancion c2=new Cancion("colocao","nicki",2);
        Cancion c3=new Cancion("hello cotto","duki",7);
        Cancion c4=new Cancion("lovely","billie",3);
        Cancion c5=new Cancion("smoke that","eminem",6);
        
        concurso.agregarCancion(c1,1);
        concurso.agregarCancion(c2,1);
        concurso.agregarCancion(c3,2);
        concurso.agregarCancion(c4,2);
        concurso.agregarCancion(c5,3);
        
        Estudiante e1=new Estudiante("rob","lucen",1);
        Estudiante e2=new Estudiante("sabri","oña",2);
        Estudiante e3=new Estudiante("jorge","davila",3);
        
        concurso.interpretarCacion(7, e1, 7);
        concurso.interpretarCacion(3, e2, 10);
        concurso.interpretarCacion(6, e3, 8);
        
        System.out.print("Ingrese un identificador d cancion: ");
        int identificador = scanner.nextInt();
        
        if(concurso.conocerEstudianteGanador(identificador)!=null){
            System.out.println(concurso.conocerEstudianteGanador(identificador).getNombre());
            System.out.println(concurso.conocerEstudianteGanador(identificador).getApellido());
            System.out.println(concurso.conocerEstudianteGanador(identificador).getDni());
        }
        else
            System.out.println("nadie");
        
        scanner.close();
        
        if(concurso.puntajeMasGrande(1).getPuntajeOtorgado()==0){
            System.out.println("nadie interpreto");
        }
        System.out.println(concurso.puntajeMasGrande(2).getNombre());
        System.out.println(concurso.puntajeMasGrande(3).getNombre());//m tendria q decir lovely y smack that
    }
    
}
