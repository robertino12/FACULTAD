package polizas;

public class Cliente {
    private int dni;
    private String nombre;
    private String apellido;

    public Cliente(int dni, String nombre, String apellido) {
        this.dni = dni;
        this.nombre = nombre;
        this.apellido = apellido;
    }

    private int getDni() {
        return dni;
    }

    private String getNombre() {
        return nombre;
    }

    private String getApellido() {
        return apellido;
    }

    public boolean coincideDni(int dni){
        boolean aux=false;
        if(this.getDni()==dni){
            aux=true;
        }
        return aux;
    }
    
    @Override
    public String toString() {
        return "Cliente{" + "dni=" + this.getDni() + ", nombre=" + this.getNombre() + ", apellido=" + this.getApellido() + '}';
    }
    
    
}
