package polizas;
import java.util.Scanner;
public class MainCompañia {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        Compañia compañia = new Compañia();
        Fecha fC = new Fecha(10, 10, 2023);
        Fecha fV = new Fecha(26, 4, 2024);
        Fecha noV=new Fecha(31,8,2026);
        Cliente c1 = new Cliente(1, "rob", "lucen");
        Cliente c2 = new Cliente(2, "sabri", "ona");
        Cliente c3 = new Cliente(3, "mark", "ona");
        Poliza p1 = new Poliza(10000, 5000, fC, fV, c1);
        Poliza p2 = new Poliza(100000,10000,fC, noV,c1);
        Poliza p3 = new Poliza(50000,8000,fC,noV,c2);
        Poliza p4 = new Poliza(5000,2000,fC,fV,c2);
        Poliza p5 = new Poliza(150000,25000,fC,noV,c3);
        Poliza p6 = new Poliza(256010,12500,fC, noV,c1);
        
        compañia.agregarPoliza(p1, 3);
        compañia.agregarPoliza(p6, 3);
        compañia.agregarPoliza(p2, 1);
        compañia.agregarPoliza(p3, 4);
        compañia.agregarPoliza(p5, 6);
        compañia.agregarPoliza(p4, 2);
        
        System.out.println("ingresar dni: ");
        int dni=scanner.nextInt();
        System.out.println(compañia.infoCliente(dni));//pongo dni 1 y me deberia dar las polizas p1 y p2
        
        compañia.aumentarCuotas(1.11, 3);
        
        System.out.println(compañia.infoCliente(dni));
        
        System.out.println(compañia.cantidadAVencer(4, 2024));
    }

}
