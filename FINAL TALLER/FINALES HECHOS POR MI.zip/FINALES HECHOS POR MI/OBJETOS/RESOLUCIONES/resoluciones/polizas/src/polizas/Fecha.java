package polizas;
public class Fecha {
    private int dia;
    private int mes;
    private int año;

    public Fecha(int dia, int mes, int año) {
        this.dia = dia;
        this.mes = mes;
        this.año = año;
    }

    private int getDia() {
        return dia;
    }
    
    private int getMes() {
        return mes;
    }

    private int getAño() {
        return año;
    }

    
    public boolean mismoFecha(int mes, int año){
        boolean aux=true;
        if((this.getAño()==año)&&(this.getMes()==mes)){
            aux=false;
        }
        return aux;
    }

    @Override
    public String toString() {
        return "Fecha{" + "dia=" + this.getDia() + ", mes=" + this.getMes() + ", a\u00f1o=" + this.getAño() + '}';
    }
    
    
}
