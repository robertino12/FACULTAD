package polizas;

public class Poliza {
    private double montoAsegurado;
    private double valorCuotaMensual;
    private Fecha fechaComienzoCobertura;
    private Fecha fechaFinalCobertura;
    private Cliente cliente;

    public Poliza(double montoAsegurado, double valorCuotaMensual, Fecha fechaComienzoCobertura, Fecha fechaFinalCobertura, Cliente cliente) {
        this.montoAsegurado = montoAsegurado;
        this.valorCuotaMensual = valorCuotaMensual;
        this.fechaComienzoCobertura = fechaComienzoCobertura;
        this.fechaFinalCobertura = fechaFinalCobertura;
        this.cliente = cliente;
    }

    private double getMontoAsegurado() {
        return montoAsegurado;
    }

    private double getValorCuotaMensual() {
        return valorCuotaMensual;
    }
    
    private void setValorCuotaMensual(double valor){
        this.valorCuotaMensual=valor;
    }

    private Fecha getFechaComienzoCobertura() {
        return fechaComienzoCobertura;
    }

    private Fecha getFechaFinalCobertura() {
        return fechaFinalCobertura;
    }

    public Cliente getCliente() {
        return cliente;
    }

    public boolean esVigente (int mes, int año){
        boolean aux=true;
        if(this.getFechaFinalCobertura().mismoFecha(mes,año)){
            aux=false;
        }
        return aux;
    }

    public void aumentarValorCuota(double p){
        this.setValorCuotaMensual(this.getValorCuotaMensual()*p);
    }
    @Override
    public String toString() {
        return "Poliza{" + "montoAsegurado=" + this.getMontoAsegurado() + ", valorCuotaMensual=" + this.getValorCuotaMensual() + ", fechaComienzoCobertura=" + this.getFechaComienzoCobertura().toString() + ", fechaFinalCobertura=" + this.getFechaFinalCobertura().toString()+ '}';
    }
    
    
}
