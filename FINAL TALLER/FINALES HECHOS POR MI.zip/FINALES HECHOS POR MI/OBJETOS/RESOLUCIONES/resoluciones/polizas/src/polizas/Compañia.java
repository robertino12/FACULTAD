package polizas;
//empece 15:26
public class Compañia {
    private Poliza[][] polizas;
    private int dimFFila,dimFCol;
    private int[] dimL;
    
    public Compañia (){
        this.dimFFila=10;
        this.dimFCol=10;
        this.polizas=new Poliza[this.dimFFila][this.dimFCol];
        this.dimL=new int[this.dimFFila];
        for(int i=0;i<this.dimFFila;i++){
            this.dimL[i]=0;
        }
    }

    private Poliza[][] getPolizas() {
        return polizas;
    }

    private int getDimFFila() {
        return dimFFila;
    }

    private int getDimFCol() {
        return dimFCol;
    }

    private int[] getDimL() {
        return dimL;
    }

    private void setDimL(int[] dimL) {
        this.dimL = dimL;
    }
    
    public void agregarPoliza(Poliza unaPoliza, int unRubro){
        if(unRubro<this.dimFFila){
            this.getPolizas()[unRubro-1][this.getDimL()[unRubro-1]]=unaPoliza;
            this.getDimL()[unRubro-1]++;
        }
    }
    
    public String infoCliente(int unDni){ //se recorre toda porque dice que un mismo cliente puede tener mas de una poliza incluso en el mismo rubro
        String aux="informacion de todas las polizas del cliente con dni: "+unDni+"\n";
        for(int i=0;i<this.getDimFFila();i++){
            for(int j=0;j<this.getDimL()[i];j++){
                if(this.getPolizas()[i][j].getCliente().coincideDni(unDni)){
                    aux+="rubro y numero poliza: "+(i+1)+"-"+(j+1)+this.getPolizas()[i][j].toString()+"\n";
                }
            }
        }
        return aux;
    }
    
    public void aumentarCuotas(double unPorcentaje, int unRubro){
        for(int j=0;j<this.getDimL()[unRubro-1];j++){
            if(this.getPolizas()[unRubro-1][j].esVigente(4,2024)){
                this.getPolizas()[unRubro-1][j].aumentarValorCuota(unPorcentaje);
            }
        }
    }
    
    public int cantidadAVencer (int mes, int año){
        int cant=0;
        for(int i=0;i<this.getDimFFila();i++){
            for(int j=0;j<this.getDimL()[i];j++){
                if(this.getPolizas()[i][j].esVigente(mes, año)){
                    cant++;
                }
            }
        }
        return cant;
    }
}
