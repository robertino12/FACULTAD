package empresa;
//EMPECE 11:00 //PARE 11:42 VOLVI 12:22 Termine 12:27, 1hs aprox
public class Empresa {
    private String nombre;
    private String direccion;
    private Director directorEjecutivo;
    private Encargado[] sucursales;
    private int dimF;

    public Empresa(String nombre, String direccion, Director directorEjecutivo, int dimF) {
        this.nombre = nombre;
        this.direccion = direccion;
        this.directorEjecutivo = directorEjecutivo;
        this.dimF = dimF;
        this.sucursales=new Encargado[this.dimF];
        //java  inicializa vacio=null cada elemento del vector por defecto
    }

    private String getNombre() {
        return nombre;
    }

    private String getDireccion() {
        return direccion;
    }

    private Director getDirectorEjecutivo() {
        return directorEjecutivo;
    }

    private Encargado[] getSucursales() {
        return sucursales;
    }

    private int getDimF() {
        return dimF;
    }
    
    public void asignarEncargado(Encargado e, int x){
        this.getSucursales()[x-1]=e;
    }

    @Override
    public String toString() {
        String aux="nombre= "+this.getNombre()+", direccion= "+this.getDireccion()+" datos director= "+this.getDirectorEjecutivo().toString()+" datos encargados: "+"\n";
        for(int i=0;i<this.getDimF();i++){
            if(this.getSucursales()[i]==null){
                aux+="sucursal= "+i+" sin encargado \n";
            }
            else
                aux+="numero sucursal: "+i+" representacion encargados: "+this.getSucursales()[i].toString();
        }
        return aux;
    }
    
    
}
