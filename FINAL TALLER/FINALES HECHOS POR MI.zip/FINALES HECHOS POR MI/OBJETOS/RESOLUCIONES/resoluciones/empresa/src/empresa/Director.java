package empresa;

public class Director extends Empleado{
    private double montoViaticos;
    
    public Director(int montoViaticos,String nombre, int dni, int anioIngreso,double montoBasico){
        super(nombre,dni,anioIngreso,montoBasico);
        this.montoViaticos=montoViaticos;
    }

    private double getMontoViaticos() {
        return montoViaticos;
    }

    @Override
    public double sueldoCobrar(){
        return super.sueldoCobrar()+this.getMontoViaticos();
    }
}
