package empresa;

public class Encargado extends Empleado{
    private int cantEmpleadosACargo;
    
    public Encargado (int cantEmpleadosACargo, String nombre, int dni, int anioIngreso, double sueldoBasico){
        super(nombre,dni,anioIngreso,sueldoBasico);
        this.cantEmpleadosACargo=cantEmpleadosACargo;
    }

    private int getCantEmpleadosACargo() {
        return cantEmpleadosACargo;
    }
   
    @Override
    public double sueldoCobrar(){
        return super.sueldoCobrar()+this.cantEmpleadosACargo*1000;
    }
}
