package empresa;

public class EmpresaMain {

    public static void main(String[] args) {
        Director director=new Director(1500,"rober",44,2000,10000);
        Empresa empresa=new Empresa("tecLucen","nueva york",director,3);
        Encargado e1=new Encargado(50,"tom",40,2020,3000);
        Encargado e2=new Encargado(30,"lu",41,2001,2000);
        empresa.asignarEncargado(e2, 3);
        empresa.asignarEncargado(e1, 2);
        System.out.println(e1.sueldoCobrar());
        System.out.println(e2.sueldoCobrar());
        System.out.println(director.sueldoCobrar());
        System.out.println(empresa.toString());
    }
    
}
