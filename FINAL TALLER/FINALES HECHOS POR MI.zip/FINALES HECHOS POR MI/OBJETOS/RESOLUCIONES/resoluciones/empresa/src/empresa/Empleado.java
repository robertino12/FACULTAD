package empresa;

public abstract class Empleado {
    private String nombre;
    private int dni;
    private int anioIngreso;
    private double sueldoBasico;
    
    public Empleado(String nombre, int dni, int anioIngreso, double sueldoBasico){
        this.nombre=nombre;
        this.dni=dni;
        this.anioIngreso=anioIngreso;
        this.sueldoBasico=sueldoBasico;
    }
    
    private String getNombre(){
        return this.nombre;
    }
    
    private int getDni(){
        return this.dni;
    }

    private int getAnioIngreso() {
        return anioIngreso;
    }

    public double getSueldoBasico() {
        return sueldoBasico;
    }

    public double sueldoCobrar(){
        double sueldo=this.getSueldoBasico();
        if((2024-this.getAnioIngreso())>20){
            sueldo=sueldo*1.10;
        }
        return sueldo;
    }

    @Override
    public String toString() {
        return "Empleado{" + "nombre=" + this.getNombre() + ", dni=" + this.getDni() + ", sueldoBasico=" + this.getSueldoBasico() + '}';
    }
}
