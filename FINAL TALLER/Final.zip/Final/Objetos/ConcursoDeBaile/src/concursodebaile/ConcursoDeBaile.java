/*1. Representar un concurso de baile. El concurso tiene a lo sumo
N parejas. Cada pareja tiene 2 participantes y un estilo de baile.
De los participantes se tiene dni, nombre, edad.

a) Genere las clases necesarias. Provea constructores para iniciar:
el concurso para un máximo de N parejas (inicialmente sin parejas
cargadas); las parejas y los participantes a partir de toda su 
información.

b) Implemente métodos en las clases adecuadas para permitir:

b1) Agregar una pareja al concurso. Asuma que hay lugar.

b2) Obtener la diferencia de edad de la pareja.

b3) Obtener la pareja con más diferencia de edad del concurso.

2. Realice un programa que instancie un concurso, cargue 2 
parejas y a partir del concurso muestre: los nombres de los 
participantes de la pareja con más diferencia de edad.*/
package concursodebaile;

public class ConcursoDeBaile {
    public static void main(String[] args) {
        Concurso concurso=new Concurso(5);
        
        Participante participante1=new Participante(46434641,"Alejo",18);
        Participante participante2=new Participante(22326288,"Beatriz",52);
        Pareja pareja1=new Pareja("Tango",participante1,participante2);
        concurso.agregarPareja(pareja1);
        
        Participante participante3=new Participante(25658985,"Mauro",100);
        Participante participante4=new Participante(35569874,"Pilar",22);
        Pareja pareja2=new Pareja("Tango",participante3,participante4);
        concurso.agregarPareja(pareja2);
        
        System.out.println(concurso.parejaConMasDiferenciaDeEdada().nombreDeParticipantes());
    }
    
}
