/*1. Representar un concurso de baile. El concurso tiene a lo sumo
N parejas. Cada pareja tiene 2 participantes y un estilo de baile.
De los participantes se tiene dni, nombre, edad.

a) Genere las clases necesarias. Provea constructores para iniciar:
el concurso para un máximo de N parejas (inicialmente sin parejas
cargadas); las parejas y los participantes a partir de toda su 
información.

b) Implemente métodos en las clases adecuadas para permitir:

b1) Agregar una pareja al concurso. Asuma que hay lugar.

b2) Obtener la diferencia de edad de la pareja.

b3) Obtener la pareja con más diferencia de edad del concurso.

2. Realice un programa que instancie un concurso, cargue 2 
parejas y a partir del concurso muestre: los nombres de los 
participantes de la pareja con más diferencia de edad.*/
package concursodebaile;
public class Concurso {
    private Pareja[] parejas;
    private int dimF;
    private int dimL;

    public Concurso(int N) {
        this.parejas= new Pareja [N];
        this.setDimF(N);
        this.setDimL(0);
    }
    public void agregarPareja(Pareja pareja){
        this.getParejas()[this.getDimL()]=pareja;
        this.setDimL(this.getDimL()+1);
    }
    public Pareja parejaConMasDiferenciaDeEdada(){
        Pareja pareja=null;
        int max=-1;
        for(int i=0;i<this.getDimL();i++){
            if(this.getParejas()[i].diferenciaDeEdad()>max){
                max=this.getParejas()[i].diferenciaDeEdad();
                pareja=this.getParejas()[i];
            }
        }
        return pareja;
    }
    private Pareja[] getParejas() {
        return parejas;
    }

    private void setParejas(Pareja[] parejas) {
        this.parejas = parejas;
    }

    private int getDimF() {
        return dimF;
    }

    private void setDimF(int dimF) {
        this.dimF = dimF;
    }

    private int getDimL() {
        return dimL;
    }

    private void setDimL(int dimL) {
        this.dimL = dimL;
    }

}
