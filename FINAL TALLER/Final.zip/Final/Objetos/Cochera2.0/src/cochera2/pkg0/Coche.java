/*Una cochera estacionamiento necesita gestionar sus sectores y coches ingresados. La cochera 
tiene dos sectores (cubierto y descubierto). Los sectores conocen el costo a cobrar por hora de 
estacionamiento y la informacion del coche ingresado en c/u de sus 20 lugares. De los coches 
se registra patente y cantidad de horas que estará en el estacionamiento.
1) Genere las clases necesarias. Implemente constructores. Tenga en cuenta que los sectores 
se inician sin coches en sus lugares y que la cochera se inicia a partir del costo por hr. a cobrar 
de cada sector.
2) Agregue los métodos necesarios, en las clases que correspondan, para permitir:
a) Ingresar un coche C en el primer lugar líbre de un sector. Asuma que seguro existe un 
lugar libre. Devuelva el nro. del lugar que ocupará en el sector.
b) Ingresar un coche C a la cochera. El coche se ingresa al sector cubierto si hay lugar libre en el 
mismo, caso contrario se ingresa al sector descubierto. Asuma que hay un lugar libre en alguno 
de los sectores. Devuelva un string que concatene el sector y el nro. de lugar que ocupará en el 
sector
c) Obtener la cantidad total de coches al momento en la cochera (tenga en cuenta ambos 
sectores).
3) Implemente un programa que instancie una cochera (con costo por hora para el sector 
cubierto de $250 y para el descubierto de $220). Ingrese 4 coches y muestre la cantidad total 
de coches en la cochera.*/
package cochera2.pkg0;
public class Coche {
    private String patente;
    private int horas;

    public Coche(String patente, int horas) {
        this.patente = patente;
        this.horas = horas;
    }

    public String getPatente() {
        return patente;
    }

    public void setPatente(String patente) {
        this.patente = patente;
    }

    public int getHoras() {
        return horas;
    }

    public void setHoras(int horas) {
        this.horas = horas;
    }
}
