/*IMPORTANTE: Cree un proyecto en Netbeans, utilice su apellido como nombre del proyecto y guárdelo en el Escritorio de su computadora. Para la entrega, comprima el proyecto a zip.
Se desea representar un sistema que registre conciertos para un estadio. Del estadio se conoce nombre, dirección, capacidad y una estructura que representa la agenda de conciertos que almacenará los conciertos de cada mes y día particular (1.12, 1.31). De cada concierto se guarda el nombre del artista, precio de la entrada, cantidad de entradas vendidas.
1- Genere las clases necesarias. Provea constructores para iniciar: los conciertos y el estadio a partir de la información necesaria; Inicialmente el estadio no tiene conciertos agendados.
2- Implemente los métodos necesarios, en las clases que corresponda, para:
a) Registrar un concierto C en la agenda. El método recibe un mes M y debe registrar el concierto en el siguiente día disponible del mes M.
b) Listar los conciertos del mes M devolviendo un String con la representación de los mismos en el
siguiente formato:
"Nombre del artista, precio de la entrada, cantidad de entradas vendidas"
c) Calcular la ganancia del estadio en el mes M. La ganancia de un mes es la mitad de la recaudación de las entradas vendidas en cada concierto de dicho mes..
d) Obtener un String que represente el estadio siguiendo el ejemplo:
"Estadio: nombre, dirección; capacidad
Mes 1.
Día 1: Nombre del artista, precio de la entrada, cantidad de entradas vendidas
Día 2: Nombre del artista, precio de la entrada, cantidad de entradas vendidas
Mes M.:
3- Realice un programa que instancie un estadio. Registre conciertos y compruebe el correcto
funcionamiento de los métodos implementados.*/
package conciertos;
class Estadio {
    private String nombre;
    private String direccion;
    private int capacidad;
    private Concierto[][] matriz;
    private int dimF;
    private int dimC;
    private int[] dimL;

    public Estadio(String nombre, String direccion, int capacidad) {
        this.setNombre(nombre);
        this.setDireccion(direccion);
        this.setCapacidad(capacidad);
        this.matriz=new Concierto[12][31];
        this.setDimC(12);
        this.setDimF(31);
        this.dimL=new int[12];
        for(int i=0;i<this.getDimC();i++){
            this.getDimL()[i]=0;
        }
    }
    
    /*a) Registrar un concierto C en la agenda. El método recibe un mes M y debe registrar el concierto en el siguiente día disponible del mes M.*/
    public boolean registrarConcierto(Concierto concierto,int mes){
        boolean aux=false;
        if(mes<=this.getDimC()){
          if(this.getDimL()[(mes-1)]<=this.getDimF()){
              aux=true;
              this.getMatriz()[(mes-1)][this.getDimL()[(mes-1)]]=concierto;
              this.setDimL((mes-1));
          }
        }
        return aux;
    }

    /*b) Listar los conciertos del mes M devolviendo un String con la representación de los mismos en el
siguiente formato:
"Nombre del artista, precio de la entrada, cantidad de entradas vendidas"*/
    public String listarConciertos(int mes){
        String aux="\n Mes: "+mes+".";
        if(mes<=this.getDimC()){
            for (int i=0;i<this.getDimL()[(mes-1)];i++){
                int dia=i;
                aux+="\n Dia "+(dia+1)+": "+this.getMatriz()[(mes-1)][i].toString();
            }
        }
        else{
            aux="No se ingreso un mes valido";
        }
        return aux;
    }
    /*c) Calcular la ganancia del estadio en el mes M. La ganancia de un mes es la mitad de la recaudación de las entradas vendidas en cada concierto de dicho mes..*/
    public double ganancias(int mes){
        double aux=0;
        if(mes<=this.getDimC()){
            for (int i=0;i<this.getDimL()[mes-1];i++){
                aux+=this.getMatriz()[(mes-1)][i].ganancia()/2;
            }
        }
        return aux;
    }
    /*d) Obtener un String que represente el estadio siguiendo el ejemplo:
"Estadio: nombre, dirección; capacidad
Mes 1.
Día 1: Nombre del artista, precio de la entrada, cantidad de entradas vendidas
Día 2: Nombre del artista, precio de la entrada, cantidad de entradas vendidas
Mes M.:*/
    @Override
    public String toString(){
        String aux="Estadio: "+this.getNombre()+","+this.getDireccion()+"; "+this.getCapacidad();
        for(int i=0;i<this.getDimC();i++){
            aux+=this.listarConciertos(i+1);
        }
        return aux;
    }
    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getDireccion() {
        return direccion;
    }

    public void setDireccion(String direccion) {
        this.direccion = direccion;
    }

    public int getCapacidad() {
        return capacidad;
    }

    public void setCapacidad(int capacidad) {
        this.capacidad = capacidad;
    }

    private Concierto[][] getMatriz() {
        return matriz;
    }

    private void setMatriz(Concierto[][] matriz) {
        this.matriz = matriz;
    }

    private int getDimF() {
        return dimF;
    }

    private void setDimF(int dimF) {
        this.dimF = dimF;
    }

    private int getDimC() {
        return dimC;
    }

    private void setDimC(int dimC) {
        this.dimC = dimC;
    }

    private int[] getDimL() {
        return dimL;
    }

    private void setDimL(int mes) {
        this.getDimL()[mes]+=1;
    }
}
