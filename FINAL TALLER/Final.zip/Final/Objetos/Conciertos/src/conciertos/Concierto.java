/*IMPORTANTE: Cree un proyecto en Netbeans, utilice su apellido como nombre del proyecto y guárdelo en el Escritorio de su computadora. Para la entrega, comprima el proyecto a zip.
Se desea representar un sistema que registre conciertos para un estadio. Del estadio se conoce nombre, dirección, capacidad y una estructura que representa la agenda de conciertos que almacenará los conciertos de cada mes y día particular (1.12, 1.31). 
De cada concierto se guarda el nombre del artista, precio de la entrada, cantidad de entradas vendidas.
1- Genere las clases necesarias. Provea constructores para iniciar: los conciertos y el estadio a partir de la información necesaria; Inicialmente el estadio no tiene conciertos agendados.
2- Implemente los métodos necesarios, en las clases que corresponda, para:
a) Registrar un concierto C en la agenda. El método recibe un mes M y debe registrar el concierto en el siguiente día disponible del mes M.
b) Listar los conciertos del mes M devolviendo un String con la representación de los mismos en el
siguiente formato:
"Nombre del artista, precio de la entrada, cantidad de entradas vendidas"
c) Calcular la ganancia del estadio en el mes M. La ganancia de un mes es la mitad de la recaudación de las entradas vendidas en cada concierto de dicho mes..
d) Obtener un String que represente el estadio siguiendo el ejemplo:
"Estadio: nombre, dirección; capacidad
Mes 1.
Día 1: Nombre del artista, precio de la entrada, cantidad de entradas vendidas
Día 2: Nombre del artista, precio de la entrada, cantidad de entradas vendidas
Mes M.:
3- Realice un programa que instancie un estadio. Registre conciertos y compruebe el correcto
funcionamiento de los métodos implementados.*/
package conciertos;
public class Concierto {
    private String nombre;
    private double precio;
    private int cantidad;

    public Concierto(String nombre, double precio, int cantidad) {
        this.setNombre(nombre);
        this.setPrecio(precio);
        this.setCantidad(cantidad);
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public double getPrecio() {
        return precio;
    }

    public void setPrecio(double precio) {
        this.precio = precio;
    }

    public int getCantidad() {
        return cantidad;
    }

    public void setCantidad(int cantidad) {
        this.cantidad = cantidad;
    }

    @Override
    public String toString() {
        return  this.getNombre()+" "+this.getPrecio()+"$ "+this.getCantidad();
    }
    public double ganancia(){
        double aux=this.getCantidad()*this.getPrecio();
        return aux;
    }
}
