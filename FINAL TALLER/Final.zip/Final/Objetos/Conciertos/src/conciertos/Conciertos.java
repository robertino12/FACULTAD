/*IMPORTANTE: Cree un proyecto en Netbeans, utilice su apellido como nombre del proyecto y guárdelo en el Escritorio de su computadora. Para la entrega, comprima el proyecto a zip.
Se desea representar un sistema que registre conciertos para un estadio. Del estadio se conoce nombre, dirección, capacidad y una estructura que representa la agenda de conciertos que almacenará los conciertos de cada mes y día particular (1.12, 1.31). De cada concierto se guarda el nombre del artista, precio de la entrada, cantidad de entradas vendidas.
1- Genere las clases necesarias. Provea constructores para iniciar: los conciertos y el estadio a partir de la información necesaria; Inicialmente el estadio no tiene conciertos agendados.
2- Implemente los métodos necesarios, en las clases que corresponda, para:
a) Registrar un concierto C en la agenda. El método recibe un mes M y debe registrar el concierto en el siguiente día disponible del mes M.
b) Listar los conciertos del mes M devolviendo un String con la representación de los mismos en el
siguiente formato:
"Nombre del artista, precio de la entrada, cantidad de entradas vendidas"
c) Calcular la ganancia del estadio en el mes M. La ganancia de un mes es la mitad de la recaudación de las entradas vendidas en cada concierto de dicho mes..
d) Obtener un String que represente el estadio siguiendo el ejemplo:
"Estadio: nombre, dirección; capacidad
Mes 1.
Día 1: Nombre del artista, precio de la entrada, cantidad de entradas vendidas
Día 2: Nombre del artista, precio de la entrada, cantidad de entradas vendidas
Mes M.:
3- Realice un programa que instancie un estadio. Registre conciertos y compruebe el correcto
funcionamiento de los métodos implementados.*/
package conciertos;
public class Conciertos {
    public static void main(String[] args) {
        Estadio estadio=new Estadio("Uno","1 y 50",32530);
        
        Concierto concierto1=new Concierto("Wos",10500,10000);
        System.out.println(estadio.registrarConcierto(concierto1,5));
        
        Concierto concierto2=new Concierto("Arjona",5000,15000);
        System.out.println(estadio.registrarConcierto(concierto2,1));
                
        Concierto concierto3=new Concierto("Duki",15000,29000);
        System.out.println(estadio.registrarConcierto(concierto3,2));
        
        Concierto concierto4=new Concierto("Milo J",6000,9000);
        System.out.println(estadio.registrarConcierto(concierto4,12));
        
        Concierto concierto5=new Concierto("Maria Becerra",9000,15000);
        System.out.println(estadio.registrarConcierto(concierto5,11));
        
        Concierto concierto6=new Concierto("Lali",1000,7000);
        System.out.println(estadio.registrarConcierto(concierto6,9));
        
        Concierto concierto7=new Concierto("Tini",11000,32000);
        System.out.println(estadio.registrarConcierto(concierto7,8));
        
        Concierto concierto8=new Concierto("Biza",25000,30000);
        System.out.println(estadio.registrarConcierto(concierto8,8));
        
        Concierto concierto9=new Concierto("Las pastillas del abuelo",3500,11000);
        System.out.println(estadio.registrarConcierto(concierto9,7));
        
        Concierto concierto10=new Concierto("Tylor Swift",50000,32250);
        System.out.println(estadio.registrarConcierto(concierto10,8));
        
        Concierto concierto11=new Concierto("Alan Gomez",500,5000);
        System.out.println(estadio.registrarConcierto(concierto11,4));
        
        System.out.println(estadio.toString());
        System.out.println(estadio.ganancias(8));
    }
    
}

