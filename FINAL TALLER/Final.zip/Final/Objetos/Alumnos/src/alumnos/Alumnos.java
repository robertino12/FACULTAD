/*Representar alumnos de una facultad. De cualquier alumno se conoce: DNI, nombre y sus materias aprobadas (como
máximo N). De las materias aprobadas se registra: nombre, nota y fecha. Además de los alumnos de grado se tiene la
carrera, mientras que de los alumnos de doctorado el título universitario y universidad de origen.
1- Genere las clases necesarias. Provea constructores para iniciar las materias aprobadas y los alumnos a partir de la
información necesaria (estos para un máximo de N materias aprobadas y sin materias aprobadas inicialmente).
2- Implemente los métodos necesarios, en las clases que corresponda, para:
a) Dada una materia aprobada, agregarla a las materias aprobadas del alumno.
b) Determinar si el alumno está graduado, teniendo en cuenta que para ello deben tener un total de N materias
aprobadas y deben tener aprobada la materia “Tesis”.
c) Obtener un String que represente al alumno siguiendo el ejemplo:
Ej. alumnos de grado “DNI; Nombre; Materias aprobadas: nombre, nota y fecha de c/u; Está graduado: …; Carrera”
Ej. alumnos de doctorado “DNI; Nombre; Materias aprobadas: nombre, nota y fecha de c/u; Está graduado: …; Título;
Universidad de Origen”
3- Realice un programa que instancie un alumno de cada tipo. Cargue información de materias aprobadas a cada
uno. Informe en consola el resultado del inciso c).*/
package alumnos;
public class Alumnos {
    public static void main(String[] args) {
        Grado gra=new Grado("Licenciatura en bellas artes",22326288,"Mario",3);
          Materias materiaAproGra=new Materias("tesis",8,"16/10/2023");
            gra.agregarMateriaAprobada(materiaAproGra);
          Materias materiaAproGra1=new Materias("pintura",8,"5/5/2023");
            gra.agregarMateriaAprobada(materiaAproGra1);
          System.out.println("Esta graduado? "+gra.estaGraduado());
          System.out.println(gra.toString());
        
        Doctorado doc=new Doctorado("Licenciatura en Sistemas","Informatica UNLP",46434641,"Alejo",2);
          Materias materiaAproDoc=new Materias("Tesis",9,"18/10/2023");
            doc.agregarMateriaAprobada(materiaAproDoc);
          Materias materiaAproDoc1=new Materias("Taller de programacion",9,"19/10/2023");
            doc.agregarMateriaAprobada(materiaAproDoc1);
          System.out.println("Esta graduado? "+doc.estaGraduado());
          System.out.println(doc.toString());
    }
    
}
