/*Representar alumnos de una facultad. De cualquier alumno se conoce: DNI, nombre y sus materias aprobadas (como
máximo N). De las materias aprobadas se registra: nombre, nota y fecha. Además de los alumnos de grado se tiene la
carrera, mientras que de los alumnos de doctorado el título universitario y universidad de origen.
1- Genere las clases necesarias. Provea constructores para iniciar las materias aprobadas y los alumnos a partir de la
información necesaria (estos para un máximo de N materias aprobadas y sin materias aprobadas inicialmente).
2- Implemente los métodos necesarios, en las clases que corresponda, para:
a) Dada una materia aprobada, agregarla a las materias aprobadas del alumno.
b) Determinar si el alumno está graduado, teniendo en cuenta que para ello deben tener un total de N materias
aprobadas y deben tener aprobada la materia “Tesis”.
c) Obtener un String que represente al alumno siguiendo el ejemplo:
Ej. alumnos de grado “DNI; Nombre; Materias aprobadas: nombre, nota y fecha de c/u; Está graduado: …; Carrera”
Ej. alumnos de doctorado “DNI; Nombre; Materias aprobadas: nombre, nota y fecha de c/u; Está graduado: …; Título;
Universidad de Origen”
3- Realice un programa que instancie un alumno de cada tipo. Cargue información de materias aprobadas a cada
uno. Informe en consola el resultado del inciso c).*/
package alumnos;
public abstract class Alumno {
    private int dni;
    private String nombre;
    private Materias[] aprobadas;
    private int dimF;
    private int dimL;

    public Alumno(int dni, String nombre,int N) {
        this.setDni(dni);
        this.setNombre(nombre);
        this.aprobadas=new Materias[N];
        this.setDimF(N);
        this.setDimL(0);
    }
    /*a) Dada una materia aprobada, agregarla a las materias aprobadas del alumno.*/
    public boolean agregarMateriaAprobada(Materias materia){
        boolean aux=false;
        if(this.getDimL()<this.getDimF()){
            aux=true;
            this.getAprobadas()[this.getDimL()]=materia;
            this.setDimL(this.getDimL()+1);
        }
        return aux;
    }
    /*b) Determinar si el alumno está graduado, teniendo en cuenta que para ello deben tener un total de N materias
aprobadas y deben tener aprobada la materia “Tesis”.*/
    public boolean estaGraduado(){
        boolean aux=false;
        if(this.getDimL()==this.getDimF()){
            int i=0;
            while((i<this.getDimF())&&(aux==false)){
                if(this.getAprobadas()[i].esTesis()){
                    aux=true;
                }
                else{
                   i++;
                }
            }
        }
        return aux;
    }
    /*c) Obtener un String que represente al alumno siguiendo el ejemplo:
Ej. alumnos de grado “DNI; Nombre; Materias aprobadas: nombre, nota y fecha de c/u; Está graduado: …; Carrera”
Ej. alumnos de doctorado “DNI; Nombre; Materias aprobadas: nombre, nota y fecha de c/u; Está graduado: …; Título;
Universidad de Origen”*/
    @Override
    public String toString(){
        String aux="Dni: "+this.getDni()+";"+" Nombre: "+this.getNombre()+"\n Materia aprobadas: ";
        for(int i=0;i<this.getDimL();i++)
            aux+="\n "+this.getAprobadas()[i].toString();
        aux+="\n Esta graduado: "+this.estaGraduado();
        return aux;
    }

    public int getDni() {
        return dni;
    }

    public void setDni(int dni) {
        this.dni = dni;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    private Materias[] getAprobadas() {
        return aprobadas;
    }

    private void setAprobadas(Materias[] aprobadas) {
        this.aprobadas = aprobadas;
    }

    private int getDimF() {
        return dimF;
    }

    private void setDimF(int dimF) {
        this.dimF = dimF;
    }

    private int getDimL() {
        return dimL;
    }

    private void setDimL(int dimL) {
        this.dimL = dimL;
    }
    
}
