/*
Representar una Empresa. La empresa tiene nombre, una dirección, un Director ejecutivo y los Encargados de sus sucursales numeradas de la 1. N. 
Del Director se conoce el nombre, DNI, año de ingreso a la empresa, sueldo básico y monto destinado a viáticos 
Del Encargado de cada sucursal se conoce el nombre, DNI, año de ingreso a la empresa, sueldo básico y cantidad de empleados a cargo.
a) Genere las clases necesarias. Provea constructores para iniciarlas a partir de la información necesaria. En el caso de la Empresa debe considerar que se crea 
con nombre, dirección, un Director y N sucursales inicialmente sin encargados.
b) Implemente los métodos necesarios, en las clases que corresponda, para:
1. Asignar un Encargado a la sucursal X. Asuma que X está en rango de 1.N.
2 Retomar el sueldo a cobrar por los empleados (Encargados y Director). En ambos casos la empresa incorpora al sueldo básico una comisión del 10% si supera los 20 años de antigüedad. 
Además, el Encargado tiene un adicional del 1000 pesos por cada empleado a cargo El Director recibe el monto destinado a viáticos:
3. Retornar una representación String de Director y Encargado, con formato: "Nombre, DNI, sueldo a cobrar
4. Retomar un String que represente la empresa, que contenga: nombre, dirección, representación del Director y la representación de los Encargados junto a su número de sucursal. 
Indique si existe alguna sucursal sin Encargado.
c) Realice un programa que instancie una Empresa. Cargue Encargados en distintas sucursales. Luego, imprima la representación de la Empresa.
Intro
 */
package empresa;
public class Empresaaa {
    private String nombre;
    private String direccion;
    private Director ejecutivo;
    private Encargado[] encargados;
    private int dimF;

    public Empresaaa(String nombre, String direccion, Director ejecutivo,int N) {
        this.setNombre(nombre);
        this.setDireccion(direccion);
        this.setEjecutivo(ejecutivo);
        this.encargados=new Encargado[N];
        this.setDimF(N);
    }

    /*1. Asignar un Encargado a la sucursal X. Asuma que X está en rango de 1.N.*/
    public boolean asignarEncargado(Encargado encargado,int X){
      boolean aux=false;
      if(this.getEncargados()[(X-1)]==null){
          aux=true;
          this.getEncargados()[(X-1)]=encargado;
      }
      return aux;
    }
    /*4. Retomar un String que represente la empresa, que contenga: nombre, dirección, representación del Director y la representación de los Encargados junto a su número de sucursal. 
Indique si existe alguna sucursal sin Encargado.*/
    public String toString(){
        String aux="Empresa: "+this.getNombre()+" "+this.getDireccion()+"\n Director: "+this.getEjecutivo().toString()+"\n Encargados de las sucursales";
        for(int i=0;i<this.getDimF();i++){
            aux+="\n Sucursal "+(i+1)+": ";
            if(this.getEncargados()[i]!=null)
                aux+=this.getEncargados()[i].toString();
            else
                aux+="Esta sucursal no tiene encargados";
        }
        return aux;
    }
    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getDireccion() {
        return direccion;
    }

    public void setDireccion(String direccion) {
        this.direccion = direccion;
    }

    public Director getEjecutivo() {
        return ejecutivo;
    }

    public void setEjecutivo(Director ejecutivo) {
        this.ejecutivo = ejecutivo;
    }

    private Encargado[] getEncargados() {
        return encargados;
    }

    private void setEncargados(Encargado[] encargados) {
        this.encargados = encargados;
    }

    private int getDimF() {
        return dimF;
    }

    private void setDimF(int dimF) {
        this.dimF = dimF;
    }
    
    
    
}
