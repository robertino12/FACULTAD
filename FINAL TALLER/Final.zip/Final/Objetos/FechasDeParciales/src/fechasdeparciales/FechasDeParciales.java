/*Representar fechas de parcial tomadas por una cátedra. Una
fecha de parcial guarda información de las N
salas en las que se distribuyeron los alumnos. Cada sala 
almacena información de los alumnos que rindieron
en ella (como máximo M). De los alumnos registra: nombre, DNI
y nro. de tema asignado. - - 13.50

1- Genere las clases necesarias. Provea constructores para 
iniciar: las fechas de parcial para N salas y un
máximo de M alumnos por sala (inicialmente sin alumnos); los
alumnos a partir de DNI y nombre (inicialmente
con nro. de tema indefinido -1).

2- Implemente los métodos necesarios, en las clases que 
corresponda, para:

a. Agregar un alumno a la sala X de la fecha. Asuma que X es
válido y que hay lugar para el alumno.

b. Asignar un tema a todos los alumnos de la fecha, de la 
siguiente manera: a los alumnos de una misma
sala se le asignan temas al azar (entre 1 y M).

c. Obtener un String con la información de los alumnos 
(nombre, DNI) que rinden el tema T.

3- Realice un programa que instancie una fecha de parcial
para 2 salas y 4 alumnos por sala. Agregue
alumnos a la fecha, asigne temas a todos los alumnos y luego 
muestre la información obtenida del inciso c. */
package fechasdeparciales;
public class FechasDeParciales {
    public static void main(String[] args) {
        Fecha fecha=new Fecha(2,4);
        
        Alumno alumno1=new Alumno("Alejo",46434641);
        fecha.agregarAlumno(alumno1,1);
        
        Alumno alumno2=new Alumno("Mauro",11223344);
        fecha.agregarAlumno(alumno2,1);
        
        Alumno alumno3=new Alumno("Laureano",45485698);
        fecha.agregarAlumno(alumno3,1);
        
        Alumno alumno4=new Alumno("Juan",42563257);
        fecha.agregarAlumno(alumno4,1);
        
        Alumno alumno5=new Alumno("Morena",46589651);
        fecha.agregarAlumno(alumno5,2);
        
        Alumno alumno6=new Alumno("Pepa",01);      
        fecha.agregarAlumno(alumno6,2);
        
        Alumno alumno7=new Alumno("Nicolas",46324685);     
        fecha.agregarAlumno(alumno7,2);  
        
        Alumno alumno8=new Alumno("Beatriz",22326288);
        fecha.agregarAlumno(alumno8,2);
        
        fecha.asignarTemas(5);
        System.out.println(fecha.toString(6));
        
    }
    
}
