/*Representar fechas de parcial tomadas por una cátedra. Una
fecha de parcial guarda información de las N
salas en las que se distribuyeron los alumnos. Cada sala 
almacena información de los alumnos que rindieron
en ella (como máximo M). De los alumnos registra: nombre, DNI
y nro. de tema asignado. - - 13.50

1- Genere las clases necesarias. Provea constructores para 
iniciar: las fechas de parcial para N salas y un
máximo de M alumnos por sala (inicialmente sin alumnos); los
alumnos a partir de DNI y nombre (inicialmente
con nro. de tema indefinido -1).

2- Implemente los métodos necesarios, en las clases que 
corresponda, para:

a. Agregar un alumno a la sala X de la fecha. Asuma que X es
válido y que hay lugar para el alumno.

b. Asignar un tema a todos los alumnos de la fecha, de la 
siguiente manera: a los alumnos de una misma
sala se le asignan temas al azar (entre 1 y M).

c. Obtener un String con la información de los alumnos 
(nombre, DNI) que rinden el tema T.

3- Realice un programa que instancie una fecha de parcial
para 2 salas y 4 alumnos por sala. Agregue
alumnos a la fecha, asigne temas a todos los alumnos y luego 
muestre la información obtenida del inciso c. */
package fechasdeparciales;
  import PaqueteLectura.GeneradorAleatorio;
public class Sala {
    private Alumno[] alumnos;
    private int dimF;
    private int dimL;

    public Sala(int M) {
        this.alumnos=new Alumno[M];
        this.setDimF(M);
        this.setDimL(0);
    }
    public void agregarAlumno(Alumno alumno){
        this.getAlumnos()[this.getDimL()]=alumno;
        this.setDimL(this.getDimL()+1);
    }
    public void asignarTemas(int temas){
        GeneradorAleatorio.iniciar();
        for(int i=0;i<this.getDimL();i++){
            this.getAlumnos()[i].setTema(GeneradorAleatorio.generarInt(temas));
            
        }
    }
    public String toString(int T){
        String aux="";
        for(int i=0;i<this.getDimL();i++){
            if(this.getAlumnos()[i].getTema()==T){
                aux+="\n"+this.getAlumnos()[i].toString();
            }
        }
        return aux;
    }
    private Alumno[] getAlumnos() {
        return alumnos;
    }

    private void setAlumnos(Alumno[] alumnos) {
        this.alumnos = alumnos;
    }
    
    private int getDimF() {
        return dimF;
    }

    private void setDimF(int dimF) {
        this.dimF = dimF;
    }

    private int getDimL() {
        return dimL;
    }

    private void setDimL(int dimL) {
        this.dimL = dimL;
    }

}
