/*Un psicólogo necesita un sistema para organizar su agenda semanal. El sistema mantiene para c/u de los 5 días
de atención y c/u de los 6 turnos (horarios) del día, la información del paciente que tomó el turno. De los
pacientes guarda: nombre, si tiene obra social y costo a abonar por la sesión.
a) Genere las clases necesarias. Implemente constructores para iniciar: el sistema sin pacientes; los pacientes
a partir de toda su información.
b) Lea atentamente y luego implemente métodos que permitan:
- Agendar al paciente P en un día D y turno T. Asuma que el turno está libre. D y T son válidos.
- Dado el nombre de un paciente, liberar todos sus turnos.
- Dado un día D y el nombre de un paciente, devolver si el paciente tiene agendado un turno ese día. Asuma
que D es válido.
c) Realice un programa que instancie el sistema. Cargue varios pacientes al sistema. Libere turnos agendados.
Para finalizar, imprima el resultado del inciso b.iii*/
package psicologo;
public class Agenda {
    private Paciente[][] matriz;
    private int dimF;
    private int dimC;

    public Agenda() {
        this.matriz=new Paciente[6][5];
        this.setDimF(6);
        this.setDimC(5);
    }
    private int getDimF() {
        return dimF;
    }

    private void setDimF(int dimF) {
        this.dimF = dimF;
    }

    private int getDimC() {
        return dimC;
    }

    private void setDimC(int dimL) {
        this.dimC = dimL;
    }

    
    private Paciente[][] getMatriz() {
        return matriz;
    }

    private void setMatriz(Paciente[][] Agenda) {
        this.matriz = Agenda;
    }
    public void agendarPaciente(Paciente P,int D,int T){
        this.getMatriz()[T-1][D-1]=P;
    }
    
    public int liberarTurnos(String nombre){
        int cantLib=0;
        for(int i=0;i<this.getDimC();i++){
          for(int j=0;j<this.getDimF();j++){
              if(this.getMatriz()[j][i]!=null){
                if(this.getMatriz()[j][i].esEl(nombre)){
                  this.getMatriz()[j][i]=null;
                  cantLib++;
                }
              }
          }
        }
        return cantLib;
    }
    /*- Dado un día D y el nombre de un paciente, devolver si el paciente tiene agendado un turno ese día. Asuma
que D es válido.*/
    public boolean tieneTurno(String nombre,int dia){
        boolean aux=false;
        int j=0;
        while((j<this.getDimF())&&(aux==false)){
            if(this.getMatriz()[j][dia-1]!=null){
                if(this.getMatriz()[j][dia-1].esEl(nombre)){
                    aux=true;
                }
            }
            j++;
        }
        return aux;
    }
}
