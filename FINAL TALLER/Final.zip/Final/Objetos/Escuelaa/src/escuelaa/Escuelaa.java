/*Un curso tiene año de cursada, y guarda la información de sus alumnos (como maximo N alumnos). 
De cada alumno se conoce: DNI, nombre, asistencias y cantidad de autoevaluaciones aprobadas Un curso puede ser a distancia o presencial. 
Los cursos a distancia llevan el link a la sala virtual y los cursos presenciales lleevan el número de aula. 
1- Genere las clases necesarias. Provea constructores para iniciar los cursos con un año de cursada, un máximo de alumnos N. 
Los cursos se crean sin alumnos inscriptos. Un alumno se crea con 0 asistencia y 0 autoevaluaciones aprobadas 
2- Implemente los métodos necesarios, en las clases que corresponda, para: 
a) agregarAlumno: Agregar un alumno a un curso. El método debe retornar true si pudo agregar al alumno y false en caso contrario. 
b) incrementarAsistencia: Dado un DNI, incrementar la asistencia del alumno con dicho DNI 
c) aprobarAutoevaluación: Dado un DNI, incrementar la cantidad de autoevaluaciones aprobadas del alumno con dicho DNI 
d) puedeRendir. Recibe un alumno y retorna si puede rendir o na. Si el curso es a distancia, pueden rendir el examen los alumnos que cumplen con tener 3 autoevaluaciones y 
al menos una asistencia. Si el curso es presencial, pueden rendir el examen los alumnos que tienen al menos 3 asistencias, 
e) cantidad De Alumnos QuePueden Rendir: Retorna la cantidad de alumnos en condiciones de rendir. 
3- Realice un programa que instancie un curso presencial y un curso a distancia. Agregue alumnos a cada curso. Incremente la asistencia y autoevaluaciones de los alumnos. 
Imprima la cantidad de alumnos en condiciones de rendir en cada curso.*/
package escuelaa;
public class Escuelaa {
    public static void main(String[] args) {
        Digital digital=new Digital("www.SanSimon.com",6,5);
        
        Alumno alumno1=new Alumno(111,"Alejo");
        System.out.println(digital.agregarAlumno(alumno1));
        System.out.println(digital.incrementarAutoevaluciones(111,3));
        System.out.println(digital.incrementarAsistencia(111,1));
        
        Alumno alumno2=new Alumno(222,"Juan");
        System.out.println(digital.agregarAlumno(alumno2));
        System.out.println(digital.incrementarAutoevaluciones(222,9));
        System.out.println(digital.incrementarAsistencia(222,5));
        
        Alumno alumno3=new Alumno(333,"Lionel");
        System.out.println(digital.agregarAlumno(alumno3));
        System.out.println(digital.incrementarAutoevaluciones(333,15));
        System.out.println(digital.incrementarAsistencia(333,1));
        
        Alumno alumno4=new Alumno(444,"Mario");
        System.out.println(digital.agregarAlumno(alumno4));
        System.out.println(digital.incrementarAutoevaluciones(444,3));
        System.out.println(digital.incrementarAsistencia(444,1));
        
        Alumno alumno5=new Alumno(555,"Pepa");
        System.out.println(digital.agregarAlumno(alumno5));
        System.out.println(digital.incrementarAutoevaluciones(555,3));
        System.out.println(digital.incrementarAsistencia(555,1));
        
        Alumno alumno6=new Alumno(666,"Mateo");
        System.out.println(digital.agregarAlumno(alumno6));
        System.out.println(digital.incrementarAutoevaluciones(666,3));
        System.out.println(digital.incrementarAsistencia(777,1));
        
        System.out.println(digital.cantidadDeAlumnosQuePuedenRendir());
        
        Presencial presencial=new Presencial(1,6,4);
        
        Alumno alumnoP1=new Alumno(112,"Alejandro");
        System.out.println(presencial.agregarAlumno(alumnoP1));
        System.out.println(presencial.incrementarAutoevaluciones(112,5));
        System.out.println(presencial.incrementarAsistencia(112,3));
        
        Alumno alumnoP2=new Alumno(113,"Mariano");
        System.out.println(presencial.agregarAlumno(alumnoP2));
        System.out.println(presencial.incrementarAutoevaluciones(113,0));
        System.out.println(presencial.incrementarAsistencia(113,1));
        
        Alumno alumnoP3=new Alumno(114,"Maria");
        System.out.println(presencial.agregarAlumno(alumnoP3));
        System.out.println(presencial.incrementarAutoevaluciones(114,4));
        System.out.println(presencial.incrementarAsistencia(117,2));
        
        Alumno alumnoP4=new Alumno(115,"Juana");
        System.out.println(presencial.agregarAlumno(alumnoP4));
        System.out.println(presencial.incrementarAutoevaluciones(115,5));
        System.out.println(presencial.incrementarAsistencia(115,15));
        
        Alumno alumnoP5=new Alumno(116,"Luna");
        System.out.println(presencial.agregarAlumno(alumnoP5));
        System.out.println(presencial.incrementarAutoevaluciones(116,5));
        System.out.println(presencial.incrementarAsistencia(116,19));
        
        System.out.println(presencial.cantidadDeAlumnosQuePuedenRendir());
    }
}
