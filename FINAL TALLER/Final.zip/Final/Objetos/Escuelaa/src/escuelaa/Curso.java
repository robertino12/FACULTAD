/*Un curso tiene año de cursada, y guarda la información de sus alumnos (como maximo N alumnos). 
De cada alumno se conoce: DNI, nombre, asistencias y cantidad de autoevaluaciones aprobadas Un curso puede ser a distancia o presencial. 
Los cursos a distancia llevan el link a la sala virtual y los cursos presenciales lleevan el número de aula. 
1- Genere las clases necesarias. Provea constructores para iniciar los cursos con un año de cursada, un máximo de alumnos N. 
Los cursos se crean sin alumnos inscriptos. Un alumno se crea con 0 asistencia y 0 autoevaluaciones aprobadas 
2- Implemente los métodos necesarios, en las clases que corresponda, para: 
a) agregarAlumno: Agregar un alumno a un curso. El método debe retornar true si pudo agregar al alumno y false en caso contrario. 
b) incrementarAsistencia: Dado un DNI, incrementar la asistencia del alumno con dicho DNI 
c) aprobarAutoevaluación: Dado un DNI, incrementar la cantidad de autoevaluaciones aprobadas del alumno con dicho DNI 
d) puedeRendir. Recibe un alumno y retorna si puede rendir o na. Si el curso es a distancia, pueden rendir el examen los alumnos que cumplen con tener 3 autoevaluaciones y 
al menos una asistencia. Si el curso es presencial, pueden rendir el examen los alumnos que tienen al menos 3 asistencias, 
e) cantidad De Alumnos QuePueden Rendir: Retorna la cantidad de alumnos en condiciones de rendir. 
3- Realice un programa que instancie un curso presencial y un curso a distancia. Agregue alumnos a cada curso. Incremente la asistencia y autoevaluaciones de los alumnos. 
Imprima la cantidad de alumnos en condiciones de rendir en cada curso.*/
package escuelaa;
public abstract class Curso {
    private int año;
    private Alumno[] vector;
    private int dimF;
    private int dimL;

    public Curso(int año,int N) {
        this.setAño(año);
        this.vector=new Alumno[N];
        this.setDimF(N);
        this.setDimL(0);
    }
    /*a) agregarAlumno: Agregar un alumno a un curso. El método debe retornar true si pudo agregar al alumno y false en caso contrario.*/
    public boolean agregarAlumno(Alumno alumno){
        boolean aux=false;
        if(this.getDimL()<this.getDimF()){
            aux=true;
            this.getVector()[this.getDimL()]=alumno;
            this.setDimL(this.getDimL()+1);
        }
        return aux;
    }
    public Alumno buscarAlumno(int dni){
        Alumno aux=null;
        int i=0;
        while((i<this.getDimL())&&(aux==null)){
            if(this.getVector()[i].getDni()==dni){
                aux=this.getVector()[i];
            }
            else
              i++;
        }
        return aux;
    }
    /*b) incrementarAsistencia: Dado un DNI, incrementar la asistencia del alumno con dicho DNI */
    public boolean incrementarAsistencia(int dni,int asistencias){
        boolean aux=false;
        Alumno alumno=this.buscarAlumno(dni);
        if(alumno!=null){
            aux=true;
            alumno.incrementarAsistencia(asistencias);
        }
        return aux;
    }
    /*c) aprobarAutoevaluación: Dado un DNI, incrementar la cantidad de autoevaluaciones aprobadas del alumno con dicho DNI */
    public boolean incrementarAutoevaluciones (int dni,int autoevaluaciones){
        boolean aux=false;
        Alumno alumno=this.buscarAlumno(dni);
        if(alumno!=null){
            aux=true;
            alumno.incrementarAutoevaluacion(autoevaluaciones);
        }
        return aux;
    }
    /*e) cantidad De Alumnos QuePueden Rendir: Retorna la cantidad de alumnos en condiciones de rendir.*/
    public int cantidadDeAlumnosQuePuedenRendir(){
        int aux=0;
        for(int i=0;i<this.getDimL();i++){
            boolean puede=this.puedeRendir(this.getVector()[i]);
            if(puede){
                aux++;
            }
        }
        return aux;
    }
    
    public int getAño() {
        return año;
    }

    public void setAño(int año) {
        this.año = año;
    }

    private Alumno[] getVector() {
        return vector;
    }

    private void setVector(Alumno[] vector) {
        this.vector = vector;
    }

    private int getDimF() {
        return dimF;
    }

    private void setDimF(int dimF) {
        this.dimF = dimF;
    }

    private int getDimL() {
        return dimL;
    }

    private void setDimL(int dimL) {
        this.dimL = dimL;
    }
    /*d) puedeRendir. Recibe un alumno y retorna si puede rendir o na. Si el curso es a distancia, pueden rendir el examen los alumnos que cumplen con tener 3 autoevaluaciones y 
    al menos una asistencia. Si el curso es presencial, pueden rendir el examen los alumnos que tienen al menos 3 asistencias,*/
    public abstract boolean puedeRendir(Alumno alumno);

}
