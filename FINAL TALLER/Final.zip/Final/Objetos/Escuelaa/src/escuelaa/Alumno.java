/*Un curso tiene año de cursada, y guarda la información de sus alumnos (como maximo N alumnos). 
De cada alumno se conoce: DNI, nombre, asistencias y cantidad de autoevaluaciones aprobadas Un curso puede ser a distancia o presencial. 
Los cursos a distancia llevan el link a la sala virtual y los cursos presenciales lleevan el número de aula. 
1- Genere las clases necesarias. Provea constructores para iniciar los cursos con un año de cursada, un máximo de alumnos N. 
Los cursos se crean sin alumnos inscriptos. Un alumno se crea con 0 asistencia y 0 autoevaluaciones aprobadas 
2- Implemente los métodos necesarios, en las clases que corresponda, para: 
a) agregarAlumno: Agregar un alumno a un curso. El método debe retornar true si pudo agregar al alumno y false en caso contrario. 
b) incrementarAsistencia: Dado un DNI, incrementar la asistencia del alumno con dicho DNI 
c) aprobarAutoevaluación: Dado un DNI, incrementar la cantidad de autoevaluaciones aprobadas del alumno con dicho DNI 
d) puedeRendir. Recibe un alumno y retorna si puede rendir o na. Si el curso es a distancia, pueden rendir el examen los alumnos que cumplen con tener 3 autoevaluaciones y 
al menos una asistencia. Si el curso es presencial, pueden rendir el examen los alumnos que tienen al menos 3 asistencias, 
e) cantidad De Alumnos QuePueden Rendir: Retorna la cantidad de alumnos en condiciones de rendir. 
3- Realice un programa que instancie un curso presencial y un curso a distancia. Agregue alumnos a cada curso. Incremente la asistencia y autoevaluaciones de los alumnos. 
Imprima la cantidad de alumnos en condiciones de rendir en cada curso.*/
package escuelaa;
public class Alumno {
    private int dni;
    private String nombre;
    private int asistencias;
    private int autoevaluaciones;

    public Alumno(int dni, String nombre) {
        this.setDni(dni);
        this.setNombre(nombre);
        this.setAsistencias(0);
        this.setAutoevaluaciones(0);
    }

    public int getDni() {
        return dni;
    }

    public void setDni(int dni) {
        this.dni = dni;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public int getAsistencias() {
        return asistencias;
    }

    public void setAsistencias(int asistencias) {
        this.asistencias = asistencias;
    }

    public int getAutoevaluaciones() {
        return autoevaluaciones;
    }

    public void setAutoevaluaciones(int autoevaluaciones) {
        this.autoevaluaciones = autoevaluaciones;
    }
    public void incrementarAsistencia(int asistencias){
        this.setAsistencias(this.getAsistencias()+asistencias);
    }
    public void incrementarAutoevaluacion(int autoevaluaciones){
      this.setAutoevaluaciones(this.getAutoevaluaciones()+autoevaluaciones);
    }
}
