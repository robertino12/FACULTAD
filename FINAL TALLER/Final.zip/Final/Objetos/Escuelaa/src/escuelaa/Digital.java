/*Un curso tiene año de cursada, y guarda la información de sus alumnos (como maximo N alumnos). 
De cada alumno se conoce: DNI, nombre, asistencias y cantidad de autoevaluaciones aprobadas Un curso puede ser a distancia o presencial. 
Los cursos a distancia llevan el link a la sala virtual y los cursos presenciales lleevan el número de aula. 
1- Genere las clases necesarias. Provea constructores para iniciar los cursos con un año de cursada, un máximo de alumnos N. 
Los cursos se crean sin alumnos inscriptos. Un alumno se crea con 0 asistencia y 0 autoevaluaciones aprobadas 
2- Implemente los métodos necesarios, en las clases que corresponda, para: 
a) agregarAlumno: Agregar un alumno a un curso. El método debe retornar true si pudo agregar al alumno y false en caso contrario. 
b) incrementarAsistencia: Dado un DNI, incrementar la asistencia del alumno con dicho DNI 
c) aprobarAutoevaluación: Dado un DNI, incrementar la cantidad de autoevaluaciones aprobadas del alumno con dicho DNI 
d) puedeRendir. Recibe un alumno y retorna si puede rendir o na. Si el curso es a distancia, pueden rendir el examen los alumnos que cumplen con tener 3 autoevaluaciones y 
al menos una asistencia. Si el curso es presencial, pueden rendir el examen los alumnos que tienen al menos 3 asistencias, 
e) cantidad De Alumnos QuePueden Rendir: Retorna la cantidad de alumnos en condiciones de rendir. 
3- Realice un programa que instancie un curso presencial y un curso a distancia. Agregue alumnos a cada curso. Incremente la asistencia y autoevaluaciones de los alumnos. 
Imprima la cantidad de alumnos en condiciones de rendir en cada curso.*/
package escuelaa;
public class Digital extends Curso{
    private String link;

    public Digital(String link, int año, int N) {
        super(año, N);
        this.setLink(link);
    }
    public String getLink() {
        return link;
    }

    public void setLink(String link) {
        this.link = link;
    }
    /*d) puedeRendir. Recibe un alumno y retorna si puede rendir o na. Si el curso es a distancia, pueden rendir el examen los alumnos que cumplen con tener 3 autoevaluaciones y 
    al menos una asistencia. Si el curso es presencial, pueden rendir el examen los alumnos que tienen al menos 3 asistencias,*/
    @Override
    public boolean puedeRendir(Alumno alumno){
        boolean aux=false;
        if((alumno.getAutoevaluaciones()>=3)&&(alumno.getAsistencias()>=1)){
          aux=true;
        }   
        return aux;
        }
}

