/*Representar alumnos de una facultad. De cualquier alumno se conoce: DNI, nombre y sus materias aprobadas (como
máximo N). De las materias aprobadas se registra: nombre, nota y fecha. Además de los alumnos de grado se tiene la
carrera, mientras que de los alumnos de doctorado el título universitario y universidad de origen.
1- Genere las clases necesarias. Provea constructores para iniciar las materias aprobadas y los alumnos a partir de la
información necesaria (estos para un máximo de N materias aprobadas y sin materias aprobadas inicialmente).
2- Implemente los métodos necesarios, en las clases que corresponda, para:
a) Dada una materia aprobada, agregarla a las materias aprobadas del alumno.
b) Determinar si el alumno está graduado, teniendo en cuenta que para ello deben tener un total de N materias
aprobadas y deben tener aprobada la materia “Tesis”.
c) Obtener un String que represente al alumno siguiendo el ejemplo:
Ej. alumnos de grado “DNI; Nombre; Materias aprobadas: nombre, nota y fecha de c/u; Está graduado: …; Carrera”
Ej. alumnos de doctorado “DNI; Nombre; Materias aprobadas: nombre, nota y fecha de c/u; Está graduado: …; Título;
Universidad de Origen”
3- Realice un programa que instancie un alumno de cada tipo. Cargue información de materias aprobadas a cada
uno. Informe en consola el resultado del inciso c).*/
package alumno2.pkg0;
public class Alumno20 {
    public static void main(String[] args) {
        Doctorado doctorado=new Doctorado("Licenciatura en Sistemas","UNLP",46434641,"Alejo Garcia Aragon",3);
        Materia materia1=new Materia("Taller de Programacion",10,"20/02/2024");
        System.out.println(doctorado.agregarMateria(materia1));
        Materia materia2=new Materia("Mate 2",8,"16/02/2024");
        System.out.println(doctorado.agregarMateria(materia2));
        Materia materia3=new Materia("Tesis",7,"15/06/2023");
        System.out.println(doctorado.agregarMateria(materia3));
        System.out.println(doctorado.toString());
        
        Grado grado=new Grado("Martillero",22326288,"Lautaro Garcia Souza",2);
        Materia materia4=new Materia("Terrenos",5,"01/02/2023");
        System.out.println(grado.agregarMateria(materia4));
        Materia materia5=new Materia("Tesis",8,"16/02/2024");
        System.out.println(grado.agregarMateria(materia5));
        System.out.println(grado.toString());
    }
    
    
}
