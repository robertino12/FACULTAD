/*1) Queremos representar estanterías de libros.
Una estantería mantiene sus libros organizados en N estantes cada uno con lugar para M libros.
Un libro posee título, nombre de su primer autor y peso.
a) Implemente las clases de su modelo, con sus atributos y getters/setters adecuados.
Provea constructores para iniciar: los libros a partir de toda su información; la estantería para N estantes y lugar para M libros por estante (inicialmente no debe tener libros cargados).
b) Implemente los siguientes métodos:
- almacenarLibro: recibe un libro, un nro. de estante y nro. de lugar válidos y guarda al libro en la estantería. Asuma que dicho lugar está disponible.
- sacarLibro: recibe el título de un libro, y saca y devuelve el libro con ese título, quedando su lugar disponible. Tenga en cuenta que el libro puede no existir.
- calcular: calcula y devuelve el libro más pesado de la estantería.
2) Realice un programa que instancie una estantería para 5 estantes y 3 libros por estante.
Almacene 7 libros en la estantería. A partir de la estantería: saque un libro e informe su representación String; luego, informe el título del libro más pesado.*/
package estanterias;
public class Estanteria {
    private Libro[][] estanteria;
    private int dimF;
    private int dimC;

    public Estanteria(int estanterias, int lugares) {
        this.estanteria=new Libro[estanterias][lugares];
        this.setDimC(estanterias);
        this.setDimF(lugares);
    }

    private Libro[][] getEstanteria() {
        return estanteria;
    }

    private void setEstanteria(Libro[][] estanteria) {
        this.estanteria = estanteria;
    }

    private int getDimF() {
        return dimF;
    }

    private void setDimF(int dimF) {
        this.dimF = dimF;
    }

    private int getDimC() {
        return dimC;
    }

    private void setDimC(int dimC) {
        this.dimC = dimC;
    }
    /*- almacenarLibro: recibe un libro, un nro. de estante y nro. de lugar válidos y guarda al libro en la estantería. Asuma que dicho lugar está disponible.*/
    public boolean almacenarLibro(Libro libro,int estante,int lugar){
        boolean aux=false;
        if((estante<=this.getDimC())&&(lugar<=this.getDimF())){
            aux=true;
            this.getEstanteria()[estante-1][lugar-1]=libro;
        }
        return aux;
    }
    /*- sacarLibro: recibe el título de un libro, y saca y devuelve el libro con ese título, quedando su lugar disponible. Tenga en cuenta que el libro puede no existir.*/
    public Libro sacarLibro(String titulo){
        Libro aux=null;
        boolean encontre=false;
        int i=0;
        while((i<this.getDimC())&&(encontre==false)){
          int j=0;
          while((j<this.getDimF())&&(encontre==false)){
              if(this.getEstanteria()[i][j]!=null){
                if(this.getEstanteria()[i][j].esElLibro(titulo)){
                  encontre=true;
                  aux=this.getEstanteria()[i][j];
                  this.getEstanteria()[i][j]=null;
                }   
              }
              j++;
          }
          i++;
        }
        return aux;
    }
    /*- calcular: calcula y devuelve el libro más pesado de la estantería.*/
    public Libro calcular(){
        Libro libro=null;
        double max=0;
        for(int i=0;i<this.getDimC();i++){
            for(int j=0;j<this.getDimF();j++){
                if(this.getEstanteria()[i][j]!=null){
                    if(this.getEstanteria()[i][j].getPeso()>max){
                        libro=this.getEstanteria()[i][j];
                        max=this.getEstanteria()[i][j].getPeso();
                    }
                    
                }
            }
        }
        return libro;
    }
}
