/*1) Queremos representar estanterías de libros.
Una estantería mantiene sus libros organizados en N estantes cada uno con lugar para M libros.
Un libro posee título, nombre de su primer autor y peso.
a) Implemente las clases de su modelo, con sus atributos y getters/setters adecuados.
Provea constructores para iniciar: los libros a partir de toda su información; la estantería para N estantes y lugar para M libros por estante (inicialmente no debe tener libros cargados).
b) Implemente los siguientes métodos:
- almacenarLibro: recibe un libro, un nro. de estante y nro. de lugar válidos y guarda al libro en la estantería. Asuma que dicho lugar está disponible.
- sacarLibro: recibe el título de un libro, y saca y devuelve el libro con ese título, quedando su lugar disponible. Tenga en cuenta que el libro puede no existir.
- calcular: calcula y devuelve el libro más pesado de la estantería.
2) Realice un programa que instancie una estantería para 5 estantes y 3 libros por estante.
Almacene 7 libros en la estantería. A partir de la estantería: saque un libro e informe su representación String; luego, informe el título del libro más pesado.
 */
package estanterias;
public class Libro {
    private String titulo;
    private String autor;
    private double peso;

    public Libro(String titulo, String autor, double peso) {
        this.setTitulo(titulo);
        this.setAutor(autor);
        this.setPeso(peso);
    }

    public String getTitulo() {
        return titulo;
    }

    public void setTitulo(String titulo) {
        this.titulo = titulo;
    }

    public String getAutor() {
        return autor;
    }

    public void setAutor(String autor) {
        this.autor = autor;
    }

    public double getPeso() {
        return peso;
    }

    public void setPeso(double peso) {
        this.peso = peso;
    }  
    public boolean esElLibro(String titulo){
        boolean aux=false;
        if(this.getTitulo().equals(titulo)){
            aux=true;
        }
        return aux;
    }

    @Override
    public String toString() {
        return "Libro{"+"titulo "+this.getTitulo()+ ", autor "+ this.getAutor()+", peso "+this.getPeso()+'}';
    }

}
