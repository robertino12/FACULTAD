/*Una escuela de canto quiere organizar un concurso entre sus
estudiantes y necesita un sistema que le permita administra
las canciones a interpretar, organizadas por categoria; ademas
de conocer a los estudiantes que participan en el concurso De
las canciones se desea conocer su nombre, su compositor, su 
identificador (un numero único para cada canción), el 
estudiante que mizo la mejor interpretacion de la cancion (el
"ganador" de la canción) y el puntaje otorgado por lo
profesores. De los estudiantes se desea conocer su nombre, 
apellido y dni. - - - 12.50
El concurso de canto debería crearse conociendo la cantidad 
de categorias y la cantidad máxima de canciones por categoría
(la misma cantidad para todas las categorías). 
Las canciones 
deberian crearse con su identificador único nombre, compositor
y con el puntaje en cero. 
Los estudiantes deberian crearse con
todos sus atributos. implemente las clases, atributos y metodos 
necesarios para poder realizar: 
-Agregar una nueva cancion al concurso en una determinada 
categoria suponga que en dicha cat hay lugar para la cancion)
-interpretar una cancion. Se recibe el identificador de la 
cancion (que seguro existe), el estudiante que hace la
interpretacion y el puntaje otorgado por los protesores. Si el
puntaje otorgado es más grande que el puntaje actual de la 
canción, se actualiza el puntaje y el estudiante "ganador" 
para la canción.
-Conocer el estudiante "ganador" de una canción, dado el 
identificador de la canción (que seguro existe) devuelve el 
estudiante que hava obtenido el puntaje mas alto, o null si 
ningún estudiante interpretó la canción
-Conocer la canción con el puntale más grande en una
determinada categoria.
Implemente un programa principal que realice lo siguiente:
-Cree un concurso de tres categorías y cinco canciones como
maximo para cada categoria 
-Agregue cinco nuevas canciones.

-Vaya leyendo de teclado nombre, apellido y ni del estudiante,
junto con el identificador de la canción y puntaje otorgado, 
hasta ingresar un identificador igual a cero. "Simule" las
interpretaciones de las canciones por los estudiantes 
invocando al metodo correspondiente.

-Lea un identificador de canción por teclado (que seguro 
existe) e informe el nombre, apellido y dni del estudiante
"ganador". O10 que la canción puede no haber sido interpretada
por ningún estudiante, en cuyo caso se deberia informar 
"Nadie".

-El nombre y compositor de la canción mejor interpretada 
para cada una de las cinco categorías. */
package concursodecanto;
public class ConcursoDeCanto {
    public static void main(String[] args) {
        Concurso concurso=new Concurso(3,5);
        
        Cancion cancion1=new Cancion("Al sol","Milo J",1);
        concurso.agregarCancion(cancion1, 1);
        
        Cancion cancion2=new Cancion("Rincon","Milo J",2);
        concurso.agregarCancion(cancion2, 1);
        
        Cancion cancion3=new Cancion("Penas de Antaño","Bizarap",3);
        concurso.agregarCancion(cancion3, 1);
        
        Cancion cancion4=new Cancion("Una foto","El mesita",4);
        concurso.agregarCancion(cancion4, 3);
        
        Cancion cancion5=new Cancion("Bizarap Sesion Young Miko","Bizarap",5);
        concurso.agregarCancion(cancion5, 2);
        
        Estudiante estudiante1=new Estudiante("Alejo","Garcia Aragon",46434641);
        concurso.interpretarCancion(1,estudiante1,9);
        
        Estudiante estudiante2=new Estudiante("Nicolas","Caraccio",46485441);
        concurso.interpretarCancion(5,estudiante2,1);
        
        Estudiante estudiante3=new Estudiante("Bautista","Giogia",45444641);
        concurso.interpretarCancion(5,estudiante3,5);
        
        Estudiante estudiante4=new Estudiante("Uma","Brown",46789891);
        concurso.interpretarCancion(5,estudiante4,3);
        
        Estudiante estudiante5=new Estudiante("Beatriz","Aragon",22326288);
        concurso.interpretarCancion(4,estudiante5,2);
        
        Estudiante estudiante6=new Estudiante("Agustin","Casetti",46895658);
        concurso.interpretarCancion(4,estudiante6,1);
        
        Estudiante estudiante7=new Estudiante("Tomas","Lucentini",38596587);
        concurso.interpretarCancion(3,estudiante7,10);
        
        Estudiante estudiante8=new Estudiante("Pedro","Griffo",46854789);
        concurso.interpretarCancion(3,estudiante8,9);
        
        Estudiante estudiante9=new Estudiante("Lionel","Messi",34598690);
        concurso.interpretarCancion(2,estudiante9,7);
        
        Estudiante estudiante10=new Estudiante("Nicolas","Perez",39589652);
        concurso.interpretarCancion(2,estudiante10,4);
        
        Estudiante estudiante11=new Estudiante("Robertino","Lucentini",46435891);
        concurso.interpretarCancion(1,estudiante11,6);
        
        System.out.println("1 "+concurso.mayorPuntajeDeCategoria(1).getGanador().toString());
        System.out.println("2 "+concurso.mayorPuntajeDeCategoria(2).getGanador().toString());
        System.out.println("3 "+concurso.mayorPuntajeDeCategoria(3).getGanador().toString());
        
        cancion1 = concurso.mayorPuntajeDeCategoria(1);
        System.out.println("1 "+cancion1.getCompositor()+" "+cancion1.getNombre());
        cancion2 = concurso.mayorPuntajeDeCategoria(2);
        System.out.println("2 "+cancion2.getCompositor()+" "+cancion2.getNombre());
        cancion3 = concurso.mayorPuntajeDeCategoria(3);
        System.out.println("3 "+cancion3.getCompositor()+" "+cancion3.getNombre());
    
    }
}
