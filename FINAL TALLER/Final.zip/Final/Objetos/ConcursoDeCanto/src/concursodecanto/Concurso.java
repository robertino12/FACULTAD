/*Una escuela de canto quiere organizar un concurso entre sus
estudiantes y necesita un sistema que le permita administra
las canciones a interpretar, organizadas por categoria; ademas
de conocer a los estudiantes que participan en el concurso De
las canciones se desea conocer su nombre, su compositor, su 
identificador (un numero único para cada canción), el 
estudiante que mizo la mejor interpretacion de la cancion (el
"ganador" de la canción) y el puntaje otorgado por lo
profesores. De los estudiantes se desea conocer su nombre, 
apellido y dni. - - - 12.50
El concurso de canto debería crearse conociendo la cantidad 
de categorias y la cantidad máxima de canciones por categoría
(la misma cantidad para todas las categorías). 
Las canciones 
deberian crearse con su identificador único nombre, compositor
y con el puntaje en cero. 
Los estudiantes deberian crearse con
todos sus atributos. implemente las clases, atributos y metodos 
necesarios para poder realizar: 
-Agregar una nueva cancion al concurso en una determinada 
categoria suponga que en dicha cat hay lugar para la cancion)
-interpretar una cancion. Se recibe el identificador de la 
cancion (que seguro existe), el estudiante que hace la
interpretacion y el puntaje otorgado por los protesores. Si el
puntaje otorgado es más grande que el puntaje actual de la 
canción, se actualiza el puntaje y el estudiante "ganador" 
para la canción.
-Conocer el estudiante "ganador" de una canción, dado el 
identificador de la canción (que seguro existe) devuelve el 
estudiante que hava obtenido el puntaje mas alto, o null si 
ningún estudiante interpretó la canción
-Conocer la canción con el puntale más grande en una
determinada categoria.
Implemente un programa principal que realice lo siguiente:
-Cree un concurso de tres categorías y cinco canciones como
maximo para cada categoria 
-Agregue cinco nuevas canciones.

-Vaya leyendo de teclado nombre, apellido y ni del estudiante,
junto con el identificador de la canción y puntaje otorgado, 
hasta ingresar un identificador igual a cero. "Simule" las
interpretaciones de las canciones por los estudiantes 
invocando al metodo correspondiente.

-Lea un identificador de canción por teclado (que seguro 
existe) e informe el nombre, apellido y dni del estudiante
"ganador". Oj0 que la canción puede no haber sido interpretada
por ningún estudiante, en cuyo caso se deberia informar 
"Nadie".

-El nombre y compositor de la canción mejor interpretada 
para cada una de las cinco categorías. */
package concursodecanto;
public class Concurso {
    private Cancion[][] categorias;
    private int[]dimLF;
    private int dimFC;
    private int dimfF;
    
    /*El concurso de canto debería crearse conociendo la cantidad 
de categorias y la cantidad máxima de canciones por categoría
(la misma cantidad para todas las categorías). 
Las canciones */

    public Concurso(int cantCategorias,int maxCanciones) {
        this.categorias=new Cancion[cantCategorias][maxCanciones];
        this.dimLF=new int[cantCategorias];
        for(int i=0;i<cantCategorias;i++)
          this.getDimL()[i]=0;
        this.setDimFC(cantCategorias);
        this.setDimfF(maxCanciones);
    }
    /*-Agregar una nueva cancion al concurso en una determinada 
categoria suponga que en dicha cat hay lugar para la cancion)*/
    public boolean agregarCancion(Cancion cancion,int categoria){
        boolean aux=false;
        if(categoria<=this.getDimFC()){
            this.getCategorias()[categoria-1][this.getDimL()[categoria-1]]=cancion;
            this.getDimL()[categoria-1]++;
            aux=true;
        }
        return aux;
    }
/*-interpretar una cancion. Se recibe el identificador de la 
cancion (que seguro existe), el estudiante que hace la
interpretacion y el puntaje otorgado por los protesores. Si el
puntaje otorgado es más grande que el puntaje actual de la 
canción, se actualiza el puntaje y el estudiante "ganador" 
para la canción.*/
    public void interpretarCancion(int identificador,Estudiante estudiante,double puntaje){
        boolean encontre=false;
        int i=0;
        while((i<this.getDimFC())&&(encontre==false)){
            int j=0;
            while((j<this.getDimL()[i])&&(encontre==false)){
                if(this.getCategorias()[i][j].getIdentificador()==identificador){
                    encontre=true;
                    this.getCategorias()[i][j].esMayorElPuntaje(estudiante,puntaje);
                }
                else
                  j++;
            }
            i++;
        }
    }
    /*-Conocer el estudiante "ganador" de una canción, dado el 
identificador de la canción (que seguro existe) devuelve el 
estudiante que hava obtenido el puntaje mas alto, o null si 
ningún estudiante interpretó la canción*/
    public Estudiante conocerEstudiante(int identificador){
      boolean encontre=false;
      Estudiante aux=null;
      int i=0;
      while((i<this.getDimFC())&&(encontre=false)){
          int j=0;
          while((j<this.getDimL()[i])&&(encontre=false)){
              if(this.getCategorias()[i][j].getIdentificador()==identificador){
                  encontre=true;
                  aux=this.getCategorias()[i][j].getGanador();
              }
              else
                j++;
          }
          i++;
      }
      return aux;
    }
    /*-Conocer la canción con el puntale más grande en una
determinada categoria.*/
    public Cancion mayorPuntajeDeCategoria(int categoria){
        Cancion aux=null;
        double max=0.0;
        if(categoria<=this.getDimFC()){
            for(int i=0;i<this.getDimL()[categoria-1];i++){
                if(this.getCategorias()[categoria-1][i].getPuntuacion()>max){
                    aux=this.getCategorias()[categoria-1][i];
                    max=this.getCategorias()[categoria-1][i].getPuntuacion();
                }
            }
        }
        return aux;
    }
    private Cancion[][] getCategorias() {
        return categorias;
    }

    private void setCategorias(Cancion[][] categorias) {
        this.categorias = categorias;
    }

    private int[] getDimL() {
        return dimLF;
    }

    private void setDimLF(int[] dimLF) {
        this.dimLF = dimLF;
    }

    private int getDimFC() {
        return dimFC;
    }

    private void setDimFC(int dimFC) {
        this.dimFC = dimFC;
    }

    private int getDimfF() {
        return dimfF;
    }

    private void setDimfF(int dimfF) {
        this.dimfF = dimfF;
    }

}
