/*Una estación de GNC quiere administrar la información 
correspondiente a la carga de gas. La estación posee una 
dirección, precio por m3 y la información de sus 6 surtidores.
De cada surtidor se conoce si se encuentra fuera de servicio y
la información de las ventas (como máximo V). De cada venta 
se registra: DNI del cliente, cantidad de m3 cargados, monto 
abonado y el medio de pago utilizado (débito, crédito o efectivo)

1-Genere las clases necesarias. Provea constructores para 
crear la estación para 6 surtidores, a partir de una
dirección. un precio por m3 y un máximo V de ventas por 
surtidor; cada surtidor en servicio y con capacidad para V 
ventas (inicialmente sin ventas); y cada venta a partir de la
información necesaria.  

2- Implemente los métodos necesarios, en las clases que 
corresponda, para:

a) Dado un número N de surtidor, el DNI de un cliente, una
cantidad de m3 y una forma de pago, generar la venta 
correspondiente y agregaría en dicho surtidor de la estación.
Asumir que el número N de surtidor es válido.

b) Dado un valor X, marcar como fuera de servicio aquellos 
surtidores que hayan vendido menos de X m3 en total (entre
todas sus ventas).

c) Obtener la venta realizada con mayor monto abonado de toda
la estación.

d) Obtener un String que represente la estación siguiendo el 
ejemplo
Estación de Servicio: Dirección precio por m3
Surtidor 1: Si está fuera de servicio o no; Ventas (ONí del 
cliente, cantidad de ma, monto abonado.)
Surtidor 2: Si está fuera de servicio o no; Ventas (DNI del 
cliente, cantidad de m3, monto abonado;
3- Realice un programa que Instancie una estación. Realice 
ventas Compruebe el correcto funcionamiento de los
métodos implementados. */
package gnc;
public class Estacion {
    private String direccion;
    private double precio;
    private Surtidor[] surtidores;
    private int dimF;
/*1-Genere las clases necesarias. Provea constructores para 
crear la estación para 6 surtidores, a partir de una
dirección. un precio por m3 y un máximo V de ventas por 
surtidor; cada surtidor en servicio y con capacidad para V 
ventas (inicialmente sin ventas); y cada venta a partir de la
información necesaria.*/
    public Estacion(String direccion, double precio,int V) {
        this.setDireccion(direccion);
        this.setPrecio(precio);
        this.surtidores = new Surtidor[6];
        this.setDimF(6);
        for(int i=0;i<this.getDimF();i++){
            Surtidor surtidor=new Surtidor(V);
            this.getSurtidores()[i]=surtidor;
        }
    }
/*a) Dado un número N de surtidor, el DNI de un cliente, una
cantidad de m3 y una forma de pago, generar la venta 
correspondiente y agregaría en dicho surtidor de la estación.
Asumir que el número N de surtidor es válido.*/
    public boolean generarVenta(int surtidor,int dni,int cantidad,String pago){
        boolean aux=false;
        if(this.getSurtidores()[surtidor-1].noCompletoVentas()){
            Venta venta=new Venta(dni,cantidad,this.getPrecio()*cantidad,pago);
            this.getSurtidores()[surtidor-1].generarVenta(venta);
            aux=true;
        }
        return aux;
    }
/*b) Dado un valor X, marcar como fuera de servicio aquellos 
surtidores que hayan vendido menos de X m3 en total (entre
todas sus ventas).*/
    public void marcarOffline(int X){
        for(int i=0;i<this.getDimF();i++)
            if(this.getSurtidores()[i].totalVendio()<X)
                this.getSurtidores()[i].setServicio(false);
    }
/*c) Obtener la venta realizada con mayor monto abonado de toda
la estación.*/
    public Venta mayorVenta(){
        Venta venta=null;
        double max=0;
        for(int i=0;i<this.getDimF();i++){
           Venta aux=this.getSurtidores()[i].mayorVenta();
           if(aux!=null)
               if(aux.getMonto()>max){
                   max=aux.getMonto();
                   venta=aux;
               }
        }
        return venta;
    }
/*d) Obtener un String que represente la estación siguiendo el 
ejemplo
Estación de Servicio: Dirección precio por m3
Surtidor 1: Si está fuera de servicio o no; Ventas (ONí del 
cliente, cantidad de ma, monto abonado.)
Surtidor 2: Si está fuera de servicio o no; Ventas (DNI del 
cliente, cantidad de m3, monto abonado;*/
    @Override
    public String toString(){
        String aux="Estacion de Servicio: "+this.getDireccion()+" "+this.getPrecio()+"$";
        for(int i=0;i<this.getDimF();i++){
            aux+="\n Surtidor "+(i+1)+": "+this.getSurtidores()[i].toString();
        }
        return aux;
    }
    public String getDireccion() {
        return direccion;
    }

    public void setDireccion(String direccion) {
        this.direccion = direccion;
    }

    public double getPrecio() {
        return precio;
    }

    public void setPrecio(double precio) {
        this.precio = precio;
    }

    private Surtidor[] getSurtidores() {
        return surtidores;
    }

    private void setSurtidores(Surtidor[] surtidores) {
        this.surtidores = surtidores;
    }

    private int getDimF() {
        return dimF;
    }

    private void setDimF(int dimF) {
        this.dimF = dimF;
    }
    
}
