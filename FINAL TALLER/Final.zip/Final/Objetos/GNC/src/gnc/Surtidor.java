/*Una estación de GNC quiere administrar la información 
correspondiente a la carga de gas. La estación posee una 
dirección, precio por m3 y la información de sus 6 surtidores.
De cada surtidor se conoce si se encuentra fuera de servicio y
la información de las ventas (como máximo V). De cada venta 
se registra: DNI del cliente, cantidad de m3 cargados, monto 
abonado y el medio de pago utilizado (débito, crédito o efectivo)

1-Genere las clases necesarias. Provea constructores para 
crear la estación para 6 surtidores, a partir de una
dirección. un precio por m3 y un máximo V de ventas por 
surtidor; cada surtidor en servicio y con capacidad para V 
ventas (inicialmente sin ventas); y cada venta a partir de la
información necesaria.  

2- Implemente los métodos necesarios, en las clases que 
corresponda, para:

a) Dado un número N de surtidor, el ONI de un cliente, una
cantidad de m3 y una forma de pago, generar la venta 
correspondiente y agregaría en dicho surtidor de la estación.
Asumir que el número N de surtidor es válido.

b) Dado un valor X, marcar como fuera de servicio aquellos 
surtidores que hayan vendido menos de X m3 en total (entre
todas sus ventas).

c) Obtener la venta realizada con mayor monto abonado de toda
la estación.

d) Obtener un String que represente la estación siguiendo el 
ejemplo
Estación de Servicio: Dirección precio por m3
Surtidor 1: Si está fuera de servicio o no; Ventas (ONí del 
cliente, cantidad de ma, monto abonado.)
Surtidor 2: Si está fuera de servicio o no; Ventas (DNI del 
cliente, cantidad de m3, monto abonado;
3- Realice un programa que Instancie una estación. Realice 
ventas Compruebe el correcto funcionamiento de los
métodos implementados. */
package gnc;
public class Surtidor {
    private boolean servicio;
    private Venta[] ventas;
    private int dimF;
    private int dimL;

    public Surtidor(int V) {
        this.setServicio(true);
        this.ventas= new Venta[V];
        this.setDimF(V);
        this.setDimL(0);
    }
    public void generarVenta(Venta venta){
        this.getVentas()[this.getDimL()]=venta;
        this.setDimL(this.getDimL()+1);
    }
    public boolean noCompletoVentas(){
        boolean aux=false;
        if(this.isServicio())
          if(this.getDimL()<this.getDimF())
            aux=true;
        return aux;
    }
    public double totalVendio(){
        double aux=0;
        for(int i=0;i<this.getDimL();i++)
            aux+=this.getVentas()[i].getCantidad();
        return aux;
    }
    public Venta mayorVenta(){
        Venta venta=null;
        double max=0;
        for(int i=0;i<this.getDimL();i++)
            if(this.getVentas()[i].getMonto()>max){
                max=this.getVentas()[i].getMonto();
                venta=this.getVentas()[i];
            }
        return venta;
    }
    /*d) Obtener un String que represente la estación siguiendo el 
ejemplo
Estación de Servicio: Dirección precio por m3
Surtidor 1: Si está fuera de servicio o no; Ventas (ONí del 
cliente, cantidad de ma, monto abonado.)
Surtidor 2: Si está fuera de servicio o no; Ventas (DNI del 
cliente, cantidad de m3, monto abonado;*/

    @Override
    public String toString() {
        String aux="Esta fuera de servicio: "+!this.isServicio()+"\nVENTAS: ";
        for(int i=0;i<this.getDimL();i++)
            aux+="\n       "+this.getVentas()[i].toString();
        return aux;
    }
    
    public boolean isServicio() {
        return servicio;
    }

    public void setServicio(boolean servicio) {
        this.servicio = servicio;
    }

    private Venta[] getVentas() {
        return ventas;
    }

    private void setVentas(Venta[] ventas) {
        this.ventas = ventas;
    }

    private int getDimF() {
        return dimF;
    }

    private void setDimF(int dimF) {
        this.dimF = dimF;
    }

    private int getDimL() {
        return dimL;
    }

    private void setDimL(int dimL) {
        this.dimL = dimL;
    }
    
}
