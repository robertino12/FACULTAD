/*la UNLP necesita un sistema para evaluar/otorgar subsidios de viaje a sus investigadores. El sistema detie permiti Inscribir a lo sumo N solicitudes de subsidios de viaje. 
De cada soncitud se conoce: nomtre del investigador, nombre del plan de trabajo, lugar de destino, costo del pasaje de ida, costo del pasaje de vuelta, tasa de embarque, cantidad de días 
de estadia, monto de hotel por dia y si fue otorgado o no el susidio.
Además, nos piden dos versiones del sistema, que varian en el algoritmo de otorgamiento de subsidion una versión otorgará aquellas solicitudes que no superen un monto de avión, la otra versión otorgará aqueltas solicitudes que no superen un monto de estadía.
1- Genere las clases. Provea constructores para iniciar los objetos de su modelo a partir de la información necesaria. En particular: las solicitudes de subsidios deben iniciar con estado no otorgado, cualquier sistera
debe iniciar sin solicitudes de subsidios y con capacidad de guardar a lo sumo N soficitudes.
2- Implemente todos los métodos necesarios, en las clases que corresponda, para:
a) Agregar una solicitud de subsidio al sistema.
b) Dado un número i, obtener la l-ésima solicitud de subsidio cargada en el sistema. Asuma que i es válido.
c) Otorgar subsidios. Dado un valor X (double) recibido:
- Una versión del sistema otorga todas las solicitudes de subsidios que no superen un monto de avión
X. El monto de avión de una solicitud es: costo_pasaje_ida + costo_pasaje_vuelta + tasa _embarque.
- Otra versión del sistema otorga todas las solicitudes de subsidios que no superen un monto de estadia
X. El monto de estadía de una solicitud es: cantidad_dias _estadia * costo_hotel_por _dia.
Nota: para otorgar una solicitud, cambie el estado de la misma a otorgado.
d) Obtener una representación String, que concatene de todos los subsidios otorgados: nombre del investigador, nombre del plan de trabajo, lugar de destino.
3- Escriba un programa que instancie un sistema de cada versión. Cargue algunas solicitudes de subsidios en cada sistema. Otorgue los subsidios en cada sistema. Imprima la información de los subsidios otorgados por
cada sistema.*/
package subsidios;
public abstract class Sistema {
    private Solicitud[] solicitudes;
    private int dimF;
    private int dimL;

    public Sistema(int N) {
        this.solicitudes=new Solicitud[N];
        this.setDimF(N);
        this.setDimL(0);
    }
    public abstract void otorgarSubsidios(double X);
    public boolean agregarSolicitud(Solicitud solicitud){
        boolean aux=false;
        if(this.getDimL()<this.getDimF()){
            this.getSolicitudes()[this.getDimL()]=solicitud;
            this.setDimL(this.getDimL()+1);
            aux=true;
        }
        return aux;
    }
    /*b) Dado un número i, obtener la l-ésima solicitud de subsidio cargada en el sistema. Asuma que i es válido.*/
    public Solicitud obtenerSolicitud(int i){
        return this.getSolicitudes()[i-1];
    }
    /*d) Obtener una representación String, que concatene de todos los subsidios otorgados: nombre del investigador, nombre del plan de trabajo, lugar de destino.*/
    @Override
    public String toString(){
        String aux="Se le entrego el subsidio a las siguiente personas: ";
        for(int i=0;i<this.getDimL();i++){
            if(this.getSolicitudes()[i].isOtorgado()){
                aux+="\n"+(i+1)+". "+this.getSolicitudes()[i].toString();
            }
        }
        return aux;
    }
    public Solicitud[] getSolicitudes() {
        return solicitudes;
    }

    private void setSolicitudes(Solicitud[] solicitudes) {
        this.solicitudes = solicitudes;
    }

    private int getDimF() {
        return dimF;
    }

    private void setDimF(int dimF) {
        this.dimF = dimF;
    }

    public int getDimL() {
        return dimL;
    }

    private void setDimL(int dimL) {
        this.dimL = dimL;
    }
    
    
    
}
