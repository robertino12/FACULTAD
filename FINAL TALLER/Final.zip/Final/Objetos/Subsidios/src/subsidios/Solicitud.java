/*la UNLP necesita un sistema para evaluar/otorgar subsidios de viaje a sus investigadores. El sistema detie permiti Inscribir a lo sumo N solicitudes de subsidios de viaje. 
De cada soncitud se conoce: nomtre del investigador, nombre del plan de trabajo, lugar de destino, costo del pasaje de ida, costo del pasaje de vuelta, tasa de embarque, cantidad de días 
de estadia, monto de hotel por dia y si fue otorgado o no el susidio.
Además, nos piden dos versiones del sistema, que varian en el algoritmo de otorgamiento de subsidion una versión otorgará aquellas solicitudes que no superen un monto de avión, la otra versión otorgará aqueltas solicitudes que no superen un monto de estadía.
1- Genere las clases. Provea constructores para iniciar los objetos de su modelo a partir de la información necesaria. En particular: las solicitudes de subsidios deben iniciar con estado no otorgado, cualquier sistera
debe iniciar sin solicitudes de subsidios y con capacidad de guardar a lo sumo N soficitudes.
2- Implemente todos los métodos necesarios, en las clases que corresponda, para:
a) Agregar una solicitud de subsidio al sistema.
b) Dado un número i, obtener la l-ésima solicitud de subsidio cargada en el sistema. Asuma que i es válido.
c) Otorgar subsidios. Dado un valor X (double) recibido:
- Una versión del sistema otorga todas las solicitudes de subsidios que no superen un monto de avión
X. El monto de avión de una solicitud es: costo_pasaje_ida + costo_pasaje_vuelta + tasa _embarque.
- Otra versión del sistema otorga todas las solicitudes de subsidios que no superen un monto de estadia
X. El monto de estadía de una solicitud es: cantidad_dias _estadia * costo_hotel_por _dia.
Nota: para otorgar una solicitud, cambie el estado de la misma a otorgado.
d) Obtener una representación String, que concatene de todos los subsidios otorgados: nombre del investigador, nombre del plan de trabajo, lugar de destino.
3- Escriba un programa que instancie un sistema de cada versión. Cargue algunas solicitudes de subsidios en cada sistema. Otorgue los subsidios en cada sistema. Imprima la información de los subsidios otorgados por
cada sistema.*/
package subsidios;
public class Solicitud {
    private String investigador;
    private String plan;
    private String destino;
    private double costoIda;
    private double costoVuelta;
    private double tazaDeEmbarque;
    private int dias;
    private double hotel;
    private boolean otorgado;

    public Solicitud(String investigador, String plan, String destino, double costoIda, double costoVuelta, double tazaDeEmbarque, int dias, double hotel) {
        this.setInvestigador(investigador);
        this.setPlan(plan);
        this.setDestino(destino);
        this.setCostoIda(costoIda);
        this.setCostoVuelta(costoVuelta);
        this.setTazaDeEmbarque(tazaDeEmbarque);
        this.setDias(dias);
        this.setHotel(hotel);
        this.setOtorgado(false);
    }
    @Override
    public String toString(){
        return this.getInvestigador()+", cuyo plan de trabajo es: "+this.getPlan()+" y su lugar de destino es: "+this.getDestino();
    }

    public double montoDeAvion(){
        return this.getCostoIda()+this.getCostoVuelta()+this.getTazaDeEmbarque();
    }
    public double montoDeEstadia(){
        return this.getHotel()*this.getDias();
    }
    public String getInvestigador() {
        return investigador;
    }

    public void setInvestigador(String investigador) {
        this.investigador = investigador;
    }

    public String getPlan() {
        return plan;
    }

    public void setPlan(String plan) {
        this.plan = plan;
    }

    public String getDestino() {
        return destino;
    }

    public void setDestino(String destino) {
        this.destino = destino;
    }

    public double getCostoIda() {
        return costoIda;
    }

    public void setCostoIda(double costoIda) {
        this.costoIda = costoIda;
    }

    public double getCostoVuelta() {
        return costoVuelta;
    }

    public void setCostoVuelta(double costoVuelta) {
        this.costoVuelta = costoVuelta;
    }

    public double getTazaDeEmbarque() {
        return tazaDeEmbarque;
    }

    public void setTazaDeEmbarque(double tazaDeEmbarque) {
        this.tazaDeEmbarque = tazaDeEmbarque;
    }

    public int getDias() {
        return dias;
    }

    public void setDias(int dias) {
        this.dias = dias;
    }

    public double getHotel() {
        return hotel;
    }

    public void setHotel(double hotel) {
        this.hotel = hotel;
    }

    public boolean isOtorgado() {
        return otorgado;
    }

    public void setOtorgado(boolean otorgado) {
        this.otorgado = otorgado;
    }
}
