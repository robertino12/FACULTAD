/*Se desea representar un Banco. El Banco tiene su nombre, 
cantidad de empleados y la información de sus cuentas (máximo
N cuentas). 

De cada cuenta se conoce su CBU, alias, DNI del titular, 
moneda y monto. Existen dos tipos de bancos: el tradicional 
que posee su dirección, localidad y cantidad de cuentas en 
dólares abiertas y el digital que define su dirección web.
1- Genere las clases necesarias. Provea constructores para 
iniciar los objetos del modelo a partir de la información 
necesaria.
En particular, los bancos deben iniciarse para un máximo de N 
cuentas, (inicialmente sin cuentas); el banco tradicional debe 
iniciar con cantidad O de cuentas en dólares abiertas; una 
cuenta debe iniciarse con monto en 0.
2- Implemente los métodos necesarios, en las clases que 
corresponda, para:

a) agregarCuenta: Agrega una cuenta al banco. Considerar que un 
banco tradicional puede tener un máximo de 100 cuentas abiertas 
en dólares. El método debe retornar true si pudo agregarse y 
false en caso contrario. 

b) obtenerCuenta: Dado un CBU, obtener la cuenta con dicho CBU.

c) depositarDinero: Dado un CBU y un monto, incrementar el monto
de la cuenta en dicha cantidad.

d) puedeRecibirTarjeta: Recibe un CBU y retorna si es posible 
asociarle una tarjeta de débito a la cuenta. Este método retorna
verdadero en las siguientes situaciones:
• Si el banco es digital, la cuenta debe ser en pesos y su saldo 
superior a $100.000.
• Si el banco es tradicional, la cuenta debe ser en dólares o 
pesos. Si es en dólares, con saldo superior a U$S 500. Si es en 
pesos con saldo superior a $70.000.

3- Realice un programa que instancie un banco tradicional y otro 
digital. Agregue cuentas bancarias y realice las operaciones de 
los puntos 2.c y 2.d. */
package bancos;
public class Bancos {
    public static void main(String[] args) {
        Tradicional tradicional=new Tradicional("7 y 50","Localidad","Banco Provincia",10,7);
        
        Cuentas cuenta1=new Cuentas(641,"Alejo.mp",46434641,"Pesos");
        System.out.println(tradicional.agregarCuenta(cuenta1));
        
        Cuentas cuenta2=new Cuentas(487,"tobi.dlp",43434581,"Dolares");
        System.out.println(tradicional.agregarCuenta(cuenta2));
        
        Cuentas cuenta3=new Cuentas(365,"elfamosoGordoTete",14523688,"Pesos");
        System.out.println(tradicional.agregarCuenta(cuenta3));
        
        Cuentas cuenta4=new Cuentas(859,"pilar mujer del gordo",44528581,"Dolares");
        System.out.println(tradicional.agregarCuenta(cuenta4));
        
        Cuentas cuenta5=new Cuentas(777,"tu waaa",21256859,"Pesos");
        System.out.println(tradicional.agregarCuenta(cuenta5));
        
        Cuentas cuenta6=new Cuentas(666,"pepa pig",11236541,"Dolares");
        System.out.println(tradicional.agregarCuenta(cuenta6));
        
        Cuentas cuenta7=new Cuentas(895,"computadora.mp",33333333,"Pesos");
        System.out.println(tradicional.agregarCuenta(cuenta7));
        
        tradicional.depositarDinero(641,70000);
        System.out.println(tradicional.puedeRecibirTarjeta(641));
        
        tradicional.depositarDinero(487,501);
        System.out.println(tradicional.puedeRecibirTarjeta(487));
        
        tradicional.depositarDinero(365,71000);
        System.out.println(tradicional.puedeRecibirTarjeta(365));
        
        tradicional.depositarDinero(859,500);
        System.out.println(tradicional.puedeRecibirTarjeta(859));
        
        tradicional.depositarDinero(777,150000);
        System.out.println(tradicional.puedeRecibirTarjeta(777));
        
        tradicional.depositarDinero(666,400);
        System.out.println(tradicional.puedeRecibirTarjeta(666));
        
        tradicional.depositarDinero(555,10);
        System.out.println(tradicional.puedeRecibirTarjeta(555));
        
        Digital digital=new Digital("www.BancoFrances.com","Banco Frances",10,5);
        
        Cuentas cuentad1=new Cuentas(111,"tobi.culo.mp",32628895,"Pesos");
        System.out.println(digital.agregarCuenta(cuentad1));
        
        Cuentas cuentad2=new Cuentas(222,"culonnn",13121110,"Dolares");
        System.out.println(digital.agregarCuenta(cuentad2));
        
        Cuentas cuentad3=new Cuentas(333,"consumiendooo",99999999,"Pesos");
        System.out.println(digital.agregarCuenta(cuentad3));
        
        Cuentas cuentad4=new Cuentas(444,"pepapig",88888888,"Dolares");
        System.out.println(digital.agregarCuenta(cuentad4));
        
        Cuentas cuentad5=new Cuentas(555,"culonnn",22326288,"Pesos");
        System.out.println(digital.agregarCuenta(cuentad5));
        
        digital.depositarDinero(111,99999);
        System.out.println(digital.puedeRecibirTarjeta(111));
        digital.depositarDinero(223,150);
        System.out.println(digital.puedeRecibirTarjeta(222));
        digital.depositarDinero(333,999999);
        System.out.println(digital.puedeRecibirTarjeta(333));
        digital.depositarDinero(444,959999);
        System.out.println(digital.puedeRecibirTarjeta(444));
        digital.depositarDinero(650,12);
        System.out.println(digital.puedeRecibirTarjeta(555));
      }
    }
    
