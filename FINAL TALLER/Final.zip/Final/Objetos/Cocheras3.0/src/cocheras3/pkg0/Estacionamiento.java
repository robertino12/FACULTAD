/*Una cochera estacionamiento necesita gestionar sus sectores y coches ingresados. La cochera 
tiene dos sectores (cubierto y descubierto). Los sectores conocen el costo a cobrar por hora de 
estacionamiento y la informacion del coche ingresado en c/u de sus 20 lugares. De los coches 
se registra patente y cantidad de horas que estará en el estacionamiento.
1) Genere las clases necesarias. Implemente constructores. Tenga en cuenta que los sectores 
se inician sin coches en sus lugares y que la cochera se inicia a partir del costo por hr. a cobrar 
de cada sector.
2) Agregue los métodos necesarios, en las clases que correspondan, para permitir:
a) Ingresar un coche C en el primer lugar líbre de un sector. Asuma que seguro existe un 
lugar libre. Devuelva el nro. del lugar que ocupará en el sector.
b) Ingresar un coche C a la cochera. El coche se ingresa al sector cubierto si hay lugar libre en el 
mismo, caso contrario se ingresa al sector descubierto. Asuma que hay un lugar libre en alguno 
de los sectores. Devuelva un string que concatene el sector y el nro. de lugar que ocupará en el 
sector
c) Obtener la cantidad total de coches al momento en la cochera (tenga en cuenta ambos 
sectores).
3) Implemente un programa que instancie una cochera (con costo por hora para el sector 
cubierto de $250 y para el descubierto de $220). Ingrese 4 coches y muestre la cantidad total 
de coches en la cochera.*/
package cocheras3.pkg0;
public class Estacionamiento {
    private Sector descubierto;
    private Sector cubierto;

    public Estacionamiento(double precioCubierto,double precioDescubierto) {
        this.descubierto=new Sector(precioDescubierto);
        this.cubierto=new Sector(precioCubierto);
    }
     /*b) Ingresar un coche C a la cochera. El coche se ingresa al sector cubierto si hay lugar libre en el 
mismo, caso contrario se ingresa al sector descubierto. Asuma que hay un lugar libre en alguno 
de los sectores. Devuelva un string que concatene el sector y el nro. de lugar que ocupará en el 
sector*/
    public String ingresarCoche(Coche coche){
        String aux;
        if(this.getCubierto().estaLibre())
            aux="Cubierto "+this.getCubierto().ingresarCoche(coche);
        else
            aux="Descubierto "+this.getDescubierto().ingresarCoche(coche);
        return aux;
    }
    /*c) Obtener la cantidad total de coches al momento en la cochera (tenga en cuenta ambos 
sectores).*/
    public int totalCoches(){
        return this.getCubierto().cantCoches()+this.getDescubierto().cantCoches();
    }

    private Sector getDescubierto() {
        return descubierto;
    }

    private void setDescubierto(Sector descubierto) {
        this.descubierto = descubierto;
    }

    private Sector getCubierto() {
        return cubierto;
    }

    private void setCubierto(Sector cubierto) {
        this.cubierto = cubierto;
    }

}
