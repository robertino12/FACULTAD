/*TURNO A - TEMA 1 - Módulo Objetos - 19/10/2023
-queremos representar compras realizadas en un comercio De una compra se conoce numero, fecha (dia, mes, año) y los productos comprados (a lo sumo N). asimismo el comercio permite hacer 
compras al por mayor que poseen ademas los datos del consumidor final (CUIT y nombre). Los productos se caracterizan por tener codigo, descripcion, precio unitario y cantidad de unidades
1- Genere las clases necesarias. Provea constructores para iniciar los objetos de su modelo a partir de la informacion necesaria. En particular, las compras deben iniciar con un número, 
una fecha, y sin productos (con capacidad de guardad a lo sumo N productos): y además para las compras al por mayor, con el consumidor final.
2- Implemente los métodos necesarios, en las clases que corresponda, para
a- Agregar un producto a la compra. Tener en cuenta que en las compras al por mayor el producto se agrega solo si supera las 6 unidades.
b- Obtener el precio final de la compra. Tener en cuenta que: el precio final es la suma de los precios finales de los productos agregados 
(el precio final de un producto es precio _unitario * cantidad_unidades), las compras al por mayor descuentan el 21% (correspondiente al IVA) al precio final de la compra.
c- Obtener un resumen de compra, que concatene: número, fecha (día/mes/año), el código, descripción y precio final de cada producto agregado, y el precio final de la compra
d- Saber si la compra es abonable en cuotas. Esto es posible cuando su precio final supera los 100.000
3- Realice un programa que instancie una compra y una compra al por mayor, con los datos necesarios y para un maximo de 10 productos. Cargue algunos productos a cada compra. 
Al finalizar, muestre el resumen de cada compra e prima si son abonables en cuotas.*/
package compras;
public class Fecha {
    private int dia;
    private int mes;
    private int ano;

    public Fecha(int dia, int mes, int ano) {
        this.setDia(dia);
        this.setMes(mes);
        this.setAno(ano);
    }

    public int getDia() {
        return dia;
    }

    public void setDia(int dia) {
        this.dia = dia;
    }

    public int getMes() {
        return mes;
    }

    public void setMes(int mes) {
        this.mes = mes;
    }

    public int getAno() {
        return ano;
    }

    public void setAno(int ano) {
        this.ano = ano;
    }

    @Override
    public String toString(){
        return this.getDia()+"/"+this.getMes()+"/"+this.getAno();
    }

}
