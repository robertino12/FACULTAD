/*/*TURNO A - TEMA 1 - Módulo Objetos - 19/10/2023
-queremos representar compras realizadas en un comercio De una compra se conoce numero, fecha (dia, mes, año) y los productos comprados (a lo sumo N). asimismo el comercio permite hacer 
compras al por mayor que poseen ademas los datos del consumidor final (CUIT y nombre). Los productos se caracterizan por tener codigo, descripcion, precio unitario y cantidad de unidades
1- Genere las clases necesarias. Provea constructores para iniciar los objetos de su modelo a partir de la informacion necesaria. En particular, las compras deben iniciar con un número, 
una fecha, y sin productos (con capacidad de guardad a lo sumo N productos): y además para las compras al por mayor, con el consumidor final.
2- Implemente los métodos necesarios, en las clases que corresponda, para
a- Agregar un producto a la compra. Tener en cuenta que en las compras al por mayor el producto se agrega solo si supera las 6 unidades.
b- Obtener el precio final de la compra. Tener en cuenta que: el precio final es la suma de los precios finales de los productos agregados 
(el precio final de un producto es precio _unitario * cantidad_unidades), las compras al por mayor descuentan el 21% (correspondiente al IVA) al precio final de la compra.
c- Obtener un resumen de compra, que concatene: número, fecha (día/mes/año), el código, descripción y precio final de cada producto agregado, y el precio final de la compra
d- Saber si la compra es abonable en cuotas. Esto es posible cuando su precio final supera los 100.000
3- Realice un programa que instancie una compra y una compra al por mayor, con los datos necesarios y para un maximo de 10 productos. Cargue algunos productos a cada compra. 
Al finalizar, muestre el resumen de cada compra e prima si son abonables en cuotas.
 */
package compras;
public class Compra {
    private int numero;
    private Fecha fecha;
    private Producto[] productos;
    private int dimF;
    private int dimL;

    public Compra(int numero, Fecha fecha,int N) {
        this.setNumero(numero);
        this.setFecha(fecha);
        this.productos=new Producto[N];
        this.setDimF(N);
        this.setDimL(0);
    }
    /*a- Agregar un producto a la compra. Tener en cuenta que en las compras al por mayor el producto se agrega solo si supera las 6 unidades.*/
    public boolean agregarProducto(Producto producto){
        boolean aux=false;
        if(this.getDimL()<this.getDimF()){
            this.getProductos()[this.getDimL()]=producto;
            aux=true;
            this.setDimL(this.getDimL()+1);
        }
        return aux;
    }
    /*b- Obtener el precio final de la compra. Tener en cuenta que: el precio final es la suma de los precios finales de los productos agregados 
(el precio final de un producto es precio _unitario * cantidad_unidades), las compras al por mayor descuentan el 21% (correspondiente al IVA) al precio final de la compra.*/
    public double obtenerPrecioFinal(){
        double aux=0;
        for(int i=0;i<this.getDimL();i++){
            aux+=this.getProductos()[i].precioFinal();
        }
        return aux;
    }
    /*c- Obtener un resumen de compra, que concatene: número, fecha (día/mes/año), el código, descripción y precio final de cada producto agregado, y el precio final de la compra*/
    public String resumenDeCompra(){
        String aux="Numero de compra: "+this.getNumero()+" ("+this.getFecha().toString()+")";
        for(int i=0;i<this.getDimL();i++){
            aux+="\n"+this.getProductos()[i].toString();
        }
        aux+="\nPRECIO FINAL "+this.obtenerPrecioFinal()+"$";
        return aux;
    }
        /*d- Saber si la compra es abonable en cuotas. Esto es posible cuando su precio final supera los 100.000*/
    public boolean esAbonableEnCuotas(){
       boolean aux=false;
       if(this.obtenerPrecioFinal()>2000)
           aux=true;
       return aux;
    }
    
    public int getNumero() {
        return numero;
    }

    public void setNumero(int numero) {
        this.numero = numero;
    }

    public Fecha getFecha() {
        return fecha;
    }

    public void setFecha(Fecha fecha) {
        this.fecha = fecha;
    }

    private Producto[] getProductos() {
        return productos;
    }

    private void setProductos(Producto[] productos) {
        this.productos = productos;
    }

    private int getDimF() {
        return dimF;
    }

    private void setDimF(int dimF) {
        this.dimF = dimF;
    }

    private int getDimL() {
        return dimL;
    }

    private void setDimL(int dimL) {
        this.dimL = dimL;
    }

}
